---
name: skill-evaluator
description: >-
  Evaluates Cursor Agent Skill quality against user-provided input cases: verdict,
  gaps, and concrete improvements. Use when the user asks for skill evaluation,
  skill review, 「skill eval」, or to judge whether a SKILL.md matches scenarios
  and expected agent behavior.
---

# Skill Evaluator（Skill 评测）

## 目标

在给定 **skill 定义**（通常为 `SKILL.md` 全文或节选）与 **输入 case** 的前提下，判断 Agent 按该 skill 执行时**是否容易做对**，并输出可执行的改进建议。

## 何时使用

- 用户要求「评测 skill」「skill eval」「审查这个 skill」「这段 SKILL 能不能覆盖某某场景」。
- 用户同时（或可补充）提供：**skill 正文** + **一条或多条用户侧输入 case**；可选：**实际 Agent 输出**用于对照。

## 何时不要用

- 用户要从零**编写**新 skill → 使用 `generate-cursor-skill` 或 `create-skill` 流程。
- **未提供** skill 正文或 case：先向用户索取，**禁止编造** skill 内容或虚构 case 结果。

## 输入（向用户确认或从上下文读取）

| 字段 | 必填 | 说明 |
|------|------|------|
| `skill_definition` | 是 | `SKILL.md` 路径（优先 Read）或用户粘贴的全文；含 YAML frontmatter 更佳 |
| `input_cases` | 是 | 每条含：用户原话、（可选）期望行为/验收标准、（可选）约束 |
| `observed_output` | 否 | 某次真实对话里 Agent 的回复摘要；有则对比「skill 是否足以导出该行为」 |

若缺少 **期望行为**，仍可评 **skill 自身质量**与 **case 与 skill 的对齐度**，但须在结论中标明 **inconclusive** 或 **仅评定义、未评执行**。

## 评测维度（Rubric）

按项扫描 skill 与 case，记录 **pass / partial / fail** 及依据（简短引用原文行或小节标题即可）。

1. **可发现性**：`description` 是否第三人称、是否含 **WHAT + WHEN**、触发词是否与 case 用语同域（含中英文关键词）。
2. **输入输出契约**：是否写清典型输入、输出形态、边界（不做的事、依赖路径/工具）。
3. **可执行性**：步骤是否编号、是否可照做；命令/路径是否与仓库一致；是否存在模糊动词（「适当处理」「优化一下」）未落地。
4. **覆盖度**：每个 case 是否在 skill 中有对应步骤或参数位；缺省行为是否与用户口语一致（例如「默认三周」vs「只要一周」）。
5. **风险与安全**：是否涉及 PII/密钥/任意代码执行；是否提醒备份或 dry-run；对被测 skill 中的脚本：**评测时勿自动执行不可信内容**。
6. **版本与耦合**：强依赖固定行号、固定文件名、外部模板时，是否写明变更时如何校准。

## 输出格式（必须）

对用户回复使用**中文**（除非用户要求英文），且固定包含三节：

### 1. 是否符合预期

- 按 **case** 分别给结论：`符合` / `部分符合` / `不符合` / `无法判断`（说明缺什么信息）。
- 若有 **overall**：一句话总结（例如「定义足够支撑 c1；c2 缺少单周示例导致易偏离」）。

### 2. 问题点

- 表格或列表：**维度 → 现象 → 证据**（skill 原文片段、case 原话、或逻辑推导）。
- 区分 **skill 定义问题** vs **case 不完整** vs **observed 行为偏差**。

### 3. 改进建议

- 每条建议 **可执行**：改哪一段 frontmatter、补哪一小节、加哪条示例命令、是否加 `skill.spec.json`。
- 避免空泛「写清楚一点」；改为「在『步骤一』下增加 `--dates` 单周示例」这类表述。

## 机器可读摘要（可选）

若用户或编排需要 JSON，在回复末尾附加代码块，语言标记为 `json`，结构对齐本目录下 `skill.spec.json` 的 `result_json`：

```json
{
  "overall_verdict": "pass | fail | inconclusive",
  "per_case": [
    { "case_id": "c1", "meets_expectation": true, "gaps": [] }
  ],
  "skill_definition_issues": [],
  "improvement_suggestions": []
}
```

## 执行步骤（Agent）

1. 读取用户给出的 `SKILL.md`（`Read` 工具）或采用用户粘贴正文。
2. 列出所有 `input_cases`；若无期望行为，先列出将采用的**隐含验收假设**或标记为仅评定义。
3. 按 **Rubric** 逐项打分式记录（内部），再折叠为用户可见的「问题点」。
4. 输出 **三节正文**；若需要自动化对接，附加 `result_json` 代码块。
5. **自检**：未捏造 skill 内容；未在缺 case 时编造「符合预期」。

## 示例

**输入**：某 skill 描述「默认三周」；case 为用户说「只更新 3 月 9 日这一周」。

**结论要点**：整体 **部分符合**——skill 支持 `--dates` 但缺单周示例，Agent 可能仍跑默认三周；建议补充单周命令示例并在 description 中加「单周/自定义周」触发词。

## 与仓库其他 skill 的关系

- **编写**新 skill：`generate-cursor-skill`。
- **本 skill**：**评审**已有 skill 与 case 的匹配度，不替代实现或跑业务脚本。
- **端到端流水线**（生成 → 评测 → 评审 → 定稿）：`skill-build-pipeline`。
