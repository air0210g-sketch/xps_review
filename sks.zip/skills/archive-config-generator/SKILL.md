---
name: archive-config-generator
description: 为 delivery-service 生成数据库归档配置 JSON。当用户提到归档、清理数据时使用。
---

# 归档配置生成器 (Archive Config Generator)

分析代码 (model/repo/cron) 并生成 Shopee DB Archive 插件所需的配置 JSON。

## 1. 分析与安全 Checklist (必填)

生成前必须核对并报告。标注 `[代码分析]` 的项由 Cursor 自动完成，标注 `[用户确认]` 的项需用户自行在对应平台操作后告知结果。

- **现有清理任务 `[代码分析]`**: 搜索 `saturnjob` 和 `cron_*` 确认代码中是否有现有清理逻辑。
- **归档平台查重 `[用户确认]`**: 用户需自行在归档平台确认是否已有该表的归档任务，避免重复执行或逻辑冲突。
- **下游依赖 `[用户确认]`**: 用户需自行检查 ODS 表/Hive 是否有同步依赖，并确认依赖方使用情况。(有依赖 -> `TRANS_REMOVE`; 无依赖 -> `ONLY_REMOVE`)。
- **数据终态 `[代码分析]`**: SQL 条件必须覆盖所有业务终态 (如 complete/reject/cancel)，避免废弃数据长期堆积。
- **兜底条件 `[代码分析]`**: 除常规的 状态+时间 过滤 (如 `ctime < 3个月`)，建议增加极值兜底条件 (如 `OR ctime <= 1年`)，强制清理因历史 Bug 导致状态永远无法流转的异常脏数据。
- **分库分表 `[代码分析]`**: 区分分库 (`sharding_enabled`) 与分表 (表名后缀)。确认分片哈希算法 (平台内置 `crc32` 和 `fnv64`，其他算法需 UDF)。
- **集群映射 `[代码分析]`**: 将代码中的 `BindDefaultDBByCluster` 映射到下方 DB Pattern。

## 2. 数据库集群映射

| 常量 | Pattern |
|---|---|
| `DEFAULTDB` | `shopee_fms_delivery_{CID}_db` |
| `FMSDB` | `shopee_ssc_spx_delivery_mgt_{CID}_db` |
| `EXTDB` | `shopee_ssc_spx_delivery_ext_data_{CID}_db` |
| `FEEDERDB` | `shopee_ssc_spx_delivery_feeder_{CID}_db` |
| `其他`| *需询问用户 Pattern，询问后同时更新该映射* |

## 3. JSON Schema & 规则

输出 JSON 文件 (`~/Downloads/archive_config_{表名}_{日期}.json`)。
**严格遵循此结构:**

```json
{
  "service": "deliveryapi",
  "db_pattern": "shopee_fms_delivery_{CID}_db", // 必须包含 {CID}。若分库，使用 {CID}_$index
  "table": "example_tab", // 若分表，使用前缀并删去末尾 index (如 "order_tab_")
  "condition": "where (ctime < unix_timestamp(DATE_SUB(:?, INTERVAL 3 MONTH)) AND status IN (1,2,3) OR ctime < unix_timestamp(DATE_SUB(:?, INTERVAL 12 MONTH)))", // where 子句必须加括号
  "condition_expression": "now()",
  "frequency": 14, // 天数
  "qps_limit": 1000,
  "db_delay": 2,
  "markets": ["id", "br", "vn", "th", "ph", "tw", "sg", "my"],
  "archive_type": "ONLY_REMOVE", // 或 "TRANS_REMOVE"
  "table_type": "General", // 多库多表关联归档时必须为 "SDDL"
  // 若 TRANS_REMOVE (迁移后删除):
  "target_db_pattern": "shopee_ssc_spx_delivery_{CID}_archive_2026_db",
  "target_table": "example_tab", // 与 table 同名
  // 若分库
  "sharding_enabled": true,
  "sharding_start": 0,
  "sharding_end": 100, // db_pattern 中的 $index 将被替换为 000000-000100
  // 若关联表 (级联删除):
  "assoc_tables": [
    {
      "parent_table": "{db_pattern}.{main_table}",
      "src_db": "...",
      "src_table": "child_tab",
      "foreign_keys": [{ "from": "parent_col", "to": "child_col" }] // 外键必须包含分片键，且必须走索引
      // 若 TRANS_REMOVE (迁移后删除):
      "target_db_pattern": "shopee_ssc_spx_delivery_{CID}_archive_2026_db",
      "target_table": "example_tab", // 与 src_table 同名
    }
  ]
}
```

### 关键规则

- `condition` 中使用 `:?` 代替 `now()`，对应的实际值填入 `condition_expression`。`ctime` 默认秒级。
- 归档过程只走主键索引 (相当于全表扫描)，`where` 子句本身不需要考虑索引优化。
- `TRANS_REMOVE` 仅支持源表与目标表一一对应；若关系不一致，需要配置 SDDL。
- 同一 DB cluster 上同一时刻只能运行一个 remove 任务。
- 关联表的外键 (Foreign Key) **必须包含分片键 (Sharding Key)**，且该分片键必须走索引。
- 同表多市场建议放在一个 Ticket 中，每个市场单独一个 Job。

### SDDL 逻辑表

多库多表关联归档时，`table_type` 必须设为 `"SDDL"`，并提醒用户在 SDDL 平台创建/更新逻辑库。若 `TRANS_REMOVE`，target 表也需要配置 SDDL 表。

SDDL 逻辑库命名规范: `{原库名}__sddl`，如 `shopee_fms_delivery_br_db__sddl`。

> **SDDL 配置属于平台操作 `[用户确认]`**：Cursor 无法直接操作 SDDL 平台，仅提醒用户需要配置，并告知命名规范和注意事项。

## 4. 输出要求

1. **Checklist 报告**: 简要说明第 1 部分每项的检查结果。`[代码分析]` 项给出通过/失败/警告；`[用户确认]` 项标记为"待用户确认"并说明用户需要检查什么。
2. **生成文件**: 写入 JSON 文件到 `~/Downloads/`。
3. **风险提示**: 高亮具体风险 (如：未知依赖、终态遗漏、分片键未走索引、SDDL 未配置)。
4. **后续提醒**: 提醒用户完成以下平台操作：
   - 在归档平台创建 Ticket 和 Job
   - 如涉及 SDDL，在 SDDL 平台创建/更新逻辑库
   - 将 Job 链接回填到归档信息收集表
