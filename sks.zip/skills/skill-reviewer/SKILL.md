---
name: skill-reviewer
description: >-
  Reviews a Cursor Agent SKILL.md (and optional scripts/spec): scores I/O clarity,
  ambiguity, hallucination risk, and split/reuse; outputs prioritized fixes and an
  optional rewritten SKILL.md. Use when the user asks to review, audit, or harden
  a skill, or before publishing a skill to the team.
---

# Skill Reviewer（Agent Skill 评审）

## 目标

对**待评审的 Skill**（通常 `SKILL.md`，必要时含同目录 `scripts/`、`skill.spec.json`）做结构化质量评审，并给出**可执行的改进项**与**可选的修订版正文**。

## 何时使用

- 用户说「评审 skill」「skill review」「检查 SKILL 质量」「防幻觉」「能否拆分」等。
- 新增或大幅改写 skill 后、准备共享到项目/团队前。

## 何时不要用

- 用户尚未提供**被评审对象**（路径或粘贴全文）且无法从仓库推断时：先请用户指定文件或粘贴内容，**不要凭空评审**。

## 输入（必须明确其一）

| 来源 | 要求 |
|------|------|
| 仓库内路径 | 例如 `.cursor/skills/foo/SKILL.md`；若正文引用 `scripts/*.py`，**应打开并核对**脚本与文档是否一致。 |
| 用户粘贴 | 完整 YAML frontmatter + 正文；若提到外部路径，说明是否在本仓库。 |

可选上下文：`review_locale`（默认中文结论）、`emit_rewritten_skill`（`true` 时输出完整新版 `SKILL.md` 草稿）、`strictness`（`normal` | `strict`，strict 时对未验证的断言一律标为风险）。

## 执行步骤

1. **读取**目标 `SKILL.md`（及被引用的脚本路径、若存在则 `read_file`）。
2. **对照**下列四维逐项记录证据（引用原文短句或行号/章节标题，避免空泛形容词）。
3. **一致性检查**：文档描述的命令、路径、参数、行号/公式/默认值是否与仓库文件一致；不一致则记入「幻觉风险」并标明**以代码为准**的修订建议。
4. **输出**按下方「输出格式」组织；若 `emit_rewritten_skill=true`，给出**完整**新版 `SKILL.md`（含合法 YAML frontmatter），并说明相对原稿的结构性变化。
5. **自检**：未读取被评文件不得给出具体修改句；不得伪造不存在的脚本或标志位。

## 评审维度（必须覆盖）

### 1. 输入输出是否清晰

- `description`（frontmatter）是否包含 **WHAT + WHEN**、触发场景是否可检索。
- 正文中**人类调用输入**（文件、参数、目录、前置条件）与**完成判据**（怎样算做完）是否可验证。
- 若存在 CLI：是否写明**默认工作目录**、默认路径、与 `--help` 或脚本实现是否一致。

### 2. 歧义

- 是否存在**多入口**（多脚本）但未说明默认推荐路径。
- 「可选」「默认」「整表」等词是否缺少操作定义（例如与 `--dates` / `--all-columns` 的对应关系）。
- 术语混用（中英文指标名、路径相对仓库根 vs 绝对）是否会导致执行偏差。

### 3. Hallucination（模型臆造）风险

- Skill 是否**要求或暗示** Agent 在未经核对的情况下手写关键事实（行号、列字母、API 字段、配置 key）。
- 是否缺少**权威来源**声明（例如「以某脚本常量为准」「以 openapi 为准」）。
- 长表格、易变模板是否与代码**脱钩**；若脱钩，是否提示模板变更时的同步流程。

### 4. 拆分 / 复用

- 单文件是否混合**操作手册**、**领域公式/业务释义**、**脚本实现细节**；可否抽 `reference.md` 或子 skill。
- 是否与仓库内其他 skill **重复**（如生成类 vs 评审类）；重复部分建议交叉引用而非复制。

## 输出格式（对用户展示）

### A. 摘要

- 一两句：**是否建议合并/拆分**、**最大风险点**。

### B. 四维结论

对每一维给出：`结论（低/中/高）` + `依据（要点列表）`。

### C. 改进建议

- 使用表格：`优先级（P0/P1/P2）` | `问题` | `改法` | `影响面`。
- P0：会导致错误执行或与代码不一致项。

### D. 新版本 Skill（可选）

- 当用户要求或 `emit_rewritten_skill=true`：输出完整 ```markdown 代码块```，内容为新版 `SKILL.md`，并附「变更摘要」小节（3～7 条）。

### E. 机器摘要（可选 JSON）

若调用方需要结构化结果，在文末附加一个 `json` 代码块，符合 `skill.spec.json` 中 `output_schema` 的 `review_result` 约定。

## 质量检查（评审完成后自检）

- [ ] 四维均有**可指向原文或脚本**的依据  
- [ ] 已区分「文档问题」与「实现问题」（并建议改文档还是改代码）  
- [ ] 未编造被评 skill 中不存在的路径、子命令或业务规则  

## 与 `generate-cursor-skill` 的关系

- 本 skill **不负责从零撰写**新 skill；若评审结论为「需重写」，可建议用户再调用 `generate-cursor-skill` 或由其作者按本评审的 P0/P1 清单改稿。
- 重写时：`description` 仍建议用英文第三人称 + 触发词，正文语言按团队约定。
- **端到端流水线**（生成 → `skill-evaluator` → 本 skill → 定稿）：`skill-build-pipeline`。

## 可扩展点

- 增加 `scripts/check_skill_paths.py`：扫描 SKILL 内反引号路径是否存在于仓库。  
- 将 `review_result` 写入 CI，对 `.cursor/skills/**/SKILL.md` 做 PR 门禁（可选）。
