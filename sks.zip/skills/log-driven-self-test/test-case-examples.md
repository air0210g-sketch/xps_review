# 日志驱动自测：测试用例示例

## 快速开始 —— 最简输入

最简使用方式：提供 trace ID + 一句话描述。

```
trace_id: spx-deliveryapi-pfb-xxx-xxx
验证 AT 创建流程正常，zone 单量分配正确
```

Agent 会自动：
1. 查询日志 → 识别模块、站点、任务 ID
2. 阅读相关源码 → 构建函数调用链
3. 执行校验 → 生成结构化报告
4. 标注需人工确认的项目

---

## 示例一：通用格式

```yaml
test_case_id: TC-001
test_purpose: "验证某功能在特定配置下的行为"
trace_id: "spx-deliveryapi-pfb-xxx-xxx-xxx"
date: "2026-02-25"
module: "delivery_assignment_task"  # 可选

configs:
  some_config_key: '{"enabled": true}'

expected:
  - "步骤A成功完成"
  - "数据正确写入DB"
  - "无ERROR日志"
```

---

## 示例二：AA 计算 —— 仅主策略

```yaml
test_case_id: AA-TC-001
test_purpose: "主策略为BizRule，对比策略池为空，主流程正常完成"
trace_id: "spx-deliveryapi-pfb-dms-dev-spxfm-213980-test-test-id-0a8728dc-492220-532695041"
date: "2026-02-25"
configs:
  main_pre_allocate_zone_order_strategy_list: '{"default_strategy":[1],"station_strategy_map":{}}'
  report_hive_pre_allocate_zone_order_strategy_list: '{"default_strategy":[],"station_strategy_map":{}}'
expected:
  - "只执行BizRule，无SmartSolution"
  - "无异步对比策略"
  - "task_status更新为3"
```

---

## 示例三：AA 计算 —— 策略解耦

```yaml
test_case_id: AA-TC-003
test_purpose: "主策略与对比策略解耦，主流程不等待对比策略"
trace_id: "spx-deliveryapi-pfb-dms-dev-spxfm-213980-test-test-id-0a8728dc-492222-934751546"
date: "2026-02-25"
configs:
  main_pre_allocate_zone_order_strategy_list: '{"default_strategy":[1],"station_strategy_map":{}}'
  report_hive_pre_allocate_zone_order_strategy_list: '{"default_strategy":[2],"station_strategy_map":{}}'
expected:
  - "BizRule同步执行完成"
  - "SmartSolution异步执行"
  - "processAutoAssignCT success 时间戳 < SmartSolution完成时间戳"
```

**校验重点**：对比时间戳以证明解耦。

---

## 示例四：AA 计算 —— ECO 站点校验

```yaml
test_case_id: AA-TC-008
test_purpose: "ECO站点策略结果校验准确，std/eco订单无误报"
trace_id: "spx-deliveryapi-pfb-dms-dev-spxfm-213980-test-test-id-0a8728dc-492223-1521133651"
date: "2026-02-25"
configs:
  main_pre_allocate_zone_order_strategy_list: '{"default_strategy":[1],"station_strategy_map":{}}'
  report_hive_pre_allocate_zone_order_strategy_list: '{"default_strategy":[1,2],"station_strategy_map":{}}'
  support_slower_eco_station_white_list: '[417474]'
expected:
  - "IsStationSupportSlowerEco: true"
  - "使用PreAllocateZonesOrderQuantityToDriversV2"
  - "verifyOrderTypeConsistency通过，无误报"
  - "task_status更新为3"
```

**需人工确认项**：
- [ ] DB：`assignment_task_zone_relation_tab` 的 std/eco 单量正确
- [ ] DB：`pre_allocated_at_result` 的 `order_cnt_detail` 正确

---

## 示例五：失败分析

```yaml
test_case_id: ERR-001
test_purpose: "分析任务失败的根因"
calculation_task_id: "ACTID2602240000GB3Z"  # 无 trace_id 时使用任务 ID
date: "2026-02-24"
expected:
  - "识别第一个错误日志和错误码"
  - "区分根因 vs 衍生错误"
```

**分析方法**：
1. 用任务 ID 搜索日志 → 找到第一条 ERROR 日志
2. 识别错误码及其含义
3. 沿调用链追踪错误传播路径
4. 区分根因与衍生症状（例如重试命中已失败的任务）

---

## 示例六：批量执行

用户可一次提供多个测试用例：

```
请验证以下三个trace：

TC-001: spx-xxx-001, 验证BizRule单策略正常
TC-002: spx-xxx-002, 验证策略解耦
TC-003: spx-xxx-003, 验证ECO站点校验
```

Agent 会逐个产出报告 + 最终汇总表。

---

## 常见错误码参考

| 错误码 | 消息 | 典型根因 |
|---|---|---|
| 143902013 | no orders in zones | CK 中没有符合条件的订单 |
| 143902005 | invalid auto-assignment task status | 任务已被其他 worker 处理 |
| 143902012 | get station event failed | 站点事件 API 调用失败 |
| 311001001 | JSON unmarshal error | JSON 解析失败 |
| 311001002 | Apollo config JSON unmarshal error | Apollo 配置格式错误 |
