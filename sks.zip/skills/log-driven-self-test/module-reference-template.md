# 模块参考生成模板

本文件是模块参考文档的**生成模板**，不直接使用。
Agent 在每次新 session 中调用自测 skill 时，应基于此模板 + 实际代码生成 `generated/module-{name}.md`。

---

## 模板结构

生成的模块参考文档应包含以下章节（按需裁剪）：

```markdown
# 模块参考：{模块中文名}（{module_directory_name}）

{一句话描述模块职责}

## MCP 配置

- **MCP 工具**: `log-mcp-test`（自测默认）/ `log-mcp`（生产）
- **Application**: `deliverytask` 或 `deliveryapi`（说明原因）
- **搜索字段**: Global-Id（trace_id）
- **备选搜索**: {模块特有的辅助 ID，如 calculation_task_id、assignment_task_id 等}

## 函数调用链

{用缩进树形图展示从入口到终点的完整调用链，标注关键分支}

## 关键日志模式

### {子类别，如"生命周期日志"}
| 日志模式 | 含义 |
|---|---|
| `[函数名] 日志内容模式` | {含义} |

### {子类别，如"错误模式"}
| 日志模式 | 含义 |
|---|---|
| `code = XXXX, message = ...` | {含义} |

## 关键 Apollo 配置键（如适用）

| 配置键 | 用途 |
|---|---|
| `namespace.key_name` | {用途} |

## 业务逻辑要点（如适用）

{配置推导逻辑、状态机转换、特殊分支条件等，帮助 agent 理解校验要点}

## 关键源码文件

| 文件 | 职责 |
|---|---|
| `{文件名}.go` | {职责} |
```

---

## 生成指引

Agent 生成模块参考时应：

1. **从入口开始** —— 找到模块的 Handler/Job/HTTP 入口，通常在 `access/` 或 `task/` 目录
2. **逐层追踪** —— 阅读 `service/impl/` 下的核心实现，记录每个函数的：
   - 函数签名和调用关系
   - `logger.CtxLogInfof/CtxLogErrorf` 日志模式
   - 错误处理和分支逻辑
3. **提取配置** —— 识别 `config.GetStringWithContext` 等 Apollo 配置读取
4. **标注关键分支** —— 特性开关、站点级覆盖、环境差异等
5. **记录错误码** —— 从 `errcode/` 目录提取模块特有的错误码

生成的文件保存至 `generated/module-{name}.md`，每次新 session 重新生成。
