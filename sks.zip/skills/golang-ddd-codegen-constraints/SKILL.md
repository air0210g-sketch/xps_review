---
name: golang-ddd-codegen-constraints
description: Use only when the user explicitly asks to generate or refactor Go code with DDD, DDD改造, 公司DDD规范, or domain-driven design constraints in this SPX repository. Do not use for ordinary Go code generation, bug fixes, tests, or reviews unless DDD is explicitly requested.
---

# Go DDD Codegen Constraints

This skill is opt-in. Use it only when the user explicitly requests DDD code generation,
DDD refactoring, DDD改造, or compliance with the company DDD specification.

## Required Context

Before generating or refactoring code, read:

- `.codex/rules/coding.md`
- `.codex/rules/testing.md` if tests are touched
- `.codex/skills/golang-ddd-spec-checker/references/ddd-spec.md`

If validating existing structure, run:

```bash
/Users/shaohua.xia/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  .codex/skills/golang-ddd-spec-checker/scripts/ddd_scan.py --repo-root .
```

Use `--module`, `--layout-root`, or `--layer-map` when the request targets one module or the
project uses non-standard layer names.

## Opt-In Guardrail

- Do not apply DDD restructuring to normal feature work unless the user explicitly says DDD.
- Do not introduce broad directory migrations while implementing a small feature.
- If the request is ambiguous, keep the existing local architecture and ask before applying DDD.
- Preserve existing behavior first; DDD shape never justifies changing business semantics silently.

## Layering Contract

Generated write paths must follow:

```text
API/Access -> Application -> Domain -> Domain Port -> Infra Adapter -> DAO/Generated Code
```

Layer responsibilities:

- API/Access: protocol adaptation, request parsing, basic validation, auth/context extraction,
  identifier normalization, response/error mapping.
- Application: one use case per method, transaction/idempotency boundary, orchestration across
  aggregates/modules, conversion between request DTOs and domain inputs.
- Domain: entities, value objects, aggregate roots, domain services, business invariants,
  domain errors, repository/gateway interfaces.
- Infra: repository/gateway implementations, DAO/PO conversion, database/cache/RPC/MQ/SDK access,
  daogen and other generated technical code.

## Hard Constraints

- `domain` must not import API, application, infra, handler, request, response, DTO, ORM, SQL,
  HTTP, gRPC, MQ, cache, or third-party SDK packages.
- `application` must not import API request/response models and must not directly access SQL,
  DAO, ORM, cache, RPC clients, MQ clients, or external SDKs.
- API/Access must not directly call repository, DAO, SQL, ORM, cache, RPC clients, MQ clients, or
  infra adapters.
- Infra must not decide whether a business action is allowed; business rules belong in domain.
- Repository interfaces belong in domain and should return domain objects, not DAO/PO structs.
- daogen, ORM, SQL DSL, and generated technical code must stay under infra or an equivalent
  infrastructure directory, separated from hand-written adapters/converters.
- Do not modify generated files by hand. Add adapter/converter code around generated code.

## Write Model Rules

- State changes must go through aggregate methods or domain services.
- Application may decide process order and transaction scope, but domain decides business validity.
- Repository saves the result of a completed domain decision; it must not replace aggregate or
  domain service logic.
- Domain errors express business failure reasons. API/application map them to protocol error codes.

## Read Model Rules

- Query paths may use DTOs or read models for simplicity and performance.
- Read optimization must not pollute domain entities with paging fields, JSON tags for protocols,
  display-only fields, or request/response types.

## Module Boundary Rules

- Prefer module-local ports over direct dependency on another module's implementation package.
- Cross-module orchestration belongs in application.
- If one module needs another module's capability, define the smallest business-facing interface
  needed by the caller and bind it through an implementation at the outer layer.
- Avoid putting module-specific logic into `common`, `util`, or `helper`.

## Code Generation Checklist

Before editing:

- Identify the target module and whether it already has layer aliases such as `access`, `service`,
  `command`, `domain`, `repository`, or `infra`.
- Reuse local naming and dependency-injection patterns when they do not violate DDD.
- Decide whether the change is a write use case, read query, infra adapter, or pure domain rule.

While editing:

- Put request/response structs near API/Access, not in domain.
- Put transaction, idempotency, and orchestration in application.
- Put invariants, status transitions, and eligibility checks in domain.
- Put persistence and external integration details in infra.
- Keep new interfaces narrow and business-semantic.

Before finishing:

- Re-run focused tests for touched packages.
- If structure changed, run the DDD scan with the narrowest practical scope.
- Report any intentional deviation and why it is safer than strict DDD in this case.
