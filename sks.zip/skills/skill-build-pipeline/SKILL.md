---
name: skill-build-pipeline
description: >-
  Orchestrates the full Cursor Skill lifecycle in this repo: generate-cursor-skill
  → draft SKILL → skill-evaluator (cases) → skill-reviewer (rewrite) → finalized
  New Skill on disk. Use when the user wants a skill quality pipeline, end-to-end
  skill authoring, or 「Skill 一条龙」.
---

# Skill Build Pipeline（Skill 一条龙）

## 目标

在本仓库内把 **编写 → 评测 → 评审 → 定稿** 串成固定顺序，减少 Agent 跳过 Eval/Review 或 handoff 丢失上下文的情况。

**流水线**（严格顺序）：

```text
Skill Generator (generate-cursor-skill)
    → Skill v1（SKILL.md [+ skill.spec.json]）
    → Eval (skill-evaluator)
    → Reviewer (skill-reviewer)
    → New Skill v2（落盘替换或同目录新版本）
```

## 何时使用

- 用户要求「skill 一条龙」「从需求到可发布 skill」「pipeline」「先写再评再改」。
- 用户已有一个 skill 草稿，希望**补跑** Eval + Reviewer 后定稿（从阶段 2 进入即可）。

## 何时不要用

- 仅需从零写 skill、不需要评测：只用 `generate-cursor-skill`。
- 仅有评审或仅有 case 评测：分别用 `skill-reviewer`、`skill-evaluator`。

## 前置约定

- **落盘目录**：`.cursor/skills/<skill-name>/`（与 `generate-cursor-skill` 一致）。
- **语言**：对用户说明用中文；`SKILL.md` frontmatter 的 `description` 仍建议英文第三人称 + 触发词（与仓库内其他 skill 一致）。

## 执行步骤（Agent 必须按序执行）

### 阶段 1 — Skill Generator

1. 读取并遵循：`.cursor/skills/generate-cursor-skill/SKILL.md`（规范实现）。
   - 若该文件不存在或内容为占位，Agent 可根据本阶段的输入收集清单（见第 2 步）手动编写 SKILL.md 初稿，遵循 Cursor Skill 规范（YAML frontmatter + 结构化正文）。
2. 向用户补齐 `purpose`、`trigger_when`、`inputs`、`outputs`、`constraints`、`examples`；缺失则提问，**禁止编造**业务规则。
3. 产出：
   - `skill.spec.json`（草稿，若用户要双轨或自动化）
   - `SKILL.md`（v1）
4. 写入：`.cursor/skills/<skill-name>/`（`skill-name` 与 frontmatter `name` 一致）。

### 阶段 2 — Skill v1（制品）

- 确认路径与 frontmatter 合法；若含 `scripts/`，路径与命令在文档中已写明。

### 阶段 3 — Eval

1. 读取并遵循：`.cursor/skills/skill-evaluator/SKILL.md`。
2. **必填**：`skill_definition` = 阶段 1 的 `SKILL.md`（`Read`）；`input_cases` = 至少 1 条，且覆盖：
   - 典型成功路径（用户会怎么说、期望 Agent 做哪几步）；
   - 一条边界或「用户没说清默认值」场景（若适用）。
3. 每条 case 尽量含 `expected_behavior`；否则按 evaluator 规则标注 **仅评定义 / inconclusive**。
4. **可选**：若已有一次真实执行，附上 `observed_output` 做对照。
5. 保存 Eval 结论中的 **`improvement_suggestions`** 与 **`skill_definition_issues`**，作为下一阶段输入。

### 阶段 4 — Reviewer

1. 读取并遵循：`.cursor/skills/skill-reviewer/SKILL.md`。
2. 输入：阶段 3 的同一 `SKILL.md`（及同目录 `skill.spec.json`、`scripts/` 若存在）。
3. 将 **Eval 的改进建议** 合并进本次评审的「上下文/任务说明」（例如用户消息中列出 P0/P1 清单），避免 Reviewer 与 Eval 结论打架。
4. 建议 **`emit_rewritten_skill=true`**，直接产出可落盘的完整新版 `SKILL.md`；若变更仅 frontmatter 一两句，可 `false` 只出表格建议，再由人工改。
5. 对 **P0（文档与代码不一致、错误路径/参数）**：必须修订至与仓库一致后再进入阶段 5。

### 阶段 5 — New Skill（定稿）

1. 以 Reviewer 输出的 **完整新版 `SKILL.md`**（若有）为权威；若无全文重写，则按 P0→P1 手动合并 evaluator + reviewer 建议到 v1。
2. **覆盖写回** `.cursor/skills/<skill-name>/SKILL.md`。
3. 若存在 `skill.spec.json`：同步更新 `input_schema` / `use_when` / 示例与正文一致（与 `generate-cursor-skill` 的双轨约定一致）。
4. 向用户交付：**变更摘要**（3～7 条）+ 最终路径列表。

## 回环（何时重跑）

| 条件 | 动作 |
|------|------|
| Eval `overall_verdict` 为 `fail` 或关键 case「不符合」 | 先按 Eval/Reviewer 改稿；大改可回到阶段 1 用 `generate-cursor-skill` 说明「在 v1 基础上按以下清单重写」 |
| Reviewer 四维中 **hallucination_risk** 为 `high` 或有 P0 | 禁止直接发布；修正文档或脚本后再从阶段 3 重跑 Eval |
| 仅措辞优化、无契约变化 | 可只做阶段 4（strictness 可选 `strict`）后落盘 |

## 质量检查（pipeline 结束自检）

- [ ] v2 `SKILL.md` 已写入目标目录，frontmatter 合法  
- [ ] Eval 的 case 在 v2 中有对应步骤或显式「不适用」说明  
- [ ] Reviewer P0 已清零或与用户确认接受风险  
- [ ] `skill.spec.json`（如有）与正文无矛盾  

## 与仓库内其他 skill 的关系

| Skill | 在流水线中的角色 |
|-------|------------------|
| `generate-cursor-skill` | 阶段 1 唯一作者规范 |
| `skill-evaluator` | 阶段 3，case 驱动是否符合预期 |
| `skill-reviewer` | 阶段 4，结构/幻觉/拆分与可选全文重写 |
| `skill-build-pipeline` | 本文件，编排顺序与 handoff |

## 示例（用户一句话触发）

> 帮我把「从日志查慢查询」做成 skill，并走完整评测评审后定稿。

Agent：阶段 1 用 `generate-cursor-skill` 落盘 → 阶段 3 准备 2 条 case（有堆栈 / 仅关键词）→ 阶段 4 `emit_rewritten_skill=true` → 阶段 5 写回并给变更摘要。
