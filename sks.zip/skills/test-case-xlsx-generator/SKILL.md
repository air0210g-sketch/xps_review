---
name: test-case-xlsx-generator
description: >-
  Generates import-style manual test cases in Excel by analyzing TD (Technical
  Design) and PRD (Product Requirements Document) via Confluence MCP, using
  test_case/import_task_execution.xlsx as the layout template and writing a new
  xlsx (optionally via scripts/write_import_task_execution_xlsx.py). Use when the
  user wants TD/PRD-driven test cases in import_task_execution format or 「import
  用例 xlsx」「从 TD 生成用例」「从 PRD 生成用例」.
---

# Test Case Import XLSX Generator（TD/PRD → import_task_execution 用例）

## 目标与边界

- **目标**：基于 **TD（技术方案）和 PRD（产品需求文档）** 的设计规格，推导可执行的**手工/导入用例**，并按固定模板输出为**新的 `.xlsx` 文件**。
- **核心输入**：TD 和 PRD 文档（Confluence 链接），通过 Confluence MCP 获取内容。
- **模板**（不可改表头与合并单元格）：仓库内 `test_case/import_task_execution.xlsx`。
- **边界**：不替代自动化单测；若文档中信息不足，须向用户索取或标注 **待确认**，**禁止编造**业务规则。

## 模板结构（权威）

| 位置 | 内容 |
|------|------|
| Sheet 名 | `info` |
| 第 1 行 | 合并区：`A1:F1` = Case info，`G1:H1` = Execution info（**勿改**） |
| 第 2 行表头 | A Name → B Pre-requisite → C Step → D Expectation → E Priority → F Jira key → G Result → H Assignee |
| 第 3 行起 | 用例行 |

**列说明**

- **Name**：用例标题，动词开头、可区分场景。
- **Pre-requisite**：数据/环境/账号/开关（无则写「无」或「默认环境」）。
- **Step**：编号步骤，可换行；与验收操作一致。
- **Expectation**：可观察结果（接口返回/UI/DB/日志关键词）；避免模糊形容词。
- **Priority**：建议 `P0` / `P1` / `P2` 或与项目约定一致。
- **Jira key**：默认填需求对应单号；无则留空并提醒补充。
- **Result / Assignee**：导入执行后再填；生成阶段可留空。

## 何时使用

- 用户提供 **TD / PRD 的 Confluence 链接** 或文档片段，要求生成测试用例。
- 用户说「从 TD 生成用例」「根据技术方案出测试用例」「PRD 生成 import xlsx」。
- 用户提供 **Jira 号 + 需求描述**，要给 **import_task_execution** 格式的测试清单。

## 何时不要用

- 只要 Markdown/表格不要 xlsx。
- 模板文件不存在或用户明确只要 Gherkin/代码用例。
- 用户只需要从代码 diff 生成用例（无 TD/PRD）—— 此场景可将 MR 说明作为补充输入，但 Skill 核心仍以 TD/PRD 为权威来源。

## 前置条件

1. **Confluence MCP** 可用于读取 TD/PRD 页面内容。
2. **Jira 号**：优先从用户输入或 TD 标题中提取；无法确定时必须询问用户，**禁止编造**。

## 执行步骤（Agent）

### 第一步：收集输入

向用户确认或提取（缺失则提问，禁止编造）：

| 输入 | 必填 | 说明 |
|------|------|------|
| TD 链接 | 是（推荐） | Confluence URL，技术方案设计文档 |
| PRD 链接 | 是（推荐） | Confluence URL，产品需求文档 |
| Jira 号 | 是 | 如 `SPXFM-223633` |
| 扫描范围 | 否 | 可限定为 TD 中的特定章节或功能域 |
| MR/代码补充 | 否 | 可选补充：MR 链接或分支名，用于交叉验证 |

至少提供 TD 和 PRD 中的一个。两者都有时效果最佳。

### 第二步：解析 TD 和 PRD

通过 Confluence MCP 读取文档，提取用例推导的关键设计信息：

**Step 2a：从 PRD 提取验收要点**

- **功能列表**：PRD 中定义的功能需求项
- **验收标准**：每个功能的验收条件
- **业务规则**：约束、流程、角色权限
- **非功能要求**：性能、兼容性、安全等

**Step 2b：从 TD 提取技术设计规格**

- **API 设计**（TD 章节 3）：接口路径、请求/响应参数、校验规则、错误码
- **数据模型**（TD 章节 2.3）：新增/变更字段、类型、约束（枚举范围、长度、必填/可选）
- **核心业务流程**（TD 章节 2.2.3）：流程图/时序图中的分支路径、异常路径
- **核心状态机**（TD 章节 2.2.5）：状态流转、触发条件
- **配置项**（TD 章节 4/5）：Apollo key、feature switch、默认值、灰度方案
- **兼容性设计**（TD 章节 5.4）：新旧版本兼容策略、回滚方案

**Step 2c：构建「设计要点清单」**

将提取的信息组织为结构化清单，作为用例推导的依据：

```
设计要点清单:
  功能域: {从 TD 功能架构提取}
  API 变更:
    - POST /api/xxx/create: 新增参数 field_a(枚举:0/1/2), field_b(整数:1-10)
    - PUT /api/xxx/update: 新增校验规则...
  数据模型变更:
    - table_xxx 新增字段: field_a(tinyint), field_b(int)
  业务规则:
    - 规则1: 当 field_a=0 时，field_b 使用默认值 1
    - 规则2: ...
  状态流转:
    - 新增状态 X → Y 的触发条件
  配置项:
    - apollo_key_xxx: 功能开关，默认关闭
  兼容性:
    - 旧版本不传 field_a 时走默认值
```

### 第三步：推导用例矩阵

基于设计要点清单，按五维矩阵逐一推导用例：

| 维度 | 推导来源 | 推导方法 | 典型场景 |
|------|---------|---------|---------|
| **正向** | PRD 验收标准 + TD API/流程 | 每个功能的主路径成功执行 | 正常创建 → 新字段正确持久化；主流程端到端通过 |
| **边界** | TD 数据模型字段约束 | 枚举边界值、数值上下限、空值、零值 | 整数字段 min=1/max=10 → 测 0、1、10、11 |
| **异常** | TD API 错误码 + 校验规则 | 非法输入、权限不足、依赖不可用 | 非法枚举值 → 校验拒绝；缺少必填字段 → 错误码 |
| **兼容/回归** | TD 兼容性设计 | 不传新字段时旧逻辑不受影响 | 旧版本客户端不传新字段 → 走默认值 |
| **配置/灰度** | TD 灰度方案 + 配置项 | 开关 on/off、灰度名单内/外 | 功能开关关闭 → 走旧逻辑；灰度白名单外 → 不生效 |

**用例生成规则**：

- 每个 PRD **验收标准**至少一条正向用例
- TD 中每个 **API 接口**至少覆盖：正常调用 + 参数缺失 + 非法参数
- 枚举类型字段：每个合法值至少 1 条正向 + 至少 1 条非法值异常
- 数值范围字段：min-1、min、中间值、max、max+1（5 条边界）
- 布尔/开关字段：on + off 各至少 1 条
- TD 状态机中每条**状态流转路径**至少 1 条用例
- 组合条件（如「灰度开关 AND 配置 A」）：列出关键组合，避免全排列爆炸

**示例（SPXFM-223633 Config CRUD）**：
```
从 TD 提取设计要点:
  API: POST /api/route_match/config/create, PUT /api/route_match/config/update
  数据模型: route_match_driver_config_tab 新增 3 个字段:
    - reallocate_to_declined_drivers (tinyint, 枚举: 0/1/2)
    - auto_decline_call_up_time (int, 范围: 1-10, 默认 1)
    - prioritize_single_shift_ids (varchar, 逗号分隔 event ID)
  校验规则:
    - auto_decline_call_up_time 传 0 时自动设为默认值 1
    - auto_decline_call_up_time 超出 1-10 范围 → 拒绝
  兼容性: 不传新字段 → 走默认值

推导用例:
  正向: Create 含新字段 → 3 个新字段正确持久化; Update 新字段 → 值更新成功
  边界: auto_decline_call_up_time=0 → 自动设为默认值 1
        auto_decline_call_up_time=1 → 最小合法值
        auto_decline_call_up_time=10 → 最大合法值
  异常: auto_decline_call_up_time=11 → 校验拒绝
        reallocate_to_declined_drivers=99 → 非法枚举值拒绝
  兼容: 不传新字段 → 走默认值，旧逻辑不受影响
  配置: 灰度开关关闭 → 新字段不生效（若 TD 有灰度方案）
```

### 第四步：编写用例行

- 每条对应一行；Step 与 Expectation 可追踪到 TD/PRD 原文（用「参见 TD 3.1 ××接口」避免冗长）。
- 对于从 TD 状态机或流程图推导的用例，在 Pre-requisite 中注明需要的前置状态。

### 第五步：生成 xlsx（推荐脚本，避免手改损坏格式）

在工作区根目录执行（路径相对于仓库根）：

```bash
# 先写入 cases.json（UTF-8），再生成新文件
python3 .cursor/skills/test-case-import-xlsx-generator/scripts/write_import_task_execution_xlsx.py \
  --template test_case/import_task_execution.xlsx \
  --output test_case/import_task_execution_<JIRA或简述>.xlsx \
  --cases /path/to/cases.json
```

依赖：`pip install openpyxl`（若环境无 openpyxl）。

### 第六步：命名建议

- `test_case/import_task_execution_<JIRA>.xlsx` 或 `test_case/import_task_execution_<YYYYMMDD>_<feature_slug>.xlsx`。

### 第七步：交付

- 回复中说明：输出路径、用例条数、覆盖维度（正向/边界/异常/兼容/配置各多少条）。
- 列出 **待确认**（若有）：TD/PRD 中不明确的规则、缺失的约束信息。
- 附上 **设计要点清单**摘要，供用户确认用例推导依据是否正确。

## cases.json 格式

与 `scripts/write_import_task_execution_xlsx.py` 一致：

```json
{
  "default_jira_key": "SPXFM-00000",
  "cases": [
    {
      "name": "示例-主流程成功",
      "pre_requisite": "测试环境；相关开关开启",
      "step": "1. …\n2. …",
      "expectation": "…可验证现象…",
      "priority": "P1",
      "jira_key": "",
      "result": "",
      "assignee": ""
    }
  ]
}
```

单条 `jira_key` 为空时使用 `default_jira_key`。

## cases.json 真实产出示例

以下为 SPXFM-228110 Config CRUD 相关的真实 cases.json 片段（完整版见 `test_case/cases_MR17137_SPXFM-228110.json`）：

```json
{
  "default_jira_key": "SPXFM-228110",
  "cases": [
    {
      "name": "Config Create - 正常创建含新字段",
      "pre_requisite": "测试环境；station_id=1 无已有配置",
      "step": "1. POST /api/route_match/config/create\n2. body 包含 reallocate_to_declined_drivers=1, auto_decline_call_up_time=5",
      "expectation": "1. retcode=0\n2. DB route_match_driver_config_tab 中新字段值正确",
      "priority": "P1",
      "jira_key": "",
      "result": "",
      "assignee": ""
    },
    {
      "name": "Config Create - auto_decline_call_up_time 超出上限",
      "pre_requisite": "测试环境",
      "step": "1. POST /api/route_match/config/create\n2. body 中 auto_decline_call_up_time=11",
      "expectation": "1. retcode=参数错误码\n2. 错误信息包含 auto_decline_call_up_time",
      "priority": "P1",
      "jira_key": "",
      "result": "",
      "assignee": ""
    }
  ]
}
```

## 本仓库已有产出参考

| 需求 | cases.json | xlsx 输出 |
|------|-----------|----------|
| SPXFM-228110 | `test_case/cases_MR17137_SPXFM-228110.json` | `test_case/import_task_execution_MR17137_SPXFM-228110.xlsx` |
| SPXFM-232348 | `test_case/cases_MR17263_SPXFM-232348.json` | `test_case/import_task_execution_MR17263_SPXFM-232348.xlsx` |

## 质量检查（生成后自检）

- [ ] 新文件为**复制模板**后写入，第 1～2 行未被覆盖
- [ ] 每条用例 **Name + Step + Expectation** 齐全
- [ ] 无模板未列的额外列；不合并数据区单元格
- [ ] 用例可追溯到 TD/PRD 原文（Step 或 Pre-requisite 中标注来源章节）
- [ ] 五维矩阵覆盖完整：正向/边界/异常/兼容/配置各维度均有用例
- [ ] TD 中每个 API 接口至少有正常/异常/缺参三类用例
- [ ] TD 状态机中每条流转路径至少 1 条用例（若有状态机设计）
- [ ] 枚举字段覆盖所有合法值 + 至少 1 个非法值
- [ ] 数值范围字段覆盖 min-1/min/max/max+1 边界
- [ ] 脚本执行成功或说明无法安装 openpyxl 时的**手工粘贴**降级步骤

## 与仓库其他 Skill 的关系

| Skill | 关系 |
|-------|------|
| **tc-implementation-mapper** | 互补：本 skill 从 TD/PRD 生成用例 → tc-implementation-mapper 将用例映射到代码实现 |
| **integration-test-generator** | 互补：本 skill 生成手工用例 → integration-test-generator 将其中适合自动化的 TC 生成集成测试 |
| **log-driven-self-test** | 互补：本 skill 定义「测什么」→ log-driven-self-test 验证「测通了没」 |

## 与 skill-build-pipeline 的关系

- 本 skill 可作为独立能力调用；若用户要求「按流水线评审」，继续执行 `skill-build-pipeline` 中的 Eval（准备 case：`skill-evaluator`）与 Review（`skill-reviewer`）以收紧描述与幻觉风险。

## 示例

**用户**：「这是 SPXFM-223633 的 TD: https://confluence.xxx/xxx，PRD: https://confluence.xxx/yyy，帮我生成 import xlsx。」

**Agent**：通过 Confluence MCP 读取 TD/PRD → 提取 API 设计（Config CRUD 接口）、数据模型（3 个新字段）、校验规则、兼容性设计 → 按五维矩阵推导用例 → 写 `cases.json` → 运行 `write_import_task_execution_xlsx.py` → 输出 `test_case/import_task_execution_SPXFM-223633.xlsx` 并附设计要点清单。
