#!/usr/bin/env python3
"""Write test cases to a copy of import_task_execution.xlsx template.

Template layout (sheet ``info``):
  Row 1: merged headers (do not modify)
  Row 2: Name | Pre-requisite | Step | Expectation | Priority | Jira key | Result | Assignee
  Row 3+: data rows

Usage:
  python3 write_import_task_execution_xlsx.py \\
    --template test_case/import_task_execution.xlsx \\
    --output test_case/import_task_execution_SPXFM-1.xlsx \\
    --cases cases.json

cases.json:
{
  "default_jira_key": "SPXFM-1",
  "cases": [
    {
      "name": "short title",
      "pre_requisite": "env / data",
      "step": "1. ...\\n2. ...",
      "expectation": "observable result",
      "priority": "P1",
      "jira_key": "",
      "result": "",
      "assignee": ""
    }
  ]
}
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path


def _require_openpyxl():
    try:
        from openpyxl import load_workbook  # noqa: F401
    except ImportError as e:
        print("Missing dependency: openpyxl. Install with: pip install openpyxl", file=sys.stderr)
        raise SystemExit(2) from e


def main() -> None:
    _require_openpyxl()
    from openpyxl import load_workbook

    ap = argparse.ArgumentParser(description="Fill import_task_execution-style xlsx from JSON cases.")
    ap.add_argument(
        "--template",
        default="test_case/import_task_execution.xlsx",
        help="Path to template xlsx (repo-relative or absolute).",
    )
    ap.add_argument("--output", required=True, help="Output xlsx path.")
    ap.add_argument("--cases", required=True, help="JSON file with default_jira_key + cases[].")
    args = ap.parse_args()

    template = Path(args.template).resolve()
    output = Path(args.output).resolve()
    cases_path = Path(args.cases).resolve()

    if not template.is_file():
        print(f"Template not found: {template}", file=sys.stderr)
        raise SystemExit(1)

    payload = json.loads(cases_path.read_text(encoding="utf-8"))
    default_jira = (payload.get("default_jira_key") or "").strip()
    rows = payload.get("cases") or []
    if not rows:
        print("cases[] is empty", file=sys.stderr)
        raise SystemExit(1)

    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template, output)

    wb = load_workbook(output)
    if "info" not in wb.sheetnames:
        print("Sheet 'info' missing in template", file=sys.stderr)
        raise SystemExit(1)
    ws = wb["info"]

    def next_data_row() -> int:
        for r in range(3, ws.max_row + 1):
            v = ws.cell(row=r, column=1).value
            if v is None or (isinstance(v, str) and not v.strip()):
                return r
        return ws.max_row + 1

    r = next_data_row()
    for item in rows:
        jira = (item.get("jira_key") or default_jira or "").strip()
        ws.cell(row=r, column=1, value=item.get("name") or "")
        ws.cell(row=r, column=2, value=item.get("pre_requisite") or "")
        ws.cell(row=r, column=3, value=item.get("step") or "")
        ws.cell(row=r, column=4, value=item.get("expectation") or "")
        ws.cell(row=r, column=5, value=item.get("priority") or "")
        ws.cell(row=r, column=6, value=jira)
        ws.cell(row=r, column=7, value=item.get("result") or "")
        ws.cell(row=r, column=8, value=item.get("assignee") or "")
        r += 1

    wb.save(output)
    print(f"Wrote {len(rows)} case(s) to {output}")


if __name__ == "__main__":
    main()
