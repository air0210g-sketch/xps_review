#!/usr/bin/env python3
"""Scan Go repositories for silent truncation risks and emit an HTML report."""

from __future__ import annotations

import argparse
import html
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ASSIGN_SLICE_RE = re.compile(
    r"(?P<lhs>[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)?)\s*=\s*(?P=lhs)\s*\[\s*(?P<start>[^\]:]*)\s*:\s*(?P<end>[^\]]*)\s*\]"
)

RETURN_ERROR_RE = re.compile(
    r"\breturn\b.*(\berr\b|Errorf|NewError|errors\.New|nil\s*,\s*[^,\n]*(?:err|Err|Error))"
)

BUSINESS_HINTS = (
    "order",
    "shipment",
    "driver",
    "route",
    "address",
    "agency",
    "payment",
    "toll",
    "tax",
    "report",
    "export",
    "recipient",
    "fleet",
    "cod",
    "fee",
    "list",
    "ids",
)

LOW_RISK_PATH_HINTS = (
    "_test.go",
    "/test/",
    "/tests/",
    "/vendor/",
    "/mock/",
    "/mocks/",
    "panic",
    "stack",
    "debug",
)

SAFE_CONTEXT_HINTS = (
    "too many",
    "exceed",
    "exceeds",
    "超过",
    "超出",
    "invalid",
    "return error",
    "return err",
)


@dataclass
class Finding:
    severity: str
    file: str
    line: int
    variable: str
    code: str
    reason: str
    suggestion: str
    context: str


def repo_files(repo: Path, include_tests: bool) -> list[Path]:
    try:
        result = subprocess.run(
            ["rg", "--files", "-g", "*.go"],
            cwd=repo,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        files = [repo / line for line in result.stdout.splitlines() if line.strip()]
    except (FileNotFoundError, subprocess.CalledProcessError):
        files = [p for p in repo.rglob("*.go") if ".git" not in p.parts]

    if include_tests:
        return files
    return [p for p in files if not p.name.endswith("_test.go")]


def line_window(lines: list[str], idx: int, before: int = 5, after: int = 8) -> tuple[str, str]:
    start = max(0, idx - before)
    end = min(len(lines), idx + after + 1)
    before_after = "\n".join(lines[start:end])
    numbered = []
    for pos in range(start, end):
        numbered.append(f"{pos + 1}: {lines[pos].rstrip()}")
    return before_after, "\n".join(numbered)


def classify(rel_file: str, variable: str, code: str, raw_context: str) -> tuple[str, str, str]:
    lower_blob = f"{rel_file}\n{variable}\n{code}\n{raw_context}".lower()
    next_lines = "\n".join(raw_context.splitlines()[5:])

    if any(hint in lower_blob for hint in LOW_RISK_PATH_HINTS):
        return (
            "Low",
            "更像测试、调试、panic stack 或辅助代码中的截断，通常不是核心业务静默丢数据。",
            "确认该截断不会进入业务结果；如仅用于展示或日志，建议在注释或变量名中标明。",
        )

    has_error_return = bool(RETURN_ERROR_RE.search(next_lines))
    has_safe_context = any(hint in lower_blob for hint in SAFE_CONTEXT_HINTS)
    has_business_hint = any(hint in lower_blob for hint in BUSINESS_HINTS)
    has_logging_only = any(token in lower_blob for token in ("log", "warn", "overload", "ignore", "drop"))

    if has_error_return and has_safe_context:
        return (
            "Safe-ish",
            "同一上下文中存在超限或非法输入错误返回，静默风险较低，但仍需确认截断前没有副作用。",
            "保持先校验再处理；若当前已经先查询或写入，再返回错误，应调整顺序。",
        )

    if has_business_hint and not has_error_return:
        return (
            "High",
            "业务相关数据被截断后继续处理，附近未发现明确 error 返回，容易造成调用方以为处理了完整输入。",
            "超过限制时返回明确错误，或改成显式分批处理并合并结果；不要无声丢弃尾部数据。",
        )

    if has_logging_only and not has_error_return:
        return (
            "Medium",
            "代码记录了日志或 ignore/overload 信息，但主流程可能仍以截断数据继续执行。",
            "让调用方感知被截断的事实；必要时把截断结果放入响应或改成失败返回。",
        )

    return (
        "Medium",
        "发现 slice/string 被重新赋值为子区间，需要人工确认这是否是业务窗口还是静默截断。",
        "打开上下文判断是否应返回错误、分批处理，或在报告/日志中显式说明只保留部分数据。",
    )


def scan_file(path: Path, repo: Path) -> Iterable[Finding]:
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        text = path.read_text(encoding="utf-8", errors="replace")

    rel_file = path.relative_to(repo).as_posix()
    lines = text.splitlines()
    for idx, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            continue
        match = ASSIGN_SLICE_RE.search(line)
        if not match:
            continue

        start_expr = match.group("start").strip()
        end_expr = match.group("end").strip()
        if start_expr and end_expr and start_expr not in ("0", ""):
            # Middle-window slicing is often parser/window logic; keep only explicit reassign truncations.
            if not any(hint in stripped.lower() for hint in BUSINESS_HINTS):
                continue

        raw_context, numbered_context = line_window(lines, idx)
        severity, reason, suggestion = classify(rel_file, match.group("lhs"), stripped, raw_context)
        yield Finding(
            severity=severity,
            file=rel_file,
            line=idx + 1,
            variable=match.group("lhs"),
            code=stripped,
            reason=reason,
            suggestion=suggestion,
            context=numbered_context,
        )


def severity_rank(severity: str) -> int:
    return {"High": 0, "Medium": 1, "Safe-ish": 2, "Low": 3}.get(severity, 9)


def render_html(repo: Path, findings: list[Finding]) -> str:
    counts = {name: sum(1 for item in findings if item.severity == name) for name in ("High", "Medium", "Safe-ish", "Low")}
    rows = []
    for item in sorted(findings, key=lambda x: (severity_rank(x.severity), x.file, x.line)):
        rows.append(
            f"""
            <tr class="sev-{html.escape(item.severity.lower().replace('-ish', 'ish'))}">
              <td><span class="badge">{html.escape(item.severity)}</span></td>
              <td><code>{html.escape(item.file)}:{item.line}</code></td>
              <td><code>{html.escape(item.variable)}</code></td>
              <td><pre>{html.escape(item.code)}</pre></td>
              <td>{html.escape(item.reason)}</td>
              <td>{html.escape(item.suggestion)}</td>
              <td><details><summary>查看上下文</summary><pre>{html.escape(item.context)}</pre></details></td>
            </tr>
            """
        )

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>静默截断 Bug 扫描报告</title>
  <style>
    :root {{
      color-scheme: light;
      --text: #202124;
      --muted: #5f6368;
      --border: #dadce0;
      --high: #b3261e;
      --medium: #b06000;
      --safe: #146c43;
      --low: #3c4043;
      --bg: #f8fafd;
      --panel: #ffffff;
    }}
    body {{
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--text);
      background: var(--bg);
    }}
    header {{
      padding: 28px 36px 20px;
      background: var(--panel);
      border-bottom: 1px solid var(--border);
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 26px;
      letter-spacing: 0;
    }}
    .meta {{
      color: var(--muted);
      font-size: 14px;
    }}
    .summary {{
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      margin-top: 18px;
    }}
    .card {{
      min-width: 112px;
      padding: 12px 14px;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: #fff;
    }}
    .card strong {{
      display: block;
      font-size: 24px;
    }}
    main {{
      padding: 24px 36px 40px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
    }}
    th, td {{
      border-bottom: 1px solid var(--border);
      padding: 12px;
      text-align: left;
      vertical-align: top;
      font-size: 13px;
    }}
    th {{
      background: #eef3f8;
      color: #303134;
      position: sticky;
      top: 0;
      z-index: 1;
    }}
    tr:last-child td {{
      border-bottom: 0;
    }}
    code, pre {{
      font-family: "SFMono-Regular", Consolas, monospace;
    }}
    pre {{
      white-space: pre-wrap;
      margin: 0;
      max-width: 520px;
    }}
    details pre {{
      margin-top: 8px;
      max-width: 760px;
      background: #f6f8fa;
      padding: 10px;
      border-radius: 6px;
    }}
    .badge {{
      display: inline-block;
      min-width: 66px;
      text-align: center;
      padding: 4px 8px;
      border-radius: 999px;
      color: #fff;
      font-weight: 650;
      font-size: 12px;
    }}
    .sev-high .badge {{ background: var(--high); }}
    .sev-medium .badge {{ background: var(--medium); }}
    .sev-safeish .badge {{ background: var(--safe); }}
    .sev-low .badge {{ background: var(--low); }}
    .note {{
      max-width: 920px;
      margin: 0 0 18px;
      color: var(--muted);
      line-height: 1.6;
    }}
  </style>
</head>
<body>
  <header>
    <h1>静默截断 Bug 扫描报告</h1>
    <div class="meta">仓库：<code>{html.escape(str(repo))}</code></div>
    <div class="summary">
      <div class="card"><strong>{counts["High"]}</strong>High</div>
      <div class="card"><strong>{counts["Medium"]}</strong>Medium</div>
      <div class="card"><strong>{counts["Safe-ish"]}</strong>Safe-ish</div>
      <div class="card"><strong>{counts["Low"]}</strong>Low</div>
      <div class="card"><strong>{len(findings)}</strong>Total</div>
    </div>
  </header>
  <main>
    <p class="note">本报告由静态启发式扫描生成，重点寻找 slice/string 被直接截短后继续使用、且附近没有明确错误返回的代码。结果需要结合业务上下文人工复核。</p>
    <table>
      <thead>
        <tr>
          <th>风险</th>
          <th>位置</th>
          <th>变量</th>
          <th>截断代码</th>
          <th>风险理由</th>
          <th>建议</th>
          <th>上下文</th>
        </tr>
      </thead>
      <tbody>
        {''.join(rows) if rows else '<tr><td colspan="7">未发现候选截断点。</td></tr>'}
      </tbody>
    </table>
  </main>
</body>
</html>
"""


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Scan Go code for silent truncation risks.")
    parser.add_argument("--repo", default=".", help="Go repository path. Defaults to current directory.")
    parser.add_argument("--output", default=None, help="HTML output path. Defaults to <repo>/truncation-risk-report.html.")
    parser.add_argument("--include-tests", action="store_true", help="Include *_test.go files.")
    parser.add_argument("--open", action="store_true", help="Open the report with the system default browser.")
    args = parser.parse_args(argv)

    repo = Path(args.repo).expanduser().resolve()
    if not repo.exists() or not repo.is_dir():
        raise SystemExit(f"repo path does not exist or is not a directory: {repo}")

    output = Path(args.output).expanduser().resolve() if args.output else repo / "truncation-risk-report.html"

    findings: list[Finding] = []
    for file_path in repo_files(repo, args.include_tests):
        findings.extend(scan_file(file_path, repo))

    output.write_text(render_html(repo, findings), encoding="utf-8")
    print(f"wrote {output}")
    print(f"findings: {len(findings)}")
    for severity in ("High", "Medium", "Safe-ish", "Low"):
        print(f"{severity}: {sum(1 for item in findings if item.severity == severity)}")

    if args.open:
        if sys.platform == "darwin":
            subprocess.run(["open", str(output)], check=False)
        elif os.name == "nt":
            os.startfile(output)  # type: ignore[attr-defined]
        else:
            subprocess.run(["xdg-open", str(output)], check=False)

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
