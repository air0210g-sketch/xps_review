---
name: silent-truncation-bug-scan
description: 扫描 Go 代码仓库中“静默截断”类潜在 Bug：例如 slice/string/list 被截短后继续处理、无 error 返回、无显式告警或仅记录日志。适用于用户要求检测静默截断、数据被悄悄裁剪、批量参数被截断、生成 HTML 风险列表、复用刚才的截断检测流程，或对 delivery-service、lm-route 等 Go 仓库做同类扫描。
---

# 静默截断 Bug 扫描

## 工作流

1. 先确认目标仓库路径，默认使用当前工作目录。
2. 运行脚本生成候选列表：

```bash
python ~/.codex/skills/silent-truncation-bug-scan/scripts/scan_silent_truncation.py --repo <repo-path> --output <repo-path>/truncation-risk-report.html
```

3. 打开 HTML 报告时优先使用：

```bash
open <repo-path>/truncation-risk-report.html
```

4. 人工复核高风险和中风险项。脚本是静态启发式扫描，必须结合上下文判断是否属于真实业务风险。

## 扫描重点

重点关注以下模式：

- `x = x[:limit]`、`x = x[0:limit]`、`x = x[start:end]` 后继续使用，没有返回 error。
- 批量请求参数、订单号、运单号、司机 ID、地址字段、route stop、导出内容、报表内容被截短。
- 只记录日志、只写 overload/ignore list、只发告警，但主流程仍以截断后的数据继续成功返回。
- 字符串字段为了满足长度限制被直接裁剪，导致入库、对账、支付、税务、报表数据与原始业务数据不一致。

## 复核标准

按以下口径输出结论：

- `High`：截断影响核心业务输入或持久化数据，调用方没有收到 error，后续逻辑以截断数据继续执行。
- `Medium`：截断可能影响部分结果、日志、报表、异步记录或调度路径，但代码里有一定补偿、记录或场景较窄。
- `Low`：主要是 debug、panic stack、测试、展示层、无调用工具函数，或已有明确错误返回。
- `Safe-ish`：代码确实截断，但同一分支很快返回 exceed/invalid error；仍需留意是否已经发起部分副作用。

报告里需要保留文件路径、行号、代码片段、风险理由和建议修复方向。

## 修复建议模板

优先建议以下修复方式：

- 对核心输入：超过限制时返回明确错误，不要静默裁剪。
- 对必须分批的请求：改成显式分批处理并合并结果，保证输入全集被处理。
- 对字段长度限制：在上游校验并返回可解释错误；确实必须截断时，保留原始值、记录原因，并避免影响对账或幂等 key。
- 对日志或报告：报告中明确标记“仅展示前 N 条”，不要让调用方误以为是完整结果。

## 注意事项

- 不要把队列 pop、分页窗口、parser 消费 buffer、panic stack 裁剪直接当作业务 Bug。
- 不要只依赖脚本分级；高价值结论需要打开代码上下文复核。
- 如果用户要求“用浏览器打开”，生成报告后使用系统 `open` 或可用的浏览器插件打开本地 HTML。
