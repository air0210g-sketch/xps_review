# DDD 检查口径

需要更细的检查口径、命令提示或输出模板时再读本文件。

## 结论分级

- `不符合项`：有明确代码证据，已经违反 `references/ddd-spec.md` 的依赖方向或职责边界。
- `风险项`：线索很强，但还需要补读一两个核心文件才能下结论。
- `待确认项`：目录命名特殊、公共包过多、或扫描范围受限，当前只能提示疑点。

不要把“目录不好看”“命名不统一”单独当成不符合项。

## 标准结构与大模块结构

- 标准结构：默认检查整个项目。
- 大模块结构且用户指定模块：只深查该模块内部四层，并顺手看它是否依赖其他大模块。
- 大模块结构且用户未指定模块：只做全局粗扫，不逐个深读所有模块内部实现。
- 不要把 `internal` 当成硬编码前提；只要某个目录下呈现四层或大模块再套四层的关系，就可以把它视为分层根目录。
- 不要把 `api/application/domain/infra` 当成硬编码前提；如果层名是 `access`、`usecase`、`model`、`persistence` 之类，先按角色理解，再判断依赖是否合理。
- 如果自动识别出的分层根目录不合理，改用 `--layout-root <path>` 手动指定。
- 如果自动推断出的层角色不合理，改用 `--layer-map <dir>=<role>` 手动指定。

大模块全局粗扫时，重点回答：

- 有哪些大模块
- 是否存在明显跨大模块依赖
- 哪个模块最值得优先深入

## 推荐命令

先跑静态扫描：

```bash
python3 <skill-dir>/scripts/ddd_scan.py --repo-root .
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --module order
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --layout-root apps --module order
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --layout-root apps --layer-map access=api --layer-map usecase=application --layer-map model=domain --layer-map persistence=infra --module order
```

这里的 `<skill-dir>` 指 skill 自身目录，不是目标仓库目录。
把 `<layout-root>` 理解为脚本输出里的 `Layout root`。如果输出是 `.`，表示分层就放在项目根目录。
脚本只读本地源码和 `go.mod`，不会去解析或下载私有依赖。
把 `--layer-map` 理解为“把自定义目录名映射回标准层角色”，用于修正脚本推断不准的场景。

需要补证据时，再按问题类型查：

```bash
rg -n 'request|response|dto|handler|controller' <domain-layer-path>
rg -n 'gorm|sqlx|database/sql|grpc|http\\.Client|redis|kafka|mq' <domain-layer-path> <application-layer-path> <api-layer-path>
rg -n 'Create|Update|Delete|Save|Exec|Insert|Upsert' <api-layer-path> <application-layer-path>
rg -n 'type .*Repository interface|type .*Gateway interface' <domain-layer-path>
rg -n 'BeginTx|WithinTx|Transaction|Tx' <application-layer-path>
```

这里的 `<api-layer-path>`、`<application-layer-path>`、`<domain-layer-path>` 指的是“角色路径”，不一定和目录名完全一致。先看脚本输出的层别名映射，再代入实际路径。

命令只用于缩小阅读范围，不直接等于结论。

## 高优先级问题

下面这些通常可以直接判为 `不符合项`：

- `domain` import `api`、`application`、`infra`
- `application` import `api`
- `api` 直接访问 repository、DAO、SQL、ORM、缓存、RPC client
- `domain` 直接依赖 ORM、数据库、HTTP、gRPC、MQ、第三方 SDK
- 大模块结构下，一个大模块直接 import 另一个大模块的实现包

## 需要读代码再定的问题

下面这些通常先记为 `风险项`，读完关键链路后再升级或降级：

- `api` 直接 import `domain`
- `common/util/helper` 被多个层共同使用
- `application` 中出现大量 if/else 状态判断、资格判断、业务错误拼装
- `infra` 中出现“是否允许执行”之类的业务判断

## 写路径检查

至少抽 1 到 3 条写用例做链路追踪：

1. 找入口 handler 或 consumer。
2. 找 application service 是否负责事务、幂等、编排。
3. 找 domain aggregate 或 domain service 是否负责状态流转和业务不变量。
4. 找 repository 是否只是持久化结果，而不是替代领域做决策。

如果核心状态变化主要发生在 repository、DAO、SQL 模板、handler，通常应判为 `不符合项`。

## 输出模板

建议按下面结构输出：

```text
检查范围：
结构判断：

不符合项：
1. ...

风险项：
1. ...

待确认项：
1. ...

建议下一步：
```

如果本轮是大模块全局粗扫，`建议下一步` 只需要写“优先深查哪个模块”。
