#!/usr/bin/env python3

import argparse
import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path

LAYER_NAMES = ("api", "application", "domain", "infra")
EXCLUDE_SEGMENTS = {"mock", "mocks", "testdata"}
WRAPPER_ROOT_HINTS = {"internal", "app", "apps", "src", "pkg", "service", "services"}
SKIP_WALK_DIRS = {
    ".git",
    ".idea",
    ".vscode",
    ".codex",
    ".cursor",
    "vendor",
    "node_modules",
    "third_party",
    "__pycache__",
}
ROLE_HINTS = {
    "api": {
        "api": 5,
        "access": 5,
        "controller": 4,
        "controllers": 4,
        "handler": 4,
        "handlers": 4,
        "router": 4,
        "routers": 4,
        "route": 4,
        "routes": 4,
        "transport": 3,
        "delivery": 3,
        "entry": 2,
        "endpoint": 3,
        "endpoints": 3,
        "interface": 2,
        "interfaces": 2,
        "http": 2,
        "grpc": 2,
    },
    "application": {
        "application": 5,
        "app": 3,
        "service": 3,
        "services": 3,
        "usecase": 5,
        "usecases": 5,
        "use": 1,
        "case": 1,
        "command": 3,
        "commands": 3,
        "query": 3,
        "queries": 3,
        "workflow": 2,
        "workflows": 2,
    },
    "domain": {
        "domain": 5,
        "model": 4,
        "models": 4,
        "core": 3,
        "entity": 4,
        "entities": 4,
        "aggregate": 4,
        "aggregates": 4,
        "value": 2,
        "vo": 2,
        "spec": 2,
        "biz": 2,
        "business": 2,
    },
    "infra": {
        "infra": 5,
        "infrastructure": 5,
        "persistence": 5,
        "persistent": 4,
        "repository": 4,
        "repositories": 4,
        "repo": 4,
        "repos": 4,
        "dao": 4,
        "dal": 4,
        "gateway": 3,
        "gateways": 3,
        "client": 3,
        "clients": 3,
        "adapter": 2,
        "adapters": 2,
        "store": 3,
        "storage": 3,
        "mysql": 2,
        "redis": 2,
        "rpc": 2,
    },
}
TRANSPORT_IMPORT_PREFIXES = (
    "net/http",
    "google.golang.org/grpc",
    "github.com/gin-gonic/gin",
    "github.com/labstack/echo",
    "github.com/gofiber/fiber",
    "github.com/gorilla/mux",
    "github.com/go-chi/chi",
)
INFRA_IMPORT_PREFIXES = (
    "database/sql",
    "gorm.io/",
    "entgo.io/",
    "github.com/jmoiron/sqlx",
    "go.mongodb.org/",
    "github.com/go-redis/",
    "github.com/redis/",
    "github.com/segmentio/kafka-go",
    "github.com/IBM/sarama",
    "github.com/streadway/amqp",
    "github.com/apache/rocketmq",
    "github.com/aws/",
    "github.com/aliyun/",
    "cloud.google.com/go/",
)
TECH_IMPORT_RULES = {
    "domain": (
        *INFRA_IMPORT_PREFIXES,
        *TRANSPORT_IMPORT_PREFIXES,
    ),
    "application": INFRA_IMPORT_PREFIXES,
    "api": INFRA_IMPORT_PREFIXES,
}
DIRECT_IMPORT_RULES = (
    ("domain", {"api", "application", "infra"}, "high", "domain depends on an outer layer"),
    ("application", {"api"}, "high", "application depends on api"),
    ("api", {"infra"}, "high", "api depends on infra"),
    ("api", {"domain"}, "medium", "api may be bypassing application"),
)


@dataclass
class RawPackage:
    import_path: str
    rel_path: str
    imports: list[str]
    go_files: list[str]


@dataclass
class GroupProfile:
    name: str
    package_paths: set[str] = field(default_factory=set)
    go_files: set[str] = field(default_factory=set)
    imports: set[str] = field(default_factory=set)
    outgoing_groups: set[str] = field(default_factory=set)
    incoming_groups: set[str] = field(default_factory=set)
    modules: set[str] = field(default_factory=set)


@dataclass
class LayoutCandidate:
    root: str
    structure: str
    direct_role_map: dict[str, str]
    module_role_map: dict[str, str]
    big_modules: list[str]
    package_count: int
    relevant_package_count: int
    score: int


@dataclass
class LayoutSelection:
    root: str
    structure: str
    direct_role_map: dict[str, str]
    module_role_map: dict[str, str]
    big_modules: list[str]
    mode: str
    candidates: list[LayoutCandidate]


@dataclass
class PackageInfo:
    import_path: str
    rel_path: str
    layout_root: str
    layer: str | None
    big_module: str | None
    layer_source: str | None
    go_files: list[str]
    is_wiring_package: bool
    local_imports: list[str]
    tech_imports: list[str]


def build_rel_path(import_path: str, module_path: str) -> str:
    prefix = module_path + "/"
    if import_path == module_path:
        return "."
    if import_path.startswith(prefix):
        return import_path[len(prefix) :]
    return import_path


def split_under_root(rel_path: str, layout_root: str) -> list[str] | None:
    rel_parts = rel_path.split("/")
    if layout_root == ".":
        return rel_parts

    root_parts = layout_root.split("/")
    if rel_parts[: len(root_parts)] != root_parts:
        return None
    return rel_parts[len(root_parts) :]


def read_module_path(repo_root: Path) -> str | None:
    go_mod = repo_root / "go.mod"
    if not go_mod.exists():
        return None

    for line in go_mod.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("module "):
            return stripped[len("module ") :].strip()
    return None


def strip_go_comments(source: str) -> str:
    source = re.sub(r"//.*", "", source)
    source = re.sub(r"/\*.*?\*/", "", source, flags=re.DOTALL)
    return source


def extract_imports(source: str) -> list[str]:
    cleaned = strip_go_comments(source)
    imports = []

    for block in re.findall(r"\bimport\s*\((.*?)\)", cleaned, flags=re.DOTALL):
        imports.extend(match[0] or match[1] for match in re.findall(r'"([^"]+)"|`([^`]+)`', block))

    cleaned = re.sub(r"\bimport\s*\((.*?)\)", "", cleaned, flags=re.DOTALL)
    for quoted, raw in re.findall(r"\bimport\s+(?:[_.A-Za-z0-9]+\s+)?(?:\"([^\"]+)\"|`([^`]+)`)", cleaned):
        imports.append(quoted or raw)

    return sorted(set(imports))


def iter_go_package_dirs(repo_root: Path) -> list[Path]:
    package_dirs = []
    for current_root, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [
            name
            for name in dirnames
            if name not in SKIP_WALK_DIRS and not name.startswith(".")
        ]
        current_root = Path(current_root)
        go_files = [
            name
            for name in filenames
            if name.endswith(".go") and not name.endswith("_test.go")
        ]
        if go_files:
            package_dirs.append(current_root)
    return sorted(package_dirs)


def load_raw_packages(repo_root: Path, module_path: str | None) -> list[RawPackage]:
    result = []
    for package_dir in iter_go_package_dirs(repo_root):
        rel_path = package_dir.relative_to(repo_root).as_posix()
        go_files = sorted(
            [
                path.name
                for path in package_dir.iterdir()
                if path.is_file() and path.name.endswith(".go") and not path.name.endswith("_test.go")
            ]
        )
        if not go_files:
            continue

        imports = set()
        for file_name in go_files:
            source = (package_dir / file_name).read_text(encoding="utf-8")
            imports.update(extract_imports(source))

        import_path = f"{module_path}/{rel_path}" if module_path else rel_path
        result.append(
            RawPackage(
                import_path=import_path,
                rel_path=rel_path,
                imports=sorted(imports),
                go_files=go_files,
            )
        )
    return result


def candidate_roots(raw_packages: list[RawPackage]) -> list[str]:
    roots = {"."}
    for package in raw_packages:
        parts = package.rel_path.split("/")
        prefix = []
        for segment in parts[:-1]:
            prefix.append(segment)
            if any(item in EXCLUDE_SEGMENTS for item in prefix):
                continue
            roots.add("/".join(prefix))
    return sorted(roots, key=lambda item: (0 if item == "." else len(item.split("/")), item))


def parse_layer_map(raw_items: list[str]) -> dict[str, str]:
    result = {}
    for item in raw_items:
        for pair in item.split(","):
            pair = pair.strip()
            if not pair:
                continue
            if "=" not in pair:
                raise SystemExit(f"invalid --layer-map value: {pair}")
            name, role = pair.split("=", 1)
            name = name.strip().lower()
            role = role.strip().lower()
            if role not in LAYER_NAMES:
                raise SystemExit(f"invalid layer role in --layer-map: {role}")
            if not name:
                raise SystemExit("invalid empty layer alias in --layer-map")
            result[name] = role
    return result


def tokenize(value: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", value.lower())


def prefixes_match(value: str, prefixes: tuple[str, ...]) -> bool:
    return any(value == prefix or value.startswith(prefix) for prefix in prefixes)


def score_group(profile: GroupProfile, layer_overrides: dict[str, str], mode: str = "full") -> dict[str, int]:
    scores = {role: 0 for role in LAYER_NAMES}
    override = layer_overrides.get(profile.name.lower())
    if override:
        scores[override] += 100

    for token in tokenize(profile.name):
        for role, hints in ROLE_HINTS.items():
            scores[role] += hints.get(token, 0)

    if mode == "name-only":
        return scores

    for file_name in profile.go_files:
        stem = Path(file_name).stem
        for token in tokenize(stem):
            for role, hints in ROLE_HINTS.items():
                file_score = hints.get(token, 0)
                if file_score:
                    scores[role] += max(1, file_score // 2)

    transport_hits = sum(1 for item in profile.imports if prefixes_match(item, TRANSPORT_IMPORT_PREFIXES))
    infra_hits = sum(1 for item in profile.imports if prefixes_match(item, INFRA_IMPORT_PREFIXES))
    if transport_hits:
        scores["api"] += 6 + transport_hits
    if infra_hits:
        scores["infra"] += 6 + infra_hits

    incoming = len(profile.incoming_groups)
    outgoing = len(profile.outgoing_groups)
    if incoming > 0 and outgoing == 0 and not transport_hits and not infra_hits:
        scores["domain"] += 4
    if incoming > 0 and outgoing > 0 and not transport_hits and infra_hits == 0:
        scores["application"] += 3
    if incoming == 0 and outgoing > 0 and transport_hits:
        scores["api"] += 3
    if incoming == 0 and outgoing > 0 and infra_hits:
        scores["infra"] += 3
    if outgoing > 0 and incoming > 0 and infra_hits > 0:
        scores["infra"] += 1

    return scores


def assign_role_map(
    profiles: dict[str, GroupProfile],
    layer_overrides: dict[str, str],
    mode: str = "full",
) -> dict[str, str]:
    candidates = []
    for group_name, profile in profiles.items():
        scores = score_group(profile, layer_overrides, mode=mode)
        for role, score in scores.items():
            if score >= 4:
                candidates.append((score, group_name, role))

    candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
    assigned_groups = set()
    assigned_roles = set()
    result = {}
    for score, group_name, role in candidates:
        if group_name in assigned_groups or role in assigned_roles:
            continue
        result[group_name] = role
        assigned_groups.add(group_name)
        assigned_roles.add(role)
    return result


def build_direct_profiles(
    root: str,
    raw_packages: list[RawPackage],
    local_prefix: str | None,
    rel_to_package: dict[str, RawPackage],
) -> dict[str, GroupProfile]:
    profiles: dict[str, GroupProfile] = {}
    package_group: dict[str, str] = {}

    for raw in raw_packages:
        parts = split_under_root(raw.rel_path, root)
        if parts is None or not parts or any(segment in EXCLUDE_SEGMENTS for segment in parts):
            continue
        group_name = parts[0]
        profile = profiles.setdefault(group_name, GroupProfile(name=group_name))
        profile.package_paths.add(raw.rel_path)
        profile.go_files.update(raw.go_files)
        profile.imports.update(raw.imports)
        package_group[raw.rel_path] = group_name

    if not local_prefix:
        return profiles

    for rel_path, group_name in package_group.items():
        raw = rel_to_package[rel_path]
        for dep in raw.imports:
            if not dep.startswith(local_prefix):
                continue
            dep_rel_path = build_rel_path(dep, local_prefix[:-1])
            dep_group = package_group.get(dep_rel_path)
            if dep_group and dep_group != group_name:
                profiles[group_name].outgoing_groups.add(dep_group)
                profiles[dep_group].incoming_groups.add(group_name)

    return profiles


def build_module_profiles(
    root: str,
    raw_packages: list[RawPackage],
    local_prefix: str | None,
    rel_to_package: dict[str, RawPackage],
    excluded_top_levels: set[str],
) -> tuple[dict[str, GroupProfile], dict[str, set[str]]]:
    profiles: dict[str, GroupProfile] = {}
    module_groups: dict[str, set[str]] = defaultdict(set)
    package_key: dict[str, tuple[str, str]] = {}

    for raw in raw_packages:
        parts = split_under_root(raw.rel_path, root)
        if parts is None or len(parts) < 2 or any(segment in EXCLUDE_SEGMENTS for segment in parts):
            continue
        module_name = parts[0]
        if module_name in excluded_top_levels:
            continue
        group_name = parts[1]
        profile = profiles.setdefault(group_name, GroupProfile(name=group_name))
        profile.package_paths.add(raw.rel_path)
        profile.go_files.update(raw.go_files)
        profile.imports.update(raw.imports)
        profile.modules.add(module_name)
        module_groups[module_name].add(group_name)
        package_key[raw.rel_path] = (module_name, group_name)

    if not local_prefix:
        return profiles, module_groups

    for rel_path, (module_name, group_name) in package_key.items():
        raw = rel_to_package[rel_path]
        for dep in raw.imports:
            if not dep.startswith(local_prefix):
                continue
            dep_rel_path = build_rel_path(dep, local_prefix[:-1])
            dep_key = package_key.get(dep_rel_path)
            if not dep_key:
                continue
            dep_module, dep_group = dep_key
            if dep_module != module_name or dep_group == group_name:
                continue
            profiles[group_name].outgoing_groups.add(dep_group)
            profiles[dep_group].incoming_groups.add(group_name)

    return profiles, module_groups


def count_relevant_packages(
    root: str,
    raw_packages: list[RawPackage],
    direct_role_map: dict[str, str],
    module_role_map: dict[str, str],
) -> int:
    count = 0
    for raw in raw_packages:
        parts = split_under_root(raw.rel_path, root)
        if parts is None or not parts:
            continue
        if parts[0] in direct_role_map:
            count += 1
            continue
        if len(parts) >= 2 and parts[1] in module_role_map:
            count += 1
    return count


def evaluate_candidate(
    root: str,
    raw_packages: list[RawPackage],
    module_path: str | None,
    layer_overrides: dict[str, str],
    allow_partial: bool = False,
) -> LayoutCandidate | None:
    if root != "." and any(segment in EXCLUDE_SEGMENTS for segment in root.split("/")):
        return None

    local_prefix = f"{module_path}/" if module_path else None
    rel_to_package = {item.rel_path: item for item in raw_packages}
    direct_profiles = build_direct_profiles(root, raw_packages, local_prefix, rel_to_package)
    direct_role_map = assign_role_map(direct_profiles, layer_overrides, mode="name-only")
    direct_role_count = len(set(direct_role_map.values()))
    module_profiles, module_groups = build_module_profiles(
        root,
        raw_packages,
        local_prefix,
        rel_to_package,
        set(direct_role_map.keys()) if direct_role_count >= 3 else set(),
    )
    module_role_map = assign_role_map(module_profiles, layer_overrides, mode="full")

    direct_roles = set(direct_role_map.values())
    module_roles = set(module_role_map.values())
    big_modules = sorted(
        module_name
        for module_name, groups in module_groups.items()
        if len({module_role_map[group] for group in groups if group in module_role_map}) >= 2
    )

    if big_modules and len(direct_roles) < 2:
        direct_role_map = {}
        direct_roles = set()

    if len(direct_roles) >= 3 and not big_modules:
        structure = "standard"
        module_role_map = {}
    elif big_modules and len(module_roles) >= 3 and not direct_roles:
        structure = "large-module"
    elif len(direct_roles) >= 3 and big_modules and len(module_roles) >= 2:
        structure = "mixed"
    else:
        if not allow_partial:
            return None
        structure = "unclear"

    package_count = sum(1 for raw in raw_packages if split_under_root(raw.rel_path, root) is not None)
    relevant_package_count = count_relevant_packages(root, raw_packages, direct_role_map, module_role_map)
    depth = 0 if root == "." else len(root.split("/"))
    score = (
        relevant_package_count * 20
        + len(direct_roles) * 120
        + len(module_roles) * 120
        + len(big_modules) * 100
        - depth * 5
    )
    if root == "." and not direct_roles and len(big_modules) == 1 and big_modules[0] in WRAPPER_ROOT_HINTS:
        score -= 250

    return LayoutCandidate(
        root=root,
        structure=structure,
        direct_role_map=direct_role_map,
        module_role_map=module_role_map,
        big_modules=big_modules,
        package_count=package_count,
        relevant_package_count=relevant_package_count,
        score=score,
    )


def discover_layout(
    raw_packages: list[RawPackage],
    layout_root: str | None,
    module_path: str | None,
    layer_overrides: dict[str, str],
) -> LayoutSelection:
    candidates = [
        candidate
        for root in candidate_roots(raw_packages)
        if (candidate := evaluate_candidate(root, raw_packages, module_path, layer_overrides))
    ]
    candidates.sort(
        key=lambda item: (
            -item.score,
            -item.relevant_package_count,
            -item.package_count,
            0 if item.root == "." else len(item.root.split("/")),
            item.root,
        )
    )

    if layout_root:
        chosen = evaluate_candidate(layout_root, raw_packages, module_path, layer_overrides, allow_partial=True)
        if chosen is None:
            chosen = LayoutCandidate(
                root=layout_root,
                structure="unclear",
                direct_role_map={},
                module_role_map={},
                big_modules=[],
                package_count=0,
                relevant_package_count=0,
                score=0,
            )
        return LayoutSelection(
            root=chosen.root,
            structure=chosen.structure,
            direct_role_map=chosen.direct_role_map,
            module_role_map=chosen.module_role_map,
            big_modules=chosen.big_modules,
            mode="manual",
            candidates=candidates,
        )

    if candidates:
        chosen = candidates[0]
        return LayoutSelection(
            root=chosen.root,
            structure=chosen.structure,
            direct_role_map=chosen.direct_role_map,
            module_role_map=chosen.module_role_map,
            big_modules=chosen.big_modules,
            mode="auto",
            candidates=candidates,
        )

    return LayoutSelection(
        root=".",
        structure="unclear",
        direct_role_map={},
        module_role_map={},
        big_modules=[],
        mode="fallback",
        candidates=[],
    )


def classify_package(
    parts: list[str],
    layout: LayoutSelection,
) -> tuple[str | None, str | None, str | None]:
    if not parts or any(segment in EXCLUDE_SEGMENTS for segment in parts):
        return None, None, None

    if len(parts) >= 2 and parts[0] in layout.big_modules and parts[1] in layout.module_role_map:
        return layout.module_role_map[parts[1]], parts[0], "module"
    if parts[0] in layout.direct_role_map:
        return layout.direct_role_map[parts[0]], None, "direct"
    if len(parts) >= 2 and parts[1] in layout.module_role_map:
        return layout.module_role_map[parts[1]], parts[0], "module"
    return None, None, None


def detect_tech_imports(layer: str | None, imports: list[str]) -> list[str]:
    if layer not in TECH_IMPORT_RULES:
        return []

    matches = []
    for item in imports:
        for prefix in TECH_IMPORT_RULES[layer]:
            if item == prefix or item.startswith(prefix):
                matches.append(item)
                break
    return sorted(set(matches))


def collect_packages(
    raw_packages: list[RawPackage],
    module_path: str | None,
    layout: LayoutSelection,
) -> dict[str, PackageInfo]:
    local_prefix = f"{module_path}/" if module_path else None
    result: dict[str, PackageInfo] = {}

    for raw in raw_packages:
        parts = split_under_root(raw.rel_path, layout.root)
        if parts is None or not parts or any(segment in EXCLUDE_SEGMENTS for segment in parts):
            continue

        layer, big_module, layer_source = classify_package(parts, layout)
        local_imports = []
        for dep in raw.imports:
            if local_prefix and dep.startswith(local_prefix):
                local_imports.append(build_rel_path(dep, module_path))

        result[raw.rel_path] = PackageInfo(
            import_path=raw.import_path,
            rel_path=raw.rel_path,
            layout_root=layout.root,
            layer=layer,
            big_module=big_module,
            layer_source=layer_source,
            go_files=raw.go_files,
            is_wiring_package=any(name.startswith("wire") for name in raw.go_files),
            local_imports=sorted(set(local_imports)),
            tech_imports=detect_tech_imports(layer, raw.imports),
        )

    return result


def package_in_scope(package: PackageInfo, scope_module: str | None) -> bool:
    if not scope_module:
        return True
    parts = split_under_root(package.rel_path, package.layout_root) or []
    return scope_module in parts


def add_finding(findings: list[dict], seen: set[tuple], finding: dict) -> None:
    key = (
        finding["severity"],
        finding["type"],
        finding["from"],
        finding.get("to"),
        finding.get("detail"),
    )
    if key in seen:
        return
    seen.add(key)
    findings.append(finding)


def merge_findings(findings: list[dict]) -> list[dict]:
    severity_order = {"high": 0, "medium": 1, "low": 2}
    edge_groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    standalone = []

    for finding in findings:
        if finding.get("to"):
            edge_groups[(finding["from"], finding["to"])].append(finding)
        else:
            standalone.append(finding)

    merged = []
    for finding in standalone:
        merged.append(finding)

    for (source, target), items in edge_groups.items():
        if len(items) == 1:
            merged.append(items[0])
            continue

        reasons = []
        types = []
        min_severity_rank = 9
        for item in items:
            detail = item["detail"]
            if detail not in reasons:
                reasons.append(detail)
            item_type = item["type"]
            if item_type not in types:
                types.append(item_type)
            min_severity_rank = min(min_severity_rank, severity_order.get(item["severity"], 9))

        reverse_severity = {value: key for key, value in severity_order.items()}
        merged.append(
            {
                "severity": reverse_severity.get(min_severity_rank, "medium"),
                "type": "combined-edge" if len(types) > 1 else types[0],
                "from": source,
                "to": target,
                "detail": "; ".join(reasons),
                "rules": reasons,
                "types": types,
            }
        )

    merged.sort(key=lambda item: (severity_order.get(item["severity"], 9), item["from"], item.get("to", "")))
    return merged


def analyze(
    scope_packages: dict[str, PackageInfo],
    all_packages: dict[str, PackageInfo],
    structure: str,
    scope_module: str | None,
) -> list[dict]:
    findings: list[dict] = []
    seen: set[tuple] = set()

    for package in scope_packages.values():
        if package.tech_imports and not package.is_wiring_package:
            add_finding(
                findings,
                seen,
                {
                    "severity": "medium",
                    "type": "tech-import",
                    "from": package.rel_path,
                    "detail": f"{package.layer} imports tech package(s): {', '.join(package.tech_imports)}",
                },
            )

        for dep_rel_path in package.local_imports:
            dep = all_packages.get(dep_rel_path)
            if not dep:
                continue

            for from_layer, to_layers, severity, reason in DIRECT_IMPORT_RULES:
                if package.is_wiring_package:
                    continue
                if package.layer == from_layer and dep.layer in to_layers:
                    add_finding(
                        findings,
                        seen,
                        {
                            "severity": severity,
                            "type": "layer-dependency",
                            "from": package.rel_path,
                            "to": dep.rel_path,
                            "detail": reason,
                        },
                    )

            if structure in {"large-module", "mixed"} and package.big_module and dep.big_module and package.big_module != dep.big_module:
                add_finding(
                    findings,
                    seen,
                    {
                        "severity": "medium",
                        "type": "cross-big-module",
                        "from": package.rel_path,
                        "to": dep.rel_path,
                        "detail": "big modules should not depend on sibling big-module implementations directly",
                    },
                )

            if scope_module and package.big_module == scope_module and dep.big_module and dep.big_module != scope_module:
                add_finding(
                    findings,
                    seen,
                    {
                        "severity": "medium",
                        "type": "cross-module-scope",
                        "from": package.rel_path,
                        "to": dep.rel_path,
                        "detail": "scoped module depends on another big module",
                    },
                )

    return merge_findings(findings)


def build_summary(
    scope_packages: dict[str, PackageInfo],
    layout: LayoutSelection,
    scope_module: str | None,
    layer_overrides: dict[str, str],
) -> dict:
    layer_counts = Counter(pkg.layer or "unclassified" for pkg in scope_packages.values())
    unclassified = sorted(pkg.rel_path for pkg in scope_packages.values() if not pkg.layer)

    if scope_module and layout.structure == "large-module":
        module_root_rel_path = f"{layout.root}/{scope_module}" if layout.root != "." else scope_module
        unclassified = [item for item in unclassified if item != module_root_rel_path]
        if module_root_rel_path in scope_packages and not scope_packages[module_root_rel_path].layer:
            layer_counts["unclassified"] = max(0, layer_counts.get("unclassified", 0) - 1)
            if layer_counts["unclassified"] == 0:
                del layer_counts["unclassified"]

    return {
        "scope": scope_module or "full-repo",
        "layout_root": layout.root,
        "layout_root_mode": layout.mode,
        "structure": layout.structure,
        "big_modules": layout.big_modules,
        "package_count": len(scope_packages),
        "layer_counts": dict(sorted(layer_counts.items())),
        "unclassified_packages": unclassified,
        "direct_role_map": dict(sorted(layout.direct_role_map.items())),
        "module_role_map": dict(sorted(layout.module_role_map.items())),
        "layer_overrides": dict(sorted(layer_overrides.items())),
        "candidate_roots": [
            {
                "root": item.root,
                "structure": item.structure,
                "score": item.score,
                "big_modules": item.big_modules,
                "direct_role_map": item.direct_role_map,
                "module_role_map": item.module_role_map,
            }
            for item in layout.candidates[:5]
        ],
    }


def print_role_map(title: str, role_map: dict[str, str]) -> None:
    if not role_map:
        return
    print(title)
    for name, role in sorted(role_map.items()):
        print(f"  - {name} => {role}")


def print_text(summary: dict, findings: list[dict]) -> None:
    print("DDD scan summary")
    print(f"Scope: {summary['scope']}")
    print(f"Layout root: {summary['layout_root']} ({summary['layout_root_mode']})")
    print(f"Detected structure: {summary['structure']}")
    print(f"Packages in scope: {summary['package_count']}")

    print_role_map("Direct layer aliases:", summary["direct_role_map"])
    print_role_map("Module layer aliases:", summary["module_role_map"])
    if summary["layer_overrides"]:
        print_role_map("Manual layer overrides:", summary["layer_overrides"])

    if summary["big_modules"]:
        print("Big modules:")
        for name in summary["big_modules"]:
            print(f"  - {name}")

    if summary["candidate_roots"]:
        print("Top layout candidates:")
        for item in summary["candidate_roots"]:
            print(f"  - {item['root']}: {item['structure']} (score={item['score']})")

    print("Layer counts:")
    for name, count in summary["layer_counts"].items():
        print(f"  - {name}: {count}")

    print("Potential findings:")
    if not findings:
        print("  - none from static scan")
    else:
        for item in findings:
            target = f" -> {item['to']}" if item.get("to") else ""
            print(f"  - [{item['severity']}] {item['from']}{target}: {item['detail']}")

    print("Unclassified packages:")
    if not summary["unclassified_packages"]:
        print("  - none")
    else:
        for rel_path in summary["unclassified_packages"]:
            print(f"  - {rel_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Lightweight DDD layer scanner for Go repositories.")
    parser.add_argument("--repo-root", default=".", help="Repository root. Defaults to current directory.")
    parser.add_argument(
        "--layout-root",
        help="Optional layout root relative to repo root, such as '.', 'internal', or 'apps'. Auto-detected by default.",
    )
    parser.add_argument(
        "--layer-map",
        action="append",
        default=[],
        help="Optional directory-role overrides, e.g. access=api,usecase=application,persistence=infra",
    )
    parser.add_argument("--module", help="Optional big module or business module name to focus on.")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of text.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repo_root = Path(args.repo_root).resolve()
    module_path = read_module_path(repo_root)
    layer_overrides = parse_layer_map(args.layer_map)
    raw_packages = load_raw_packages(repo_root, module_path)
    layout = discover_layout(raw_packages, args.layout_root, module_path, layer_overrides)
    all_packages = collect_packages(raw_packages, module_path, layout)
    scope_packages = {
        rel_path: package
        for rel_path, package in all_packages.items()
        if package_in_scope(package, args.module)
    }
    findings = analyze(scope_packages, all_packages, layout.structure, args.module)
    summary = build_summary(scope_packages, layout, args.module, layer_overrides)

    if args.json:
        output = {
            "summary": summary,
            "findings": findings,
            "packages": [asdict(pkg) for pkg in sorted(scope_packages.values(), key=lambda item: item.rel_path)],
        }
        print(json.dumps(output, indent=2, sort_keys=True))
        return

    print_text(summary, findings)


if __name__ == "__main__":
    main()
