---
name: golang-ddd-spec-checker
description: 根据 skill 内置的 DDD 规范文档对 Go 项目做轻量 DDD 合规检查。适用于架构评审、模板验收、代码评审，或当用户要求判断整个项目或单个大模块是否符合 DDD 标准时。重点检查依赖方向、分层职责、写操作是否经过领域模型、基础设施隔离和模块边界，并输出不符合项、风险项和证据；不负责给出详细迁移手册或分阶段改造方案。
---

# Go DDD 规范检查

先读取 `references/ddd-spec.md`。默认只读规范正文；只有在需要细化判断口径、命令提示或输出格式时，再读 `references/checklist.md`。
本 skill 里出现的 `scripts/`、`references/` 路径都相对 skill 自身目录，不相对目标仓库目录。

先运行这个 skill 自带的 `scripts/ddd_scan.py` 做结构与依赖粗扫，再人工复核职责边界。不要只根据目录名下结论。
这个脚本只读取本地 `go.mod` 和 `.go` 文件，不依赖 `go list`、依赖下载或私有仓库权限。

## 检查范围

1. 先识别项目形态：
- 标准结构：某个根目录下直接出现 `api|application|domain|infra`
- 大模块结构：某个根目录下出现 `<big-module>/{api,application,domain,infra}`

这里的“根目录”不固定，可以是项目根目录、`internal/`、`apps/`，也可以是其他名字的目录。名字不重要，只要分层关系成立即可。
层名也不要求刚好叫 `api/application/domain/infra`。脚本会先识别标准命名；识别不到时，再根据目录名线索、导入特征、文件名和依赖方向推断层角色，例如把 `access` 推断成 API 层。

2. 决定扫描粒度：
- 如果用户指定大模块，只检查该模块内部的分层，并顺手看它是否依赖了其他大模块。
- 如果仓库是大模块结构但用户没有指定模块，只做全局粗扫：
  - 列出大模块
  - 检查是否存在明显跨大模块依赖
  - 指出哪些模块值得单独深入
  - 不要一次性深读所有大模块内部实现
- 如果仓库是标准结构，默认检查整个项目。

## 快速开始

先运行脚本：

```bash
python3 <skill-dir>/scripts/ddd_scan.py --repo-root .
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --module user
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --layout-root apps --module order
python3 <skill-dir>/scripts/ddd_scan.py --repo-root . --layout-root apps --layer-map access=api --layer-map usecase=application --module order
```

这里的 `<skill-dir>` 指当前安装好的 skill 目录，例如用户级安装路径或其他实际落盘路径。

脚本输出只用于发现线索：

- 自动识别出的分层根目录
- 自动或手工指定的层别名映射
- 结构类型
- 已识别层级包
- 可能的越层依赖
- 大模块之间的直接依赖
- 需要人工归类的包

## 判定原则

- 目录命名不是硬性要求；职责和依赖方向才是核心。
- 非标准层名先做“角色推断”，不要因为没有出现 `api/application/domain/infra` 就直接判不符合。
- 明确违反规范且证据充分时，写入“`不符合项`”。
- 只有坏味道但证据不足时，写入“`风险项`”或“`待确认项`”，不要把猜测说成结论。
- 历史公共包、`common`、`util`、`helper` 只有在承载了单模块业务逻辑、反向依赖、或成为跨层绕行通道时才判问题。
- API 直接 import domain 不自动判死刑；如果只是常量、错误映射、只读轻量类型可降级为风险项，但如果直接驱动业务决策、越过 application 调 repository 或 infra，应判问题。
- Infra 可以依赖 domain，必要时也可以实现 application 需要的 port；重点检查它是否反向决定业务规则。

## 必查项

优先检查下面几类问题：

1. 依赖方向
- `domain -> api/application/infra`
- `application -> api`
- `api -> infra`
- 大模块结构下的 `moduleA -> moduleB` 直接实现依赖

2. 职责位置
- API 层是否在编排主流程、直接查库、直接调外部 SDK
- Application 层是否塞了资格判断、不变量、状态流转
- Domain 层是否出现 DTO、request、response、HTTP、SQL、ORM、SDK
- Infra 层是否偷偷做业务准入、状态判断、跨模块决策

3. 写路径
- 写操作是否围绕聚合或领域服务展开
- 是否把核心状态流转拆到 repository、DAO、SQL 模板、handler
- repository 是否在替代聚合做业务判断

4. 结构兼容性
- 标准结构下，模块是否沿 `api/application/domain/infra` 对齐
- 大模块结构下，只在指定模块内做深查；未指定模块时只做全局粗扫
- 不要因为顶层目录叫 `internal`、`apps` 或其他名字就直接下结论；先看脚本识别出的分层根目录是否合理

## 人工复核方法

- 从 1 到 3 条核心写用例逆向追踪：入口 -> application -> domain -> repository 或 gateway。
- 重点读 service、aggregate、repository interface、infra adapter，不要平均扫所有文件。
- 对“名字不像四层”的包，按职责重新归类，再判断依赖是否合理。
- 如果脚本的角色推断明显不准，改用 `--layer-map` 指定目录名到标准层角色的映射。
- 如需更多判定口径、命令提示和输出模板，读取 `references/checklist.md`。

## 输出要求

输出时只给检查结论，不给迁移手册，除非用户明确要求。

至少包含：

- 本次检查范围：全项目或某个大模块
- 分层根目录：脚本自动识别结果；如果明显不对，再人工改用 `--layout-root`
- 层别名映射：脚本推断结果；如果人工指定了 `--layer-map`，也一并写明
- 结构判断：标准结构 / 大模块结构 / 混合或待确认
- `不符合项`：逐条写规则、证据、影响
- `风险项`：证据未闭合但值得进一步确认
- `待确认项`：仅当目录命名特殊或上下文不足时使用
- 如果是大模块结构且用户未指定模块，补一行“建议下一步优先检查哪个模块”

不要输出“应该如何分阶段改造”。如果用户追问具体改法，再单独回答。
