# Neo API Test Runner — 环境配置指南

当用户请求「配置环境」时，按以下流程逐步执行。每步先检测是否已完成，跳过已满足的步骤。

## 1. 检测与安装 Neo CLI

### 1.1 检测

```bash
neo --help
```

若命令存在且输出正常 → 跳到步骤 2。

### 1.2 安装

```bash
cd "$HOME"
git clone https://github.com/4ier/neo.git
cd neo
npm install
npm run build
npm link
```

### 1.3 验证

```bash
neo --help    # 应输出命令列表
```

失败则排查 Node.js / npm 版本，确保 >= Node 18。

## 2. 检测与安装 jq

### 2.1 检测

```bash
jq --version
```

若已安装 → 跳到步骤 3。

### 2.2 安装（macOS）

```bash
brew install jq
```

### 2.3 验证

```bash
jq --version
```

## 3. 构建 Neo Chrome 扩展

### 3.1 检测

检查 Neo 项目中 `extension/dist/` 目录是否存在：

```bash
ls "$HOME/neo/extension/dist/"
```

## 4. 创建持久化 Chrome Profile 并启动 CDP Chrome

### 4.1 检测端口占用

```bash
lsof -i :9222
```

若端口已被 Chrome 占用 → 说明 CDP Chrome 已在运行，跳到步骤 5。

### 4.2 启动

```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
    --remote-debugging-port=9222 \
    --user-data-dir="$HOME/.neo-chrome-profile" \
    "about:blank" &
```

等待 3 秒后确认端口已监听：

```bash
sleep 3
lsof -i :9222
```

向用户说明：
- 此 Chrome 窗口与日常浏览器互不影响，可同时运行
- Profile 目录 `~/.neo-chrome-profile` 持久化存储，重启后保留登录态和扩展

## 5. 加载 Neo 扩展（需用户手动操作）

**此步骤无法自动化，需要引导用户操作。** 仅首次使用该 profile 时需要执行，后续启动自动加载。

提示用户：

> 请在刚打开的 CDP Chrome（端口 9222 的窗口）中执行以下操作：
>
> 1. 地址栏输入 `chrome://extensions` 回车
> 2. 右上角开启「开发者模式」
> 3. 点击「加载已解压的扩展程序」
> 4. 选择 Neo 项目的 `extension/dist/` 目录（通常在 `~/neo/extension/dist/`）
> 5. 确认 Neo 扩展出现在列表中且已启用
>
> 完成后即可开始测试。

**判断是否需要此步骤**：若用户之前已配置过（profile 目录 `~/.neo-chrome-profile` 非首次创建），询问用户是否已加载过扩展。若已加载则跳过。
