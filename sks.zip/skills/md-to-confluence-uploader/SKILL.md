---
name: md-to-confluence-uploader
description: >-
  将本地 Markdown 文档转换为 Confluence Storage Format (XHTML) 并通过 REST API
  上传到指定的 Confluence 页面。Mermaid/PlantUML 代码块和文本绘图（ASCII
  流程图、树状图、架构图）自动转为 Confluence PlantUML 宏渲染为图片。
  代码块转为 Confluence code 宏。
  当用户提到「上传到 Confluence」「同步到 Confluence」「发布到 Confluence」
  「更新 Confluence 页面」时使用。
---

# Markdown → Confluence 上传器

## 目标与边界

- **目标**：将仓库内的 `.md` 文件转换为 Confluence Storage Format 并上传到指定页面。
- **核心能力**：
  - Markdown → Confluence XHTML 转换（表格、列表、标题、引用、链接、加粗/斜体）
  - Mermaid / PlantUML 代码块 → PlantUML 宏（业务用例图、时序图、功能架构图正常展示）
  - 文本绘图 → PlantUML 宏（ASCII 流程图、树状图、box 架构图自动识别并转换）
  - 代码块 → Confluence code 宏（带语法高亮）
  - Emoji 字符自动清理（Confluence 不支持部分 Unicode emoji）
  - 通过 Confluence REST API 上传（Bearer token 认证）
- **边界**：不创建新页面（只更新已有页面）；不处理图片附件上传；PlantUML 渲染依赖 Confluence 安装了 PlantUML 插件。

## 前置条件

1. **Confluence API Token**：从 MCP 配置 `~/.cursor/mcp.json` 中自动读取，优先使用 `Confluence communication server` 的 `API_TOKEN`（Bearer 认证）。
2. **目标页面已存在**：用户需提供 Confluence 页面 URL 或 Page ID。
3. **Python 3**：转换脚本需要 Python 3.6+，使用标准库（无第三方依赖）。

## 何时使用

- 用户说「把这个 md 上传到 Confluence」「同步到 Confluence 页面」「更新 Confluence」。
- 用户提供了一个 `.md` 文件路径和一个 Confluence 页面链接。
- TRD 或分享文档写完后需要发布到 Confluence。

## 何时不要用

- 用户只需要读取 Confluence 页面（用 Confluence MCP 的 `get_page`）。
- 用户要创建新的 Confluence 页面（当前不支持，需手动创建后再更新）。
- 文档含大量嵌入图片需要作为附件上传（当前不处理图片附件）。

## 执行步骤

### 第一步：确认输入

向用户确认以下信息（缺失则提问）：

| 输入 | 必填 | 说明 |
|------|------|------|
| Markdown 文件路径 | 是 | 仓库内的 `.md` 文件路径 |
| Confluence 页面 URL 或 Page ID | 是 | 如 `https://confluence.shopee.io/pages/viewpage.action?pageId=3162294905` |
| PlantUML 图表映射 | 否 | 若文档包含特殊的 ASCII 图表需要自定义 PlantUML 转换，可提供映射 |

从 URL 中提取 Page ID：

```python
import re
m = re.search(r'pageId=(\d+)', url)
page_id = m.group(1) if m else url  # 若直接传数字则直接用
```

### 第二步：转换 Markdown → Confluence XHTML

运行转换脚本：

```bash
python3 .cursor/skills/md-to-confluence-uploader/scripts/md_to_confluence.py \
  <input.md> \
  <output.xhtml>
```

脚本自动处理以下转换：

| Markdown 元素 | Confluence 格式 |
|---------------|----------------|
| `# 标题` | `<h1>` ~ `<h6>` |
| `**粗体**` | `<strong>` |
| `` `代码` `` | `<code>` |
| `[链接](url)` | `<a href>` |
| `> 引用` | `<ac:structured-macro ac:name="info">` |
| 管道表格 | `<table>` |
| 有序/无序列表 | `<ol>` / `<ul>` |
| `---` 分隔线 | `<hr />` |
| 围栏代码块 | `<ac:structured-macro ac:name="code">` |
| ```mermaid | 转换为 `<ac:structured-macro ac:name="plantuml">` |
| ```plantuml | `<ac:structured-macro ac:name="plantuml">` |
| ASCII 文本绘图 | `<ac:structured-macro ac:name="plantuml">` |

**文本绘图识别规则**：
- 包含 box 字符（`┌┐└┘├┤─│`）→ 架构图
- 包含树形结构（`├──→`、`└──→`）→ 依赖关系图
- 包含垂直流程箭头（连续 `↓`）→ 流程图

**Mermaid 图表处理要求**：
- 文档中出现 ```mermaid、`flowchart`、`sequenceDiagram` 时，必须确认转换结果 `PlantUML diagrams` 大于 0。
- 不要把含 Mermaid 图表的文档用 MCP `content_format="markdown"` 上传；否则 Confluence 可能生成 `macro-diagram` / `MacroBodyMermaid` 占位，导致页面显示“不能识别的宏: 'macro-diagram'”。
- Mermaid 图表应先转换为 PlantUML 宏，再用 Storage XHTML 上传。

### 第三步：清理不兼容字符

Confluence REST API 不支持部分 Unicode emoji（如 🔘 等 U+10000 以上字符）。脚本已内置清理：

| 原字符 | 替换为 |
|--------|--------|
| ✅ | `(/)` |
| ❌ | `(x)` |
| ⚠️ | `(!)` |
| 🔘 | `(N/A)` |
| ⭐ 等非 BMP 字符 | `*` 或 `?` |

### 第四步：读取 Confluence 认证信息

从 `~/.cursor/mcp.json` 自动提取 API Token：

```python
import json
with open(os.path.expanduser('~/.cursor/mcp.json')) as f:
    mcp_config = json.load(f)

api_token = mcp_config['mcpServers']['Confluence communication server']['env']['API_TOKEN']
```

认证方式：`Authorization: Bearer {api_token}`

### 第五步：上传到 Confluence

优先通过 Confluence MCP 以 Storage XHTML 更新页面（尤其是包含 Mermaid/PlantUML 图表时）：

```text
mcp__atlassian_mcp__.confluence_update_page(
  page_id="<PAGE_ID>",
  title="<当前页面标题>",
  content="<output.xhtml 的内容>",
  content_format="storage",
  is_minor_edit=false,
  version_comment="Upload Markdown as storage XHTML with PlantUML macros",
  include_content=false
)
```

如果必须走 REST API，也只能上传已经转换好的 Storage XHTML：

```bash
python3 .cursor/skills/md-to-confluence-uploader/scripts/upload_to_confluence.py \
  --page-id <PAGE_ID> \
  --content <output.xhtml>
```

脚本执行流程：
1. `GET /rest/api/content/{pageId}?expand=version` — 获取当前版本号
2. `PUT /rest/api/content/{pageId}` — 更新页面内容（version +1）

### 第六步：验证

上传后通过 Confluence MCP 读取页面确认内容，包含图表时必须读 raw storage：

```
mcp__atlassian_mcp__.confluence_get_page(
  page_id="<PAGE_ID>",
  include_metadata=true,
  convert_to_markdown=false
)
```

向用户报告：
- 上传状态（成功/失败）
- 新版本号
- 页面 URL
- PlantUML 图表数量和代码块数量
- Raw storage 中存在 `ac:name="plantuml"`，且不存在 `macro-diagram` / `MacroBodyMermaid`
- 若有失败，给出错误信息和修复建议

## 自定义 PlantUML 图表映射

对于脚本无法自动识别的复杂 ASCII 图表，可在转换脚本的 `PLANTUML_DIAGRAMS` 字典中添加映射：

```python
PLANTUML_DIAGRAMS = {
    'my_diagram': '''@startuml
    ... PlantUML 代码 ...
    @enduml''',
}

DIAGRAM_SIGNATURES = [
    ('my_diagram', lambda lines: '特征文本' in '\n'.join(lines)),
]
```

匹配规则：按 `DIAGRAM_SIGNATURES` 列表顺序，第一个匹配的 lambda 返回 True 时使用对应的 PlantUML 代码。

## 质量检查（上传后自检）

- [ ] 页面标题未被意外修改
- [ ] 所有标题层级（h1-h6）正确渲染
- [ ] 表格列数和内容完整
- [ ] 代码块有正确的语法高亮语言标记
- [ ] Mermaid/业务用例图/时序图已转为 PlantUML 宏，而不是 `macro-diagram`
- [ ] PlantUML 图表渲染为图片（若显示为原始代码，检查 Confluence 的 PlantUML 插件是否启用）
- [ ] 无乱码或不可见字符
- [ ] 页面版本号正确递增

## 已知限制

| 限制 | 说明 | 规避方式 |
|------|------|---------|
| 不支持图片附件 | Markdown 中的 `![](img.png)` 不会上传图片 | 手动在 Confluence 中添加图片 |
| 不支持创建新页面 | 只能更新已有页面 | 先手动创建空白页面 |
| PlantUML 插件依赖 | 需要 Confluence 安装 PlantUML 插件 | 无插件时图表显示为代码 |
| 嵌套列表深度 | 超过 3 层嵌套可能格式异常 | 减少嵌套层级 |
| 复杂 Markdown 扩展 | 不支持脚注、定义列表、数学公式等 | 使用标准 Markdown 语法 |

## 与仓库其他 Skill 的关系

| Skill | 关系 |
|-------|------|
| **TRD 生成流程** | TRD 写入 `AI_gen/{jira_no}/` 后可通过本 Skill 上传到 Confluence |
| **test-case-import-xlsx-generator** | 分享文档更新后可通过本 Skill 同步到 Confluence |
| **所有生成 `.md` 的 Skill** | 凡是产出 Markdown 文档的 Skill，都可衔接本 Skill 发布到 Confluence |

## 示例

**用户**：「帮忙把 AI_gen/AI自动化测试实践分享.md 上传到 https://confluence.shopee.io/pages/viewpage.action?pageId=3162294905」

**Agent**：
1. 提取 pageId=3162294905
2. 运行 `md_to_confluence.py` 转换 → 生成 52KB XHTML，12 个 PlantUML 图 + 22 个代码块
3. 清理 emoji 字符
4. 通过 REST API 上传，版本 v1 → v2
5. 回复：上传成功，页面 URL，建议在浏览器中确认 PlantUML 渲染效果
