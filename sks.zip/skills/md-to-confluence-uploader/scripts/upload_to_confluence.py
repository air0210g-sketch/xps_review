#!/usr/bin/env python3
"""Upload XHTML content to a Confluence page via REST API.

Usage:
    python3 upload_to_confluence.py --page-id PAGE_ID --content FILE.xhtml [--token TOKEN] [--base-url URL]

The script auto-discovers the API token from MCP configuration if --token is
not supplied.  It reads the current page version, increments it, and PUTs the
new body.
"""

import argparse
import json
import os
import re
import sys
import urllib.request
import urllib.error


DEFAULT_BASE_URL = 'https://confluence.shopee.io'
MCP_CONFIG_PATH = os.path.expanduser('~/.cursor/mcp.json')


def discover_token():
    """Try to read the API token from MCP configuration."""
    if not os.path.exists(MCP_CONFIG_PATH):
        return None

    with open(MCP_CONFIG_PATH, 'r', encoding='utf-8') as f:
        cfg = json.load(f)

    servers = cfg.get('mcpServers', {})

    for server_name in ('Confluence communication server', 'confluence-mcp'):
        server = servers.get(server_name, {})
        env = server.get('env', {})
        token = env.get('API_TOKEN') or env.get('CONFLUENCE_TOKEN')
        if token:
            return token

    return None


def get_page_info(base_url, page_id, token):
    """GET current page version and title."""
    url = f'{base_url}/rest/api/content/{page_id}?expand=version'
    req = urllib.request.Request(url, method='GET')
    req.add_header('Authorization', f'Bearer {token}')
    req.add_header('Accept', 'application/json')

    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode('utf-8'))


def update_page(base_url, page_id, token, title, body_xhtml, new_version):
    """PUT updated page content."""
    url = f'{base_url}/rest/api/content/{page_id}'

    payload = json.dumps({
        'id': str(page_id),
        'type': 'page',
        'title': title,
        'body': {
            'storage': {
                'value': body_xhtml,
                'representation': 'storage',
            }
        },
        'version': {
            'number': new_version,
        }
    }, ensure_ascii=False)

    data = payload.encode('utf-8')
    req = urllib.request.Request(url, data=data, method='PUT')
    req.add_header('Authorization', f'Bearer {token}')
    req.add_header('Content-Type', 'application/json; charset=utf-8')
    req.add_header('Accept', 'application/json')

    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode('utf-8'))


def main():
    parser = argparse.ArgumentParser(description='Upload XHTML to Confluence page')
    parser.add_argument('--page-id', required=True, help='Confluence page ID')
    parser.add_argument('--content', required=True, help='Path to XHTML content file')
    parser.add_argument('--token', default=None, help='Bearer token (auto-discovered from MCP config if omitted)')
    parser.add_argument('--base-url', default=DEFAULT_BASE_URL, help=f'Confluence base URL (default: {DEFAULT_BASE_URL})')
    parser.add_argument('--title', default=None, help='Override page title (default: keep existing)')
    args = parser.parse_args()

    token = args.token or discover_token()
    if not token:
        print('ERROR: No API token found. Provide --token or configure Confluence MCP.', file=sys.stderr)
        sys.exit(1)

    with open(args.content, 'r', encoding='utf-8') as f:
        body_xhtml = f.read()

    print(f'Content size: {len(body_xhtml)} chars')

    try:
        page_info = get_page_info(args.base_url, args.page_id, token)
    except urllib.error.HTTPError as e:
        print(f'ERROR: Failed to get page info: {e.code} {e.reason}', file=sys.stderr)
        if e.code == 401:
            print('HINT: Check your API token. It may be expired or invalid.', file=sys.stderr)
        sys.exit(1)

    current_version = page_info['version']['number']
    title = args.title or page_info['title']
    new_version = current_version + 1

    print(f'Page: "{title}" (id={args.page_id})')
    print(f'Current version: {current_version} -> New version: {new_version}')

    try:
        result = update_page(args.base_url, args.page_id, token, title, body_xhtml, new_version)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8', errors='replace') if e.fp else ''
        print(f'ERROR: Failed to update page: {e.code} {e.reason}', file=sys.stderr)
        print(f'Response: {error_body[:500]}', file=sys.stderr)
        if 'Unsupported character' in error_body:
            match = re.search(r'Unsupported character.*?:\\\\u([0-9A-Fa-f]+)', error_body)
            char_info = f' (U+{match.group(1)})' if match else ''
            print(f'HINT: Content contains unsupported Unicode characters{char_info}.', file=sys.stderr)
            print('Run md_to_confluence.py which auto-cleans problematic characters.', file=sys.stderr)
        sys.exit(1)

    final_version = result.get('version', {}).get('number', new_version)
    page_url = f'{args.base_url}/pages/viewpage.action?pageId={args.page_id}'
    print(f'SUCCESS: Page updated to version {final_version}')
    print(f'URL: {page_url}')


if __name__ == '__main__':
    main()
