#!/usr/bin/env python3
"""Convert Markdown to Confluence Storage Format (XHTML).

Converts Mermaid/PlantUML code blocks and text-art diagrams (flowcharts, tree
structures, architecture boxes) to Confluence PlantUML macros. Code blocks
remain as Confluence code macros.

Usage:
    python3 md_to_confluence.py <input.md> [output.xhtml] [--diagrams diagrams.json]

The optional --diagrams flag points to a JSON file containing custom PlantUML
diagram mappings. See README in this directory for the schema.
"""

import re
import sys
import json
import html
import os
import uuid


# ---------------------------------------------------------------------------
# Inline conversion
# ---------------------------------------------------------------------------

def escape(text):
    return html.escape(text, quote=False)


def convert_inline(text):
    """Convert inline markdown: bold, italic, inline code, links."""
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'<em>\1</em>', text)
    text = re.sub(
        r'\[([^\]]+)\]\(([^)]+)\)',
        r'<a href="\2">\1</a>',
        text,
    )
    return text


# ---------------------------------------------------------------------------
# ASCII-art diagram detection & conversion
# ---------------------------------------------------------------------------

def is_diagram_block(lines):
    """Detect if a code block contains ASCII art that should be PlantUML."""
    text = '\n'.join(lines)
    box_chars = sum(1 for c in text if c in '┌┐└┘├┤┬┴─│╭╮╰╯')
    tree_patterns = len(re.findall(r'[├└│]─*→', text))
    flow_arrows = len(re.findall(r'↓|↑|→|←', text))

    if box_chars > 5:
        return True
    if tree_patterns >= 2:
        return True
    if flow_arrows >= 3 and any(l.strip().startswith('↓') or '    ↓' in l for l in lines):
        return True
    return False


def ascii_to_plantuml(lines, context_title=''):
    """Convert ASCII art diagram to PlantUML syntax."""
    text = '\n'.join(lines)

    if '┌' in text and '┴' in text and '│' in text:
        return _convert_box_diagram(lines)

    if re.search(r'[├└│]\s*─*→', text):
        return _convert_tree_diagram(lines)

    if re.search(r'^\s*↓\s*$', text, re.MULTILINE):
        return _convert_flow_diagram(lines)

    return _convert_generic_diagram(lines)


def mermaid_to_plantuml(lines):
    """Convert common Mermaid flowchart/sequence blocks to PlantUML syntax."""
    first_line = next((l.strip() for l in lines if l.strip()), '')

    if first_line.startswith('sequenceDiagram'):
        return _convert_mermaid_sequence(lines)

    flow_match = re.match(r'^flowchart\s+(LR|RL|TB|TD|BT)\b', first_line)
    if flow_match:
        return _convert_mermaid_flowchart(lines, flow_match.group(1))

    text = '\n'.join(lines).strip()
    return '@startuml\nnote as N\n' + text.replace('end note', 'end_note') + '\nend note\n@enduml'


def _convert_mermaid_flowchart(lines, direction):
    direction_line = {
        'LR': 'left to right direction',
        'RL': 'right to left direction',
        'TB': 'top to bottom direction',
        'TD': 'top to bottom direction',
        'BT': 'bottom to top direction',
    }.get(direction, 'top to bottom direction')

    packages = []
    package_nodes = {}
    current_package = None
    declared_nodes = {}
    edges = []

    for raw in lines[1:]:
        line = raw.strip()
        if not line:
            continue

        subgraph = re.match(r'^subgraph\s+([A-Za-z_][\w-]*)\s+\[(.+?)\]\s*$', line)
        if subgraph:
            current_package = subgraph.group(2)
            packages.append(current_package)
            package_nodes.setdefault(current_package, [])
            continue

        if line == 'end':
            current_package = None
            continue

        node = re.match(r'^([A-Za-z_][\w-]*)\[(.+?)\]\s*$', line)
        if node:
            node_id, label = node.group(1), node.group(2)
            declared_nodes[node_id] = label
            if current_package:
                package_nodes.setdefault(current_package, []).append(node_id)
            continue

        edge = re.match(
            r'^([A-Za-z_][\w-]*)\s*-->\s*(?:\|(.+?)\|)?\s*([A-Za-z_][\w-]*)\s*$',
            line,
        )
        if edge:
            edges.append((edge.group(1), edge.group(3), edge.group(2) or ''))

    puml = ['@startuml', direction_line, 'skinparam packageStyle rectangle']
    puml.extend(['skinparam rectangle {', '  RoundCorner 8', '}'])

    rendered = set()
    for package in packages:
        puml.append(f'package "{_puml_label(package)}" {{')
        for node_id in package_nodes.get(package, []):
            label = declared_nodes.get(node_id, node_id)
            puml.append(f'  rectangle "{_puml_label(label)}" as {node_id}')
            rendered.add(node_id)
        puml.append('}')

    referenced = {node for edge in edges for node in edge[:2]}
    for node_id in sorted(referenced - rendered):
        label = declared_nodes.get(node_id, node_id)
        puml.append(f'rectangle "{_puml_label(label)}" as {node_id}')

    for src, dst, label in edges:
        suffix = f' : {_puml_label(label)}' if label else ''
        puml.append(f'{src} --> {dst}{suffix}')

    puml.append('@enduml')
    return '\n'.join(puml)


def _convert_mermaid_sequence(lines):
    puml = ['@startuml']

    for raw in lines[1:]:
        line = raw.strip()
        if not line:
            puml.append('')
            continue

        participant = re.match(r'^participant\s+([A-Za-z_]\w*)\s+as\s+(.+)$', line)
        if participant:
            alias, label = participant.group(1), participant.group(2)
            puml.append(f'participant "{_puml_label(label)}" as {alias}')
            continue

        note = re.match(r'^Note\s+over\s+([A-Za-z_]\w*)\s*:\s*(.+)$', line)
        if note:
            puml.append(f'note over {note.group(1)}')
            puml.append(f'  {_puml_label(note.group(2))}')
            puml.append('end note')
            continue

        msg = re.match(
            r'^([A-Za-z_]\w*)\s*(-{1,2}>>|->>|-->|->)\s*'
            r'([A-Za-z_]\w*)\s*:\s*(.+)$',
            line,
        )
        if msg:
            arrow = '-->' if msg.group(2).startswith('--') else '->'
            puml.append(f'{msg.group(1)} {arrow} {msg.group(3)} : {_puml_label(msg.group(4))}')
            continue

        if line.startswith('alt ') or line.startswith('else') or line == 'end':
            puml.append(line)
            continue

        puml.append(f"' {line}")

    puml.append('@enduml')
    return '\n'.join(puml)


def _puml_label(text):
    return text.replace('"', "'")


def _convert_box_diagram(lines):
    cells = []
    for line in lines:
        clean = line.strip()
        if clean.startswith('│') and not all(c in '│─┼┤├┬┴┌┐└┘ ' for c in clean):
            parts = re.split(r'│', clean)
            for p in parts:
                p = p.strip()
                if p and not all(c in ' ─' for c in p):
                    cells.append(p)

    if not cells:
        return '@startsalt\n{+\n' + '\n'.join(lines) + '\n}\n@endsalt'

    puml = '@startuml\nskinparam rectangle {\n  RoundCorner 10\n  BackgroundColor #F5F5F5\n}\n'
    puml += 'rectangle "' + cells[0] + '" as title #E3F2FD {\n' if cells else ''

    seen = set()
    for cell in cells[1:]:
        cell_clean = re.sub(r'[（(].*?[）)]', '', cell).strip()
        if cell_clean and cell_clean not in seen:
            safe_id = re.sub(r'[^a-zA-Z0-9_]', '_', cell_clean)[:30]
            puml += f'  rectangle "{cell}" as {safe_id}\n'
            seen.add(cell_clean)

    if cells:
        puml += '}\n'
    puml += '@enduml'
    return puml


def _convert_tree_diagram(lines):
    puml = '@startwbs\n'

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        depth = 0
        temp = line
        while temp.startswith('    ') or temp.startswith('\t'):
            depth += 1
            temp = temp[4:] if temp.startswith('    ') else temp[1:]

        if '│' in stripped:
            indent_count = line.count('│')
            depth = max(depth, indent_count)

        clean = re.sub(r'[├└│─→\s]+', ' ', stripped).strip()
        if not clean:
            continue

        prefix = '*' * (depth + 1)
        puml += f'{prefix} {clean}\n'

    puml += '@endwbs'
    return puml


def _convert_flow_diagram(lines):
    puml = '@startuml\nstart\n'

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped == '↓':
            continue

        clean = stripped.lstrip('↓ ').strip()
        if not clean:
            continue

        clean = clean.replace('"', "'")
        puml += f':{clean};\n'

    puml += 'stop\n@enduml'
    return puml


def _convert_generic_diagram(lines):
    content = '\n'.join(lines)
    return f'@startsalt\n{{+\n{content}\n}}\n@endsalt'


# ---------------------------------------------------------------------------
# Confluence macro helpers
# ---------------------------------------------------------------------------

def make_plantuml_macro(puml_code):
    """Wrap PlantUML code in Confluence macro."""
    macro_id = str(uuid.uuid4())
    return (
        f'<ac:structured-macro ac:name="plantuml" ac:schema-version="1" ac:macro-id="{macro_id}">'
        '<ac:parameter ac:name="atlassian-macro-output-type">BLOCK</ac:parameter>'
        '<ac:plain-text-body><![CDATA[' + puml_code + ']]></ac:plain-text-body>'
        '</ac:structured-macro>'
    )


def make_code_macro(lines, lang=''):
    """Wrap code in Confluence code macro."""
    body = '\n'.join(lines)
    lang_param = ''
    if lang:
        lang_map = {
            'python': 'python', 'python3': 'python', 'py': 'python',
            'go': 'go', 'golang': 'go',
            'bash': 'bash', 'sh': 'bash', 'shell': 'bash',
            'json': 'js', 'javascript': 'js', 'js': 'js',
            'sql': 'sql', 'xml': 'xml', 'html': 'html',
            'yaml': 'yaml', 'yml': 'yaml',
            'markdown': 'text', 'md': 'text', 'text': 'text',
            'plantuml': 'text',
        }
        mapped = lang_map.get(lang.lower(), 'text')
        lang_param = f'<ac:parameter ac:name="language">{mapped}</ac:parameter>'
    return (
        f'<ac:structured-macro ac:name="code">'
        f'{lang_param}'
        f'<ac:parameter ac:name="linenumbers">false</ac:parameter>'
        f'<ac:plain-text-body><![CDATA[{body}]]></ac:plain-text-body>'
        f'</ac:structured-macro>'
    )


# ---------------------------------------------------------------------------
# Custom diagram registry (loaded from external JSON or programmatically)
# ---------------------------------------------------------------------------

PLANTUML_DIAGRAMS = {}
DIAGRAM_SIGNATURES = []


def load_diagram_mappings(json_path):
    """Load custom PlantUML diagram mappings from a JSON file.

    Expected JSON schema:
    {
      "diagrams": {
        "<name>": {
          "plantuml": "<PlantUML code>",
          "match_all": ["keyword1", "keyword2"]
        }
      }
    }

    A diagram matches when ALL keywords in ``match_all`` appear in the code
    block text.
    """
    global PLANTUML_DIAGRAMS, DIAGRAM_SIGNATURES

    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    for name, entry in data.get('diagrams', {}).items():
        PLANTUML_DIAGRAMS[name] = entry['plantuml']
        keywords = entry.get('match_all', [])
        if keywords:
            def _make_matcher(kws):
                def _matcher(block_lines):
                    text = '\n'.join(block_lines)
                    return all(kw in text for kw in kws)
                return _matcher
            DIAGRAM_SIGNATURES.append((name, _make_matcher(keywords)))


def match_diagram(lines):
    """Match a code block to a predefined PlantUML diagram."""
    for name, matcher in DIAGRAM_SIGNATURES:
        if matcher(lines):
            return PLANTUML_DIAGRAMS[name]
    return None


# ---------------------------------------------------------------------------
# Table parser
# ---------------------------------------------------------------------------

def parse_table(lines):
    out = ['<table><colgroup>']
    header = [c.strip() for c in lines[0].strip('|').split('|')]
    ncols = len(header)
    for _ in range(ncols):
        out.append('<col />')
    out.append('</colgroup>')
    out.append('<thead><tr>')
    for h in header:
        out.append(f'<th><p>{convert_inline(escape(h))}</p></th>')
    out.append('</tr></thead><tbody>')
    for row_line in lines[2:]:
        cells = [c.strip() for c in row_line.strip('|').split('|')]
        out.append('<tr>')
        for cell in cells:
            out.append(f'<td><p>{convert_inline(escape(cell))}</p></td>')
        out.append('</tr>')
    out.append('</tbody></table>')
    return '\n'.join(out)


# ---------------------------------------------------------------------------
# List parser
# ---------------------------------------------------------------------------

def convert_list_block(lines):
    def parse_marker(line):
        stripped = line.lstrip()
        indent = len(line) - len(stripped)

        if stripped.startswith('- [ ] ') or stripped.startswith('- [x] '):
            checked = stripped.startswith('- [x] ')
            prefix = '&#9745; ' if checked else '&#9744; '
            return indent, 'ul', prefix + stripped[6:]
        if stripped.startswith('- ') or stripped.startswith('* '):
            return indent, 'ul', stripped[2:]
        if re.match(r'^\d+\.\s', stripped):
            return indent, 'ol', re.sub(r'^\d+\.\s', '', stripped)
        return None

    items = [parse_marker(line) for line in lines if line.strip()]
    items = [item for item in items if item]
    if not items:
        return ''

    def render_from(index, indent):
        tag = items[index][1]
        result = [f'<{tag}>']

        while index < len(items):
            item_indent, item_tag, content = items[index]
            if item_indent < indent or (item_indent == indent and item_tag != tag):
                break
            if item_indent > indent:
                nested, index = render_from(index, item_indent)
                result.append(nested)
                continue

            result.append(f'<li><p>{convert_inline(escape(content))}</p>')
            index += 1
            while index < len(items) and items[index][0] > item_indent:
                nested, index = render_from(index, items[index][0])
                result.append(nested)
            result.append('</li>')

        result.append(f'</{tag}>')
        return '\n'.join(result), index

    rendered, _ = render_from(0, items[0][0])
    return rendered


# ---------------------------------------------------------------------------
# Main converter
# ---------------------------------------------------------------------------

def md_to_confluence(md_text):
    lines = md_text.split('\n')
    output = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # Fenced code block
        if line.startswith('```'):
            lang = line[3:].strip()
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].startswith('```'):
                code_lines.append(lines[i])
                i += 1
            i += 1
            lang_lower = lang.lower()

            if lang_lower == 'mermaid':
                output.append(make_plantuml_macro(mermaid_to_plantuml(code_lines)))
                continue

            if lang_lower == 'plantuml':
                output.append(make_plantuml_macro('\n'.join(code_lines)))
                continue

            if not lang or lang in ('', 'text', 'plaintext'):
                puml = match_diagram(code_lines)
                if puml:
                    output.append(make_plantuml_macro(puml))
                    continue
                if is_diagram_block(code_lines):
                    puml_code = ascii_to_plantuml(code_lines)
                    output.append(make_plantuml_macro(puml_code))
                    continue

            if lang == 'markdown':
                body = '\n'.join(code_lines)
                output.append(
                    f'<ac:structured-macro ac:name="code">'
                    f'<ac:parameter ac:name="language">text</ac:parameter>'
                    f'<ac:parameter ac:name="linenumbers">false</ac:parameter>'
                    f'<ac:plain-text-body><![CDATA[{body}]]></ac:plain-text-body>'
                    f'</ac:structured-macro>'
                )
                continue

            output.append(make_code_macro(code_lines, lang))
            continue

        # Heading
        if line.startswith('#'):
            m = re.match(r'^(#{1,6})\s+(.*)', line)
            if m:
                level = len(m.group(1))
                title = convert_inline(escape(m.group(2)))
                output.append(f'<h{level}>{title}</h{level}>')
                i += 1
                continue

        # Horizontal rule
        if line.startswith('---') and len(line.strip()) >= 3 and all(c == '-' for c in line.strip()):
            output.append('<hr />')
            i += 1
            continue

        # Table
        if '|' in line and i + 1 < len(lines) and re.match(r'^\|[\s\-:|]+\|$', lines[i + 1].strip()):
            table_lines = []
            while i < len(lines) and '|' in lines[i]:
                table_lines.append(lines[i])
                i += 1
            output.append(parse_table(table_lines))
            continue

        # Blockquote
        if line.startswith('>'):
            quote_lines = []
            while i < len(lines) and lines[i].startswith('>'):
                quote_lines.append(lines[i].lstrip('> ').strip())
                i += 1
            content = convert_inline(escape(' '.join(quote_lines)))
            output.append(
                f'<ac:structured-macro ac:name="info">'
                f'<ac:rich-text-body><p>{content}</p></ac:rich-text-body>'
                f'</ac:structured-macro>'
            )
            continue

        # List
        stripped = line.lstrip()
        if (stripped.startswith('- ') or stripped.startswith('* ') or
            re.match(r'^\d+\.\s', stripped) or
            stripped.startswith('- [ ]') or stripped.startswith('- [x]')):
            list_lines = []
            while i < len(lines):
                s = lines[i].lstrip()
                if (s.startswith('- ') or s.startswith('* ') or
                    re.match(r'^\d+\.\s', s) or
                    s.startswith('- [ ]') or s.startswith('- [x]') or
                    (lines[i].startswith('  ') and s)):
                    list_lines.append(lines[i])
                    i += 1
                elif not s:
                    if i + 1 < len(lines):
                        ns = lines[i + 1].lstrip()
                        if (ns.startswith('- ') or ns.startswith('* ') or
                            re.match(r'^\d+\.\s', ns)):
                            list_lines.append(lines[i])
                            i += 1
                            continue
                    break
                else:
                    break
            output.append(convert_list_block(list_lines))
            continue

        # Blank line
        if line.strip() == '':
            i += 1
            continue

        # Paragraph
        output.append(f'<p>{convert_inline(escape(line))}</p>')
        i += 1

    return '\n'.join(output)


# ---------------------------------------------------------------------------
# Emoji / unsupported-char cleaner
# ---------------------------------------------------------------------------

EMOJI_REPLACEMENTS = {
    '\u2705': '(/)',       # ✅
    '\u274c': '(x)',       # ❌
    '\u26a0\ufe0f': '(!)', # ⚠️
    '\u26a0': '(!)',       # ⚠ (without variant selector)
    '\u2611': '(/)',       # ☑
    '\u2610': '(x)',       # ☐
    '\u2b50': '*',         # ⭐
}


def clean_unsupported_chars(text):
    """Replace emoji and non-BMP chars that Confluence rejects."""
    for emoji, replacement in EMOJI_REPLACEMENTS.items():
        text = text.replace(emoji, replacement)
    # Strip remaining non-BMP characters (U+10000 and above)
    text = re.sub(r'[\U00010000-\U0010FFFF]', '?', text)
    return text


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Convert Markdown to Confluence XHTML')
    parser.add_argument('input', help='Input Markdown file')
    parser.add_argument('output', nargs='?', default=None, help='Output XHTML file (default: <input>_confluence.xhtml)')
    parser.add_argument('--diagrams', default=None, help='JSON file with custom PlantUML diagram mappings')
    args = parser.parse_args()

    if args.diagrams:
        load_diagram_mappings(args.diagrams)

    output_path = args.output or args.input.replace('.md', '_confluence.xhtml')

    with open(args.input, 'r', encoding='utf-8') as f:
        md_text = f.read()

    xhtml = md_to_confluence(md_text)
    xhtml = clean_unsupported_chars(xhtml)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(xhtml)

    plantuml_count = xhtml.count('ac:name="plantuml"')
    code_count = xhtml.count('ac:name="code"')
    print(f"Converted: {args.input} -> {output_path}")
    print(f"Output size: {len(xhtml)} chars")
    print(f"PlantUML diagrams: {plantuml_count}")
    print(f"Code blocks: {code_count}")


if __name__ == '__main__':
    main()
