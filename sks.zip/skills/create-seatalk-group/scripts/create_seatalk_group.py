#!/usr/bin/env python3
import argparse
import logging
import os
import sys
from pathlib import Path
from typing import List

import tomllib

import requests

DEFAULT_GROUP_OWNER = "jeeery.liu@shopee.com"
SEATALK_OPENAPI_BASE = "https://openapi.seatalk.io"
CODEX_CONFIG_PATH = Path.home() / ".codex" / "config.toml"

logger = logging.getLogger(__name__)
if not logger.handlers:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def normalize_email(raw: str) -> str:
    value = (raw or "").strip()
    if not value:
        return ""
    if "@" not in value:
        value = f"{value}@shopee.com"
    return value


def parse_members(raw_members: str) -> List[str]:
    if not raw_members:
        return []
    tokens = []
    for part in raw_members.replace(",", " ").split():
        email = normalize_email(part)
        if email:
            tokens.append(email)
    return tokens


def dedupe_keep_order(items: List[str]) -> List[str]:
    seen = set()
    result = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def load_seatalk_credentials() -> tuple[str, str]:
    app_id = os.environ.get("SEATALK_APP_ID", "").strip()
    app_secret = os.environ.get("SEATALK_APP_SECRET", "").strip()
    if app_id and app_secret:
        return app_id, app_secret

    if CODEX_CONFIG_PATH.is_file():
        try:
            with CODEX_CONFIG_PATH.open("rb") as f:
                config = tomllib.load(f)
        except (OSError, tomllib.TOMLDecodeError) as exc:
            logger.error("failed to read %s: %s", CODEX_CONFIG_PATH, exc)
            return "", ""

        seatalk_config = config.get("seatalk")
        if isinstance(seatalk_config, dict):
            app_id = str(seatalk_config.get("app_id", "")).strip()
            app_secret = str(seatalk_config.get("app_secret", "")).strip()
            if app_id and app_secret:
                return app_id, app_secret

    return "", ""


def get_access_token() -> str:
    app_id, app_secret = load_seatalk_credentials()
    if not app_id or not app_secret:
        logger.error(
            "Seatalk credentials not found. Set SEATALK_APP_ID / SEATALK_APP_SECRET or configure [seatalk] in %s",
            CODEX_CONFIG_PATH,
        )
        return ""

    response = requests.post(
        f"{SEATALK_OPENAPI_BASE}/auth/app_access_token",
        json={"app_id": app_id, "app_secret": app_secret},
        timeout=5,
    )
    if response.status_code != 200:
        logger.error("get_access_token failed: %s", response.text)
        return ""

    payload = response.json()
    if payload.get("code") != 0:
        logger.error("get_access_token failed: %s", response.text)
        return ""

    return payload.get("app_access_token", "")


def get_employee_code_map(access_token: str, *emails: str) -> dict:
    response = requests.post(
        f"{SEATALK_OPENAPI_BASE}/contacts/v2/get_employee_code_with_email",
        json={"emails": list(emails)},
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=5,
    )
    if response.status_code != 200:
        logger.error("get_employee_code_map failed: %s", response.text)
        return {}

    payload = response.json()
    if payload.get("code") != 0:
        logger.error("get_employee_code_map failed: %s", response.text)
        return {}

    result = {}
    for item in payload.get("employees", []):
        if item.get("code") == 0 and item.get("employee_status") == 2:
            result[item["email"]] = item["employee_code"]
    return result


def find_invalid_email(*emails: str) -> str:
    access_token = get_access_token()
    if not access_token:
        return emails[0] if emails else ""

    employee_code_map = get_employee_code_map(access_token, *emails)
    for email in emails:
        if email not in employee_code_map:
            return email
    return ""


def create_seatalk_group(access_token: str, group_name: str, group_owner: str, *group_members: str) -> str:
    emails = [*group_members, group_owner]
    employee_code_map = get_employee_code_map(access_token, *emails)
    if group_owner not in employee_code_map:
        logger.error("group owner is invalid or inactive: %s", group_owner)
        return ""

    group_member_list = [{"employee_code": employee_code_map[group_owner], "role": 1}]
    for member in group_members:
        employee_code = employee_code_map.get(member)
        if not employee_code:
            logger.error("group member is invalid or inactive: %s", member)
            return ""
        group_member_list.append({"employee_code": employee_code, "role": 0})

    payload = {
        "group_name": group_name,
        "group_settings": {"chat_history_for_new_members": 2},
        "group_owner": employee_code_map[group_owner],
        "group_member_list": group_member_list,
    }
    response = requests.post(
        f"{SEATALK_OPENAPI_BASE}/messaging/v2/group_chat/create_group",
        json=payload,
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=5,
    )
    if response.status_code != 200:
        logger.error("create_seatalk_group failed: %s", response.text)
        return ""

    result = response.json()
    if result.get("code") != 0:
        logger.error("create_seatalk_group failed: %s", response.text)
        return ""

    return result.get("group_id", "")


def main() -> int:
    parser = argparse.ArgumentParser(description="Create Seatalk group with validation.")
    parser.add_argument("--group-name", required=True, help="Seatalk group name")
    parser.add_argument(
        "--group-owner",
        default=DEFAULT_GROUP_OWNER,
        help=f"Owner email or name (default: {DEFAULT_GROUP_OWNER})",
    )
    parser.add_argument(
        "--members",
        default="",
        help="Comma or space separated member emails/names, e.g. 'tom,jerry@shopee.com'",
    )
    parser.add_argument(
        "--confirm-create",
        action="store_true",
        help="Actually create group after validation and preview.",
    )
    args = parser.parse_args()

    owner_input = args.group_owner if args.group_owner else DEFAULT_GROUP_OWNER
    owner = normalize_email(owner_input)
    if not owner:
        print("group_owner 为空，且默认群主不可用，创建终止。")
        return 1

    members = parse_members(args.members)
    members = [member for member in members if member != owner]
    members = dedupe_keep_order(members)

    all_emails = [owner, *members]
    invalid_email = find_invalid_email(*all_emails)
    if invalid_email:
        print(f"发现非法邮箱：{invalid_email}，已停止创建群。")
        return 2

    print("邮箱校验通过，请确认以下建群信息：")
    print(f"group_name: {args.group_name}")
    print(f"group_owner: {owner}")
    print(f"group_members: {members}")

    if not args.confirm_create:
        print("未执行创建。请确认无误后，使用 --confirm-create 再次执行。")
        return 3

    access_token = get_access_token()
    if not access_token:
        print("获取 access_token 失败，创建终止。")
        return 1

    group_id = create_seatalk_group(access_token, args.group_name, owner, *members)
    if not group_id:
        print("创建群失败，请检查日志。")
        return 1

    print("创建群成功")
    print(f"group_id: {group_id}")
    print(f"group_owner: {owner}")
    print(f"group_members: {members}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
