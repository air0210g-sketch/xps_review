---
name: create-seatalk-group
description: 使用项目内 scripts/create_seatalk_group.py 创建 Seatalk 群组。用户提供 group_name、group_owner、group_members 时使用。支持将仅名字（如 tom）自动转为 tom@shopee.com；若未提供群主则默认 jeeery.liu@shopee.com。创建前必须先校验邮箱，若有非法邮箱则直接告知并停止创建。校验通过后先展示参数并向用户确认，确认后才真正创建。
---

# Create Seatalk Group

## 适用场景

- 用户要求“创建 Seatalk 群/建群/拉群”。
- 用户提供了群名 `group_name`、群主 `group_owner`、群成员 `group_members`（可为邮箱或纯名字）。

## 执行规则（严格）

1. 收集参数：
   - `group_name`：群名（必填）
   - `group_owner`：群主邮箱或名字（选填，默认 `jeeery.liu@shopee.com`）
   - `group_members`：群成员邮箱或名字（可多个）
2. 标准化邮箱：
   - 去除首尾空格。
   - 若不包含 `@`，自动补全为 `<name>@shopee.com`。
3. 创建前校验（必须）：
   - 先调用脚本做邮箱校验。
   - 若返回非空邮箱，直接回复用户“该邮箱非法：<email>”，并停止，不得创建群。
4. 校验通过后，先展示参数并向用户确认：
   - 展示 `group_name`、`group_owner`、`group_members`。
   - 优先使用可点击选项框让用户确认（`确认创建` / `取消`）。
   - 若当前环境不支持选项框，再回退为文本确认“是否确认创建”。
5. 仅在用户明确确认后创建：
   - 获取 access token。
   - 调用脚本执行建群。

## 凭证配置

- 脚本优先读取环境变量 `SEATALK_APP_ID`、`SEATALK_APP_SECRET`。
- 若环境变量不存在，则回退读取 `~/.codex/config.toml` 的 `[seatalk]` 配置。
- 推荐配置示例：

```toml
[seatalk]
app_id = "your_app_id"
app_secret = "your_app_secret"
```

- 如果脚本提示找不到 `app_secret` 或 Seatalk 凭证缺失，提醒用户去 `~/.codex/config.toml` 配置 `[seatalk]`，或设置对应环境变量后再重试。

## 执行命令

第一步：仅预览与校验（不会创建群）：

```bash
python ~/.cursor/skills/create-seatalk-group/scripts/create_seatalk_group.py \
  --group-name "<group_name>" \
  --members "<member1,member2,...>"
```

第二步：用户确认后，再执行创建：

```bash
python ~/.cursor/skills/create-seatalk-group/scripts/create_seatalk_group.py \
  --group-name "<group_name>" \
  --members "<member1,member2,...>" \
  --confirm-create
```

说明：
- `--members` 可用逗号分隔，也可混合空格和逗号。
- 用户输入 `tom` 会自动转成 `tom@shopee.com`。
- 不传 `--group-owner` 时，默认使用 `jeeery.liu@shopee.com`。
- 不加 `--confirm-create` 时，脚本只做校验和预览，不会创建群。
- 如果缺少 Seatalk 凭证，优先提示用户检查 `~/.codex/config.toml` 的 `[seatalk]` 配置是否完整。

## 输出要求

- 校验失败：明确指出非法邮箱，并说明“已停止创建群”。
- 校验通过但未确认：展示参数，并提示等待用户确认。
- 凭证缺失：明确提示去 `~/.codex/config.toml` 配置 `[seatalk].app_id` / `[seatalk].app_secret`，或设置环境变量。
- 创建成功：返回 `group_id`，并回显标准化后的 owner 与 members。

## 交互确认（选项框）

校验通过后，优先用结构化提问工具展示可点击选项：

- 问题：`请确认是否创建该 Seatalk 群？`
- 选项 1：`确认创建`
- 选项 2：`取消`

只有用户点击 `确认创建`，才执行带 `--confirm-create` 的创建命令。

## 示例对话模板

### 模板 1：信息完整，先预览后确认

用户：
- 帮我建个群，群名 `live-issue-20260414`，群主 `tom`，成员 `jerry, alice@shopee.com`

代理内部参数：
- `group_name`: `live-issue-20260414`
- `group_owner`: `tom@shopee.com`
- `group_members`: `["jerry@shopee.com", "alice@shopee.com"]`

第一步（预览校验）：
```bash
python ~/.cursor/skills/create-seatalk-group/scripts/create_seatalk_group.py \
  --group-name "live-issue-20260414" \
  --group-owner "tom@shopee.com" \
  --members "jerry@shopee.com,alice@shopee.com"
```

代理回复（示例）：
- 邮箱校验通过，请确认以下建群信息：
- `group_name: live-issue-20260414`
- `group_owner: tom@shopee.com`
- `group_members: ['jerry@shopee.com', 'alice@shopee.com']`
- 展示可点击选项：`确认创建` / `取消`。

第二步（用户确认后执行）：
```bash
python ~/.cursor/skills/create-seatalk-group/scripts/create_seatalk_group.py \
  --group-name "live-issue-20260414" \
  --group-owner "tom@shopee.com" \
  --members "jerry@shopee.com,alice@shopee.com" \
  --confirm-create
```

### 模板 2：信息不完整，先追问再执行

用户：
- 帮我拉个 Seatalk 群，成员 `tom, jerry`

代理回复：
- 请补充 `group_name`。`group_owner` 未提供时会默认使用 `jeeery.liu@shopee.com`。

### 模板 3：命中非法邮箱，终止创建

用户：
- 建群，群名 `xxx`，群主 `tom`，成员 `bad_email, jerry`

代理行为：
- 将输入标准化后先校验邮箱。
- 如果脚本返回非法邮箱，回复：
  - `发现非法邮箱：<email>，已停止创建群。`
- 不执行创建群命令。

### 模板 5：缺少 Seatalk 凭证，停止创建

用户：
- 建群，群名 `xxx`，群主 `tom`，成员 `jerry`

代理行为：
- 先执行预览校验脚本。
- 如果脚本提示缺少 `app_id` / `app_secret` 或获取 access token 失败，回复：
  - `当前缺少 Seatalk 凭证，请先在 ~/.codex/config.toml 中配置 [seatalk].app_id 和 [seatalk].app_secret，或设置环境变量 SEATALK_APP_ID / SEATALK_APP_SECRET。`
- 不执行创建群命令。

### 模板 4：可复用的参数抽取格式

当用户是自然语言描述时，先在内部整理为：

```text
group_name=<string>
group_owner=<string>
group_members=<comma-separated-string>
```

再按“执行命令”章节调用脚本，避免漏参或顺序错误。
