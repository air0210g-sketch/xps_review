# 附录：分支矩阵与自检清单

## 分支矩阵（模板）

在动笔前填表（可贴在 PR 描述或任务里）：

| 用例 ID | 前置条件（开关/鉴权/入参） | 期望返回类型或行为 |
|--------|---------------------------|-------------------|
| T1     |                           |                   |

## 自检清单

- [ ] `patches := gomonkey.NewPatches(); defer patches.Reset()`
- [ ] 链式 `ApplyFunc` 签名与源码一致
- [ ] 无 `t.Parallel()`（与本文件内包级打桩并存时）
- [ ] **对同一跨包函数**（如 `config.GetStringWithContext`）多种返回值场景：**单顶层 `Test` + `t.Run`**，勿拆多个 `TestFoo_bar` 顶层函数（避免 Reset/内联后打桩不命中）
- [ ] 每个 `t.Run` 内独立 `NewPatches` + `defer Reset()`（子测试顺序执行）
- [ ] `interface{}` 类型断言与生产返回值 **值/指针** 一致（Handler 场景）
- [ ] `stub` 仅实现被调接口方法，嵌入 `nil` 大 interface
- [ ] `context`：`NewRequestWithContext` / `NewBaseServer` 不传裸 `nil` context（满足 staticcheck SA1012）
- [ ] 用户要求无 build tag 时，测试文件顶部无条件编译标签
- [ ] 多顶层 Test 已出现断言异常时：先合并为单顶层 Test；仍不稳再加 `go test -gcflags=all=-l`

## 反模式（本仓库实测）

| 反模式 | 风险 |
|--------|------|
| 多个顶层 `TestXxx_caseN` 均 `ApplyFunc` 同一符号 | 后续用例可能未走桩，读到真实 Apollo/配置或错误分支 |
| 子测试 `t.Parallel` + 包级 `ApplyFunc` | 补丁互相覆盖，结果随机 |

## 覆盖率命令（可选）

```bash
go test -coverprofile=c.out -run '^TestYour$' ./your/package/ && go tool cover -func=c.out | grep your_file.go
```
