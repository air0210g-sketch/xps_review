---
name: golang-gomonkey-access-handler-tests
description: >-
  Authors Go unit tests using agiledragon/gomonkey/v2 with NewPatches() chain
  style, no build tags. Covers two main layers: (1) access/HTTP handlers
  (RestfulContext, auth, service stubs) and (2) service/impl layer (mock
  singleton services, ApplyPrivateMethod, functional-option fixtures).
  Documents stable test structure (single top-level Test + t.Run), no t.Parallel,
  and -gcflags fallback. Use for handler branch coverage, IDOR/mask paths,
  service-layer business logic (e.g. matching, calculation), or util functions
  that call config/logger.
---

# Go gomonkey 单测（Access Handler + Service 层）

## 目标

在**不引入 build tag** 的前提下，用 **gomonkey** 写单测，典型场景包括：

- **access/http（或同类）** 薄 Handler：隔离 `ReadQuery`、`auth`、`service/impl`、业务 `util` 等；**表驱动**覆盖 `interface{}` 类型断言、枚举分支、「开关 AND 条件」（如 IDOR + 司机 ID）。
- **service/impl 层**核心业务逻辑：隔离 Repository / 外部 Service 依赖，直接实例化 `&ServiceImpl{}`，通过 `ApplyPrivateMethod` 打桩私有方法、`ApplyFunc` 打桩 `config.*` / `Get*Service()` 单例获取器等，覆盖核心业务分支（如多轮匹配、分组排序、降级逻辑）。
- **同包 util / 小函数**：对 **`config.GetStringWithContext`**、`logger.CtxLogErrorf` 等跨包函数做 `ApplyFunc`，覆盖空配置 / 合法 JSON / 解析失败回退等分支。

## 何时使用

- 用户要求用 **gomonkey** 提升某 Handler **或 Service 实现**的分支覆盖率。
- 约束包含：**无 build tag**、**`gomonkey.NewPatches()` 链式** `ApplyFunc` / `ApplyMethod`。
- Handler 依赖 **`*restful.Context`**、`auth.GetAuthUser`、大包 **service interface**。
- Service 实现依赖其他 Service 单例（通过 `Get*Service()` 获取）、Repository、config 开关、私有方法。
- 同包函数依赖 **chassis `config` / `logger`** 等，需打桩才能稳定覆盖分支。

## 何时不要用

- 无需打桩即可测的纯函数或仅依赖 interface 由 mockgen 注入的场景（不必 gomonkey）。
- 需要真实中间件链路的集成测试（用 `integration-test-generator`）。

## 执行步骤（Agent 按序）

### 1) 读目标代码，列分支矩阵

- 打开 Handler 函数，列出：**类型断言**各分支、**if/else** 的 AND 条件（如 `GetXxxSwitch && driverID != yyy`）。
- 每个独立组合对应表驱动的一行（或独立子测试）。

### 2) 选定测试文件与包名

- 与 Handler **同包** `package http`（或目标包），文件命名建议 `<handler>_test.go` 或 `<feature>_branch_test.go`，避免与巨型单测文件混挤。
- **禁止**为 gomonkey 加 `//go:build` 条件；用户未要求则不加任何 build tag。

### 3) 构造 `*restful.Context`

- 使用 `http.NewRequestWithContext(context.Background(), ...)` + `go-restful` 包装 + `restful.NewBaseServer(context.Background(), go_restful.NewRequest(req), nil)`（与仓库 `middleware/auth` 测试用法对齐；首参勿长期传 `nil` context）。
- Query 可被 `ReadQuery` mock 忽略时仍建议 URL 带合法占位参数，便于日后去掉 mock。

### 4) 大包 `service` interface：嵌入 nil + 只实现被调方法

```go
type stubSvc struct {
    service.SomeServiceInterface // nil，禁止调用其它方法
    getFoo func(ctx context.Context, ...) (interface{}, error)
}
func (s *stubSvc) GetFoo(ctx context.Context, ...) (interface{}, error) {
    if s.getFoo != nil {
        return s.getFoo(ctx, ...)
    }
    return nil, nil
}
```

- 仅 override Handler **实际会调用**的接口方法；返回值类型与生产一致（注意 **值类型 vs 指针** 与 Handler 里 `.(T)` / `.(*T)` 一致）。

### 5) `auth.AuthUser`：本地小 struct 实现全接口

- 实现 `GetUserId` 等所有方法，未用字段返回零值（参考仓库内 `webAuthUser` / 测试专用 user）。

### 6) Service 层打桩模式

当测试目标是 `service/impl/` 下的 Service 实现而非 access Handler 时：

**6a) 直接实例化 Service struct**

```go
svc := &RouteMatchDriverCalculationService{}
```

在同包内（`package impl`），直接构造零值 struct 即可，无需通过 Wire。未打桩的依赖字段为 nil，只要测试路径不触达即可。

**6b) 用 `ApplyPrivateMethod` 打桩私有方法**

Service 层常将外部调用（DB 查询、RPC）封装为私有方法，用 `ApplyPrivateMethod` 隔离：

```go
patches.ApplyPrivateMethod(&RouteMatchDriverCalculationService{},
    "fillOrderListAndStationID",
    func(_ *RouteMatchDriverCalculationService, ctx context.Context, route *define.RouteInfo) error {
        return nil
    })
```

- 第一参数为**零值指针 struct**（类型信息即可），第二参数为**私有方法名字符串**。
- 替换函数签名**必须**与原方法一致（包括 receiver 类型为值还是指针）。

**6c) 打桩 `config.*` 开关函数**

Service 层大量依赖 `config.IsXxxEnabled` / `config.GetXxxThreshold` 等开关函数：

```go
patches.ApplyFunc(config.IsRouteMatchMultiRoundEnabled,
    func(ctx context.Context) bool { return true })
patches.ApplyFunc(config.GetRouteMatchDriverDriverScoreThreshold,
    func(ctx context.Context) float64 { return 5.0 })
```

**6d) 打桩 `Get*Service()` 单例获取器**

跨 Service 依赖通常通过 `GetXxxService()` 函数获取单例，直接 `ApplyFunc` 返回 stub：

```go
patches.ApplyFunc(GetDriverService,
    func() DriverServiceInterface { return &stubDriverSvc{} })
```

**6e) 抽取公共打桩为 helper 函数**

当多个测试用例需要相同的基础打桩时，抽取为 `patchCommonDeps`：

```go
func patchCommonDeps(patches *gomonkey.Patches) {
    patches.ApplyPrivateMethod(&RouteMatchDriverCalculationService{},
        "fillOrderListAndStationID",
        func(_ *RouteMatchDriverCalculationService, ctx context.Context, route *define.RouteInfo) error {
            return nil
        })
    patches.ApplyPrivateMethod(&RouteMatchDriverCalculationService{},
        "loadVehicleCapacity",
        func(_ *RouteMatchDriverCalculationService, ctx context.Context, param *define.ClusterRouteMatchDriverParam) {
        })
}
```

### 6f) 测试数据构造：Functional Options（Fixture）模式

对于复杂的 `define.*` 结构体，推荐使用 **functional options** 构造 helper，避免每个测试用例重复拼装大 struct：

```go
func mkDriver(id uint64, cluster string, score float64,
    opts ...func(*define.RouteMatchAvailableDriver)) define.RouteMatchAvailableDriver {
    d := define.RouteMatchAvailableDriver{
        DriverID:  id,
        DriverScore: score,
        WheelTypeID: wheelType2WH,
        PreferredClusterList: []define.PreferredCluster{
            {ClusterName: cluster, ClusterPriority: 1},
        },
    }
    for _, opt := range opts {
        opt(&d)
    }
    return d
}

func withOverride() func(*define.RouteMatchAvailableDriver) {
    return func(d *define.RouteMatchAvailableDriver) { d.IsOverrideDriver = true }
}
func withWheelType(wt uint64) func(*define.RouteMatchAvailableDriver) {
    return func(d *define.RouteMatchAvailableDriver) {
        d.WheelTypeID = wt; d.VehicleTypeID = wt
    }
}
```

使用时组合语义清晰：`mkDriver(100, "C1", 10.0, withOverride(), withWheelType(4))`

同理对 Route、Config 等结构也可构造 `mkRoute()`、`defaultConfig()` helper。

### 7) gomonkey：NewPatches + 链式 + defer Reset

```go
patches := gomonkey.NewPatches()
defer patches.Reset()
patches.
    ApplyFunc(http_utils.ReadQuery, func(*restful.Context, interface{}) error { return nil }).
    ApplyFunc(auth.GetAuthUser, func(*restful.Context) auth.AuthUser { return &testAuthUser{id: uid} }).
    ApplyFunc(pkgimpl.SideEffectFunc, func(context.Context, interface{}) {})
// 继续 ApplyFunc(doUtil.SomeSwitch, ...) 等
```

- **签名**必须与真实函数一致（含包路径下的导出名）。
- 对 **变量**（如 `var Err = errors.New`）打桩用 `ApplyGlobalVar`，勿与 `ApplyFunc` 混淆。

### 8) 顶层 `Test` 结构与 gomonkey 稳定性（实践结论，易踩坑）

对**同一个**包级/跨包函数（如 `config.GetStringWithContext`）要打多种返回值、且被测函数在包内多次调用时：

- **推荐**：**一个顶层 `TestXxx`**，内用 **`t.Run` 子测试** 顺序跑各场景；**每个子测试**内 `patches := gomonkey.NewPatches(); defer patches.Reset()`，再链式 `ApplyFunc`。
- **避免**：为每个场景拆成多个顶层 `TestXxx_empty`、`TestXxx_validJSON`……在 delivery-service 实测中，若前一顶层 Test 已 `Reset` 对 `GetStringWithContext` 的打桩，后续顶层 Test 可能出现**打桩未命中**（被测代码走到真实配置或错误分支），表现为偶发/稳定失败（与内联、调用路径有关）。
- **子测试之间**仍禁止 `t.Parallel()`（见下节）。

### 9) 并发：`t.Parallel` 规则

- **禁止**在与本测试**同一进程内**对包级函数打桩的同时使用 `t.Parallel()`（含外层与子测试），否则补丁互相覆盖。
- 若整仓大量并行跑测试，仍可能与其他包的 gomonkey 冲突；本 skill 默认 **单测文件内顺序执行**。

### 10) 断言

- 优先 `testify/require`：类型断言结果、关键字段、脱敏分支可用「敏感字段不等于原文」断言。
- 覆盖 **默认/else** 分支时显式使用非法枚举值（如 `ReturnType: 99`）。

### 11) 运行与不稳定排查

- 常规：`go test -count=1 -run '^TestYour$' ./path/to/package/ -v`（单顶层 Test 时 `-run '^TestFoo$'` 会匹配其下所有子测试）。
- 若补丁因**内联**不稳定，提示使用：`-gcflags=all=-l`（与仓库 `common/middleware/show_sensitive_test.go` 等注释一致）。
- 多顶层 Test 已出现打桩异常时，**优先合并为单顶层 Test + `t.Run`**，再仍不稳则加 `-gcflags=all=-l`。

## 输入与输出约定

- **输入**：目标代码定位（包路径、函数/方法名、可选行号）、待覆盖分支描述、约束（无 build tag、链式 Patches）。目标可以是 access Handler，也可以是 service/impl 层的 Service 方法。
- **输出**：落盘 `*_test.go`；必要时在回复中给出 `go test` 与覆盖率命令。

## 本仓库参考示例

| 场景 | 层级 | 路径 |
|------|------|------|
| Handler：`GetDeliveryOrderInfo` 中 `GetDeliveryOrderDetailsResp` + IDOR 分支 | access | `apps/delivery_order/access/http/mobile_get_delivery_order_info_details_resp_test.go` |
| Util：`GetIDORMaskFields` 打桩 `config` + `logger`，单顶层 `Test` + `t.Run` | access/util | `apps/delivery_order/util/delivery_order_apollo_util_idor_mask_test.go` |
| Service：多轮匹配全流程（1696 行 35 TC），含 fixture、ApplyPrivateMethod、patchCommonDeps | service/impl | `apps/route_match_driver/service/impl/multi_round_match_test.go` |
| Service：司机评分降级逻辑 | service/impl | `apps/route_match_driver/service/impl/driver_score_fallback_test.go` |
| Service：相邻 Cluster SSO 降级 | service/impl | `apps/route_match_driver/service/impl/neighboring_sso_degradation_test.go` |

## Eval 对齐（最小用例）

| Case | 用户说法（摘要） | 期望 Agent 行为 |
|------|------------------|----------------|
| A | 按无 build tag + NewPatches 链式给某 Handler 分支写表驱动单测 | 同包测试文件、链式 ApplyFunc、分支矩阵齐全、无 t.Parallel |
| B | 能否 Parallel？ | 明确禁止与包级打桩并行；说明全局补丁范围 |
| C | 给 `GetIDORMaskFields` 这类 util 写多分支 gomonkey 单测 | 单顶层 `Test` + `t.Run`；勿拆多个顶层 `Test*` 打同一 `config.GetStringWithContext`；子测试内各自 Patches/Reset |
| D | 给 service/impl 层的 `ProcessEventRouteMatchDriverMultiRound` 写单测 | 直接实例化 `&ServiceImpl{}`；用 `ApplyPrivateMethod` 打桩 DB/RPC 私有方法；用 `patchCommonDeps` 抽取公共桩；用 fixture（`mkDriver`/`mkRoute`）构造数据 |
| E | Service 层测试需要 mock `GetXxxService()` 返回的依赖 | 用 `ApplyFunc(GetXxxService, ...)` 返回 stub 实现；stub 嵌入 nil interface 仅实现被调方法 |

## 可扩展点

- 需要 `ApplyMethod` 时优先 `reflect.TypeOf((*Concrete)(nil)).Elem()` 取类型。
- 更复杂 Handler 可将「分支矩阵」拆到 [reference.md](references/reference.md)（若后续增补）。

## 与 skill-build-pipeline 的关系

- 新建或大改本 skill 后，可按 `.cursor/skills/skill-build-pipeline/SKILL.md` 跑 **skill-evaluator → skill-reviewer** 再定稿；机器可读摘要见同目录 `skill.spec.json`。
