#!/usr/bin/env python3
"""查询 SPX OpenAPI：fleet_order、driver、station/site/hub、delivery 域订单和 AT。"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from tracking_status import names_for_code, primary_name


MARKET_DOMAINS = {
    "ID": "https://spx.shopee.co.id/",
    "MY": "https://spx.shopee.com.my/",
    "TH": "https://spx.shopee.co.th/",
    "PH": "https://spx.shopee.ph/",
    "VN": "https://spx.shopee.vn/",
    "SG": "https://spx.shopee.sg/",
    "TW": "https://spx.shopee.tw/",
    "BR": "https://spx.shopee.com.br/",
}

DELIVERY_SERVICE_BASE_URLS = {
    "ID": "https://spx-delivery-service.ssc.shopee.co.id/",
    "MY": "https://spx-delivery-service.ssc.shopee.com.my/",
    "TH": "https://spx-delivery-service.ssc.shopee.co.th/",
    "PH": "https://spx-delivery-service.ssc.shopee.ph/",
    "VN": "https://spx-delivery-service.ssc.shopee.vn/",
    "SG": "https://spx-delivery-service.ssc.shopee.sg/",
    "TW": "https://spx-delivery-service.ssc.shopee.tw/",
    "BR": "https://spx-delivery-service.ssc.shopee.com.br/",
}

CONFIG_PATH = Path.home() / ".codex" / "config.toml"
CONFIG_SECTION = "spx_openapi"

DEFAULT_OPERATOR = "delivery-test"
DEFAULT_ENV = "live"
DEFAULT_TIMEOUT_SECONDS = 20
DEFAULT_FO_SELECT_FIELDS = [
    "shipment_id",
    "display_status",
    "status",
    "dest_station_id",
    "return_station_id",
    "current_station_id",
    "transfer_direction",
    "lm_hub_receive_time",
    "returned_time",
]


class ConfigError(RuntimeError):
    pass


def _load_toml(path: Path) -> dict[str, Any]:
    try:
        import tomllib  # Python 3.11+

        with path.open("rb") as f:
            return tomllib.load(f)
    except ModuleNotFoundError:
        return _load_simple_toml(path)


def _load_simple_toml(path: Path) -> dict[str, Any]:
    data: dict[str, Any] = {}
    section: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section_name = line[1:-1].strip()
            section = data.setdefault(section_name, {})
            continue
        if section is None or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value.startswith(("'", '"')) and value.endswith(("'", '"')):
            parsed_value: Any = value[1:-1]
        elif value.lower() in {"true", "false"}:
            parsed_value = value.lower() == "true"
        else:
            try:
                parsed_value = int(value)
            except ValueError:
                parsed_value = value.split("#", 1)[0].strip()
        section[key] = parsed_value
    return data


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        raise ConfigError(
            f"缺少 {CONFIG_PATH}。请先添加 [spx_openapi] 配置："
            '\njwt_account = "xxx"\njwt_secret = "xxx"'
        )

    config = _load_toml(CONFIG_PATH)
    section = config.get(CONFIG_SECTION)
    if not isinstance(section, dict):
        raise ConfigError(
            f"缺少 {CONFIG_PATH} 中的 [{CONFIG_SECTION}] 配置段。请先配置 jwt_account 和 jwt_secret。"
        )

    jwt_account = first_present(section, "jwt_account", "jwtAccount", "jwtAccout", "account")
    jwt_secret = first_present(section, "jwt_secret", "jwtSecret", "secret")
    if not jwt_account or not jwt_secret:
        raise ConfigError(
            f"缺少 {CONFIG_PATH} 中的 [{CONFIG_SECTION}].jwt_account 或 jwt_secret。"
            "请先配置后再查询。"
        )

    return {
        "jwt_account": str(jwt_account),
        "jwt_secret": str(jwt_secret),
        "operator": str(section.get("operator") or DEFAULT_OPERATOR),
        "timeout_seconds": int(section.get("timeout_seconds") or DEFAULT_TIMEOUT_SECONDS),
    }


def first_present(mapping: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = mapping.get(key)
        if value is not None and value != "":
            return value
    return None


def base64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def sign_jwt(user_data: dict[str, Any], jwt_account: str, jwt_secret: str) -> str:
    header = {
        "typ": "JWT",
        "alg": "HS256",
        "account": jwt_account,
    }
    payload = {
        "data": user_data,
        "timestamp": int(time.time()),
    }
    encoded_header = base64url(json_bytes(header))
    encoded_payload = base64url(json_bytes(payload))
    token = f"{encoded_header}.{encoded_payload}"
    digest = hmac.new(jwt_secret.encode("utf-8"), token.encode("utf-8"), hashlib.sha256).digest()
    signature = base64url(digest)
    return f"{token}.{signature}"


def grpc_proxy_endpoint_for(country: str) -> str:
    base_url = MARKET_DOMAINS[country]
    return urllib.parse.urljoin(base_url, "api/spx/lmroute/openapi/grpc_proxy")


def delivery_order_endpoint_for(country: str) -> str:
    base_url = DELIVERY_SERVICE_BASE_URLS[country]
    return urllib.parse.urljoin(base_url, "spx_delivery/openapi/delivery_domain/order_info/query")


def assignment_task_endpoint_for(country: str, assignment_task_id: str) -> str:
    base_url = DELIVERY_SERVICE_BASE_URLS[country]
    endpoint = urllib.parse.urljoin(base_url, "spx_delivery/openapi/assignment_task/query")
    return f"{endpoint}?{urllib.parse.urlencode({'assignment_task_id': assignment_task_id})}"


def build_station_request(country: str, env: str, operator: str, site_ids: list[int]) -> dict[str, Any]:
    return {
        "operator": operator,
        "service_name": f"spx-networkroute-{env}-{country.lower()}",
        "api_path": "spx_networkroute_site.SiteBaseService/SearchSiteV2",
        "grpc_req": {"site_id_list": site_ids},
    }


def build_driver_request(country: str, env: str, operator: str, driver_ids: list[int]) -> dict[str, Any]:
    return {
        "operator": operator,
        "service_name": f"driver-service-{env}-{country.lower()}",
        "api_path": "driver_protobuf.DriverApiService/GetDriverListByDriverIdList",
        "grpc_req": {"driver_id_list": driver_ids},
    }


def build_fo_request(
    country: str,
    env: str,
    operator: str,
    shipment_ids: list[str],
    select_fields: list[str],
) -> dict[str, Any]:
    return {
        "operator": operator,
        "service_name": f"SPX-FleetOrderService-{env}-{country.lower()}",
        "api_path": "protocol.QueryService/List",
        "grpc_req": {
            "header": {
                "version": "GRRP1.0",
                "client_name": "testCli",
                "source": "testSrc",
                "service_name": "",
                "select_field": select_fields,
            },
            "content": json.dumps({"shipment_id_list": shipment_ids}, ensure_ascii=False, separators=(",", ":")),
        },
    }


def build_delivery_order_request(shipment_id: str) -> dict[str, Any]:
    return {"shipment_id": shipment_id}


def build_assignment_task_request() -> dict[str, Any]:
    return {}


def same_host_redirect(old_url: str, new_url: str) -> bool:
    old = urllib.parse.urlparse(old_url)
    new = urllib.parse.urlparse(new_url)
    return old.hostname == new.hostname and new.scheme in {"http", "https"}


def post_jwt(endpoint: str, signed_jwt: str, timeout_seconds: int) -> str:
    body = json_bytes({"jwt": signed_jwt})
    current_endpoint = endpoint
    for _ in range(4):
        request = urllib.request.Request(
            current_endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "codex-spx-openapi-query/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
                return response.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            location = exc.headers.get("Location")
            if exc.code in {307, 308} and location:
                redirect_endpoint = urllib.parse.urljoin(current_endpoint, location)
                if not same_host_redirect(current_endpoint, redirect_endpoint):
                    raise RuntimeError(f"拒绝跨域 redirect：{current_endpoint} -> {redirect_endpoint}") from exc
                current_endpoint = redirect_endpoint
                continue
            error_body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {exc.code} {exc.reason}: {error_body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"请求失败：{exc}") from exc
    raise RuntimeError("HTTP redirect 次数过多")


def parse_json_text(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def decode_embedded_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: decode_embedded_json(child) for key, child in value.items()}
    if isinstance(value, list):
        return [decode_embedded_json(item) for item in value]
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith(("{", "[")) and stripped.endswith(("}", "]")):
            try:
                return decode_embedded_json(json.loads(stripped))
            except json.JSONDecodeError:
                return value
    return value


def annotate_tracking_status(value: Any) -> Any:
    if isinstance(value, dict):
        annotated: dict[str, Any] = {}
        for key, child in value.items():
            annotated[key] = annotate_tracking_status(child)
            if key in {"display_status", "tracking_status"}:
                status_name = primary_name(child)
                if status_name:
                    annotated[f"{key}_name"] = status_name
                    aliases = names_for_code(child)
                    if len(aliases) > 1:
                        annotated[f"{key}_aliases"] = aliases
        return annotated
    if isinstance(value, list):
        return [annotate_tracking_status(item) for item in value]
    return value


def print_json(value: Any) -> None:
    if isinstance(value, str):
        print(value)
    else:
        print(json.dumps(value, ensure_ascii=False, indent=2))


def split_values(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        for item in value.split(","):
            item = item.strip()
            if item:
                result.append(item)
    return result


def split_int_values(values: list[str], label: str) -> list[int]:
    result: list[int] = []
    for item in split_values(values):
        try:
            result.append(int(item))
        except ValueError as exc:
            raise ValueError(f"{label} 必须是整数：{item}") from exc
    return result


def normalize_country(country: str) -> str:
    normalized = country.upper()
    if normalized not in MARKET_DOMAINS:
        raise ValueError(f"不支持的市场：{country}。支持：{', '.join(MARKET_DOMAINS)}")
    return normalized


def common_direct_api_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--country", "-c", required=True, help="市场：ID/MY/TH/PH/VN/SG/TW/BR")
    parser.add_argument("--timeout", type=int, help="请求超时秒数，默认读取配置或 20")
    parser.add_argument("--dry-run", action="store_true", help="只输出 endpoint 和 user_data，不签名、不发请求")
    parser.add_argument("--raw", action="store_true", help="输出原始响应文本，不解析 JSON，不补充状态名")


def common_grpc_api_args(parser: argparse.ArgumentParser) -> None:
    common_direct_api_args(parser)
    parser.add_argument("--env", default=DEFAULT_ENV, help="环境名，默认 live")
    parser.add_argument("--operator", help="operator，默认读取配置或 delivery-test")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="查询 SPX OpenAPI fleet_order、driver、station、delivery order、assignment task 信息"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    station = subparsers.add_parser("station", aliases=["site", "hub"], help="查询 station/site/hub 信息")
    common_grpc_api_args(station)
    station.add_argument("site_ids", nargs="+", help="site_id/station_id/hub_id，支持逗号分隔")

    driver = subparsers.add_parser("driver", help="查询 driver 骑手信息")
    common_grpc_api_args(driver)
    driver.add_argument("driver_ids", nargs="+", help="driver_id，支持逗号分隔")

    fo = subparsers.add_parser("fo", aliases=["fleet-order", "order"], help="查询 fleet_order/运单信息")
    common_grpc_api_args(fo)
    fo.add_argument("shipment_ids", nargs="+", help="shipment_id，支持逗号分隔")
    fo.add_argument(
        "--select-field",
        action="append",
        nargs="+",
        help="覆盖默认 select_field；可多次传入，也支持逗号分隔",
    )

    delivery_order = subparsers.add_parser(
        "delivery-order",
        aliases=["delivery", "delivery-domain-order"],
        help="查询 delivery 域订单信息",
    )
    common_direct_api_args(delivery_order)
    delivery_order.add_argument("shipment_id", help="shipment_id，例如 BR262602942631H")

    assignment_task = subparsers.add_parser(
        "at",
        aliases=["assignment-task"],
        help="查询 assignment task/AT 派送任务信息",
    )
    common_direct_api_args(assignment_task)
    assignment_task.add_argument("assignment_task_id", help="assignment_task_id，例如 AT202605124PGPR")

    status = subparsers.add_parser("status", aliases=["tracking-status"], help="解释 display_status/tracking_status")
    status.add_argument("codes", nargs="+", help="状态码，支持逗号分隔")
    return parser


def select_fields_from_args(args: argparse.Namespace) -> list[str]:
    if not args.select_field:
        return DEFAULT_FO_SELECT_FIELDS
    flattened: list[str] = []
    for group in args.select_field:
        flattened.extend(split_values(group))
    return flattened


def handle_status(args: argparse.Namespace) -> int:
    rows = []
    for code in split_values(args.codes):
        names = names_for_code(code)
        rows.append(
            {
                "code": int(code) if code.isdigit() else code,
                "primary_name": names[0] if names else None,
                "aliases": names,
            }
        )
    print_json(rows)
    return 0


def build_user_data(args: argparse.Namespace, operator: str) -> dict[str, Any]:
    country = normalize_country(args.country)
    env = getattr(args, "env", DEFAULT_ENV)
    if args.command in {"station", "site", "hub"}:
        return build_station_request(country, env, operator, split_int_values(args.site_ids, "site_id"))
    if args.command == "driver":
        return build_driver_request(country, env, operator, split_int_values(args.driver_ids, "driver_id"))
    if args.command in {"fo", "fleet-order", "order"}:
        return build_fo_request(country, env, operator, split_values(args.shipment_ids), select_fields_from_args(args))
    if args.command in {"delivery-order", "delivery", "delivery-domain-order"}:
        return build_delivery_order_request(args.shipment_id)
    if args.command in {"at", "assignment-task"}:
        return build_assignment_task_request()
    raise ValueError(f"未知命令：{args.command}")


def endpoint_for_args(args: argparse.Namespace) -> str:
    country = normalize_country(args.country)
    if args.command in {"delivery-order", "delivery", "delivery-domain-order"}:
        return delivery_order_endpoint_for(country)
    if args.command in {"at", "assignment-task"}:
        return assignment_task_endpoint_for(country, args.assignment_task_id)
    return grpc_proxy_endpoint_for(country)


def handle_api_query(args: argparse.Namespace) -> int:
    endpoint = endpoint_for_args(args)

    if args.dry_run:
        operator = getattr(args, "operator", None) or DEFAULT_OPERATOR
        user_data = build_user_data(args, operator)
        print_json({"endpoint": endpoint, "user_data": user_data})
        return 0

    config = load_config()
    operator = getattr(args, "operator", None) or config["operator"]
    timeout_seconds = args.timeout or config["timeout_seconds"]
    user_data = build_user_data(args, operator)
    signed_jwt = sign_jwt(user_data, config["jwt_account"], config["jwt_secret"])
    text = post_jwt(endpoint, signed_jwt, timeout_seconds)
    if args.raw:
        print(text)
        return 0

    parsed = parse_json_text(text)
    decoded = decode_embedded_json(parsed)
    annotated = annotate_tracking_status(decoded)
    print_json(annotated)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command in {"status", "tracking-status"}:
            return handle_status(args)
        return handle_api_query(args)
    except ConfigError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except (RuntimeError, ValueError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
