---
name: spx-openapi-query
description: 查询 SPX OpenAPI 信息，包括 fleet_order/fo/运单、delivery 域订单、assignment task/AT/派送任务、driver/骑手、station/site/hub site 站点信息。适用于用户要求按市场查询 SPX 运单字段、delivery domain 订单详情、AT 派送任务、display_status/tracking_status、骑手资料、站点或 hub site 信息，或需要生成 JWT 后发起 SPX OpenAPI 查询。
---

# SPX OpenAPI 查询

使用本 skill 查询 SPX 8 个市场的运单、delivery 域订单、AT 派送任务、骑手和站点信息。优先调用脚本：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py <类型> --country <市场> <ID...>
```

支持市场：

| 代码 | 市场 |
| --- | --- |
| `ID` | 印尼 |
| `VN` | 越南 |
| `TH` | 泰国 |
| `PH` | 菲律宾 |
| `MY` | 马来西亚 |
| `SG` | 新加坡 |
| `TW` | 台湾 |
| `BR` | 巴西 |

## 配置要求

真实查询前必须读取 `~/.codex/config.toml`。如果缺少配置，直接告知用户先配置，不要猜测或硬编码账号密钥。

```toml
[spx_openapi]
jwt_account = "xxx"
jwt_secret = "xxx"
# 可选，默认 delivery-test
operator = "delivery-test"
# 可选，默认 20
timeout_seconds = 20
```

脚本会读取 `[spx_openapi]` 中的 `jwt_account` 和 `jwt_secret`，生成 HS256 JWT，并以 `{"jwt":"<signed>"}` POST 到对应市场的 OpenAPI endpoint。

grpc_proxy 类查询使用 `/api/spx/lmroute/openapi/grpc_proxy`；delivery 域订单和 AT 查询使用 `spx-delivery-service.ssc` 域名下的 openapi path。

不要在回复里打印 JWT、jwt_secret 或完整鉴权头。

## 查询命令

查询站点、station、site、hub site：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py station --country BR 14321
```

查询骑手、driver：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py driver --country BR 3517124
```

查询运单、fleet_order、fo：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py fo --country ID SPXID061828685355
```

查询 delivery 域订单信息：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py delivery-order --country BR BR262602942631H
```

查询 AT、assignment task、派送任务：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py at --country BR AT202605124PGPR
```

可一次传多个 ID，支持空格或逗号分隔：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py driver --country BR 3517124,3517125
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py fo --country ID SPXID061828685355 SPXID061828685356
```

只验证请求构造、不访问线上接口：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py station --country BR 14321 --dry-run
```

单独解释 tracking status：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py status 4 140 934
```

## 服务映射

脚本按市场和环境自动生成 grpc_proxy 类查询的 `service_name`。默认环境是 `live`。

- 站点查询：`spx-networkroute-live-<country_lower>`
  - `api_path`: `spx_networkroute_site.SiteBaseService/SearchSiteV2`
  - `grpc_req`: `{"site_id_list": [...]}`
- 骑手查询：`driver-service-live-<country_lower>`
  - `api_path`: `driver_protobuf.DriverApiService/GetDriverListByDriverIdList`
  - `grpc_req`: `{"driver_id_list": [...]}`
- 运单查询：`SPX-FleetOrderService-live-<country_lower>`
  - `api_path`: `protocol.QueryService/List`
  - `grpc_req.header.select_field` 默认包含常用字段：`shipment_id`、`display_status`、`status`、`dest_station_id`、`return_station_id`、`current_station_id`、`transfer_direction`、`lm_hub_receive_time`、`returned_time`
  - 可用 `--select-field` 追加或覆盖查询字段
- delivery 域订单查询：
  - endpoint: `https://spx-delivery-service.ssc.shopee.<market>/spx_delivery/openapi/delivery_domain/order_info/query`
  - `user_data`: `{"shipment_id": "..."}`
- AT 派送任务查询：
  - endpoint: `https://spx-delivery-service.ssc.shopee.<market>/spx_delivery/openapi/assignment_task/query?assignment_task_id=...`
  - `user_data`: `{}`

## 输出处理

脚本默认输出格式化 JSON。如果响应中包含 `display_status` 或 `tracking_status`，会根据 `scripts/tracking_status.py` 自动追加对应的 `*_name`，例如 `display_status_name`。

当用户只问状态码含义时，不需要访问 OpenAPI，直接使用：

```bash
python ~/.codex/skills/spx-openapi-query/scripts/spx_openapi_query.py status <code...>
```

`scripts/tracking_status.py` 是状态码表的唯一维护位置。后续补充 tracking status 时只改这个文件。

## 回复方式

执行查询后，用简洁中文总结关键字段，并保留必要的原始 JSON 片段。遇到以下情况直接说明：

- 未提供市场且无法从上下文可靠判断：请用户补充 `ID/MY/TH/PH/VN/SG/TW/BR`。
- 缺少 `~/.codex/config.toml` 或 `[spx_openapi]` 鉴权字段：请用户先配置。
- HTTP 或服务返回错误：保留状态码和错误 body 的关键内容，不要吞掉原始错误。
