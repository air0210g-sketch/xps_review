# AT 核心表分库分表经验

这是一篇历史项目经验复盘，用于理解复杂分库分表项目如何拆 Jira、拆 TD、控风险。它不是主 skill 的通用流程，只有在需要案例时加载。

## 项目拆分脉络

| Jira | 主题 | 经验 |
| --- | --- | --- |
| SPXFM-232778 | SQL 审计与访问面采集 | 先知道谁在访问旧表，再决定改造范围。审计要带入口、trace、库表、条件和系统类型。 |
| SPXFM-235906 | 补齐未采集到的 URL 信息 | SQL 没有入口 owner 很难推进；访问面审计需要可归责。 |
| SPXFM-234342 / SPXFM-235959 / SPXFM-235949 / SPXFM-238733 | 慢 SQL 批次治理 | 慢 SQL 治理和分库分表互相影响，应提前识别会被分片放大的查询。 |
| SPXFM-234345 | relation/extra 表新增 station_id 与 MySQL 升级 | DDL、代码、回填、同步延迟要拆开控制；字段准备不能和读路径强依赖绑死。 |
| SPXFM-234282 | 核心表归档优化 | 分片前先处理归档和历史数据规模，否则迁移和回填成本会被放大。 |
| SPXFM-237330 | AT 底层 engine 改造 | 新旧数据源切换应集中在 repository/engine resolver，默认关闭保持旧行为。 |
| SPXFM-237467 | relation 数据访问层优化 | 分片前先收敛 DAL 语义，避免每个业务入口重复理解底层表关系。 |
| SPXFM-238277 | order_station / at_station / driver_candidate_station 索引表 | 索引表解决无 station_id 反查路由，但不能变成主数据源。 |
| SPXFM-239337 | AT 核心表兜底查询改造 | 兜底是灰度和历史入口的过渡能力，需要观测、限流和下线条件。 |
| SPXFM-239329 | AT 核心表跨库解事务 | 主链路保 AT core 本地事务，投影或过渡表用 post-commit + 可靠任务补偿。 |
| SPXFM-239961 | service 层补 station_id | route key 应显式传递到 condition，不建议只靠 context 隐式绑定。 |
| SPXFM-240598 | 导出平台适配 | 导出/报表要单独评估，不要复用在线查询的性能假设。 |

## 关键经验

### 1. 先审计访问面，再拆改造任务

AT 项目早期通过 CollectSQL 和慢 SQL 批次治理识别旧表访问。经验是：代码搜索不够，运行时 SQL 才能暴露真实入口，尤其是 PDA、cron、consumer、导出、报表和无 URL 的 SQL。

审计结果要能回答：
- 哪些入口没有 station_id。
- 哪些查询会在分片后变成全分片扫描。
- 哪些 SQL 属于低频但高风险。
- 每条 SQL 的 owner 是谁。

### 2. 字段准备和读路径切换要解耦

`SPXFM-234345` 的经验是，新增 route key 字段、MySQL 升级、DTS/ES 同步、历史刷数和读路径改造不要混成一个发布点。字段可以先写入和回填，读路径通过 shadow/comparison 验证后再放量。

风险点：
- 刷数过快会影响数据消费延迟。
- ES 同步字段冲突要提前确认字段名。
- 多市场同步延迟会影响灰度节奏。

### 3. 数据访问层先统一，业务层再补 route key

`SPXFM-237330` 的核心价值不是简单替换 DB 名，而是建立 AT core 表的数据源统一入口。灰度关闭时继续走旧逻辑，灰度开启时由 resolver 决定新旧数据源和分片。

事务内尤其要小心：如果在 transaction context 内重新绑定普通 DB engine，后续写入可能绕过事务，rollback 无法覆盖。事务路径应沿用 tx context 或 tx engine。

### 4. route key 显式传递，不把 context 当主方案

`SPXFM-239961` 的经验是，service 层补 station_id 应优先通过方法参数、内部 request 或 repository condition 显式传递。context 适合承载链路信息，不适合作为核心路由事实来源。

入口可以分级：
- S1：业务本来已有 station_id，优先改。
- S2：查询结果能推出 station_id，要验证它是否是目标表路由站点。
- S3：当前站点、hub、admin、agency 入口，要区分站点域和全局域。
- S4：没有稳定 station_id 的入口，单独设计，不放第一批。

### 5. 索引表是过渡和兜底能力，不是主路径

`SPXFM-238277` 的经验是，`order_station_tab`、`at_station_tab`、`driver_candidate_station_tab` 解决无 station_id 查询的路由问题，但最终目标仍然是主路径显式带 station_id。

设计细节：
- `order_station` 和 `at_station` 的 sharding variable 分别是 order_id 和 assignment_task_id，station_id 是查询结果或路由输入，不是这两个表的 sharding key。
- `driver_candidate_station` 是候选站点列表，不表达任务状态。
- 写入 best-effort 时必须有 retry/reconcile。
- 历史补偿应以主表驱动，避免扫描大量 relation 分片。

### 6. 跨库解事务要先定义一致性边界

`SPXFM-239329` 的重要修正是：不要为了“更可靠”过度设计 outbox；在已有可靠 AutoCall/Kafka common 能力时，可以采用 commit 后同步提交投影，失败再按 target MsgType 创建可靠重试任务。

同时要说明：
- 哪些表随主表进入同一分片本地事务。
- 哪些过渡表或投影表只保证最终一致。
- 重试 payload 如何幂等。
- 如果多个投影之间需要强一致，不能拆成互相独立的异步任务。

### 7. 过渡表要有生命周期

AT 方案里一些旧索引或反向关系表只服务灰度、兼容或历史入口。TD 中必须说明目标态是否保留、何时下线、下线前用什么指标证明安全。

## 可复用方法

1. 用审计任务先收敛访问面。
2. 用字段准备任务让新旧数据都具备路由能力。
3. 用 repository/engine 统一任务隔离新旧数据源。
4. 用 service 层 route key 任务逐步减少兜底依赖。
5. 用索引表和兜底任务覆盖无法一次性改完的入口。
6. 用跨边界一致性任务拆掉混合事务。
7. 用灰度、对账、补偿任务保护上线。

## 后续项目复用时要避免

- 直接复用 AT 的 station_id 命名；应替换成目标业务自己的 route key。
- 直接套用 AT 的索引表结构；应先确认 lookup key 和 result key。
- 直接默认 AutoCall/Kafka common 能力可用；应确认目标项目的可靠任务能力。
- 把 AT 的过渡表生命周期带到其他项目；每个项目应单独定义目标态。
