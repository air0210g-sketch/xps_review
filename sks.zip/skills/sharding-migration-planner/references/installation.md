# Installation

## 仓库位置

当前 skill 在 `ai_plugin` 仓库中的位置：

```text
/Users/quanhaizheng/workplace/goproject/spx/delivery/ai_plugin/skills/sharding-migration-planner
```

## 安装到本机 Codex

复制整个目录到本机 Codex skills 目录：

```bash
mkdir -p ~/.codex/skills
cp -R /Users/quanhaizheng/workplace/goproject/spx/delivery/ai_plugin/skills/sharding-migration-planner ~/.codex/skills/
```

如果使用 `CODEX_HOME`，则复制到：

```bash
mkdir -p "$CODEX_HOME/skills"
cp -R /Users/quanhaizheng/workplace/goproject/spx/delivery/ai_plugin/skills/sharding-migration-planner "$CODEX_HOME/skills/"
```

Codex 启动新会话时会发现该目录下的 `SKILL.md`。

## 验证

运行结构校验：

```bash
python3 /Users/quanhaizheng/.codex/skills/.system/skill-creator/scripts/quick_validate.py \
  /Users/quanhaizheng/workplace/goproject/spx/delivery/ai_plugin/skills/sharding-migration-planner
```

在新会话里可以用下面的请求触发：

```text
使用 $sharding-migration-planner 帮我把某核心表分库分表需求拆成 Jira 和 TD。
```

## 更新建议

- 主 `SKILL.md` 只保留通用流程和 reference 导航。
- 项目案例放在 `references/project-case-study.md`，不要写进主流程。
- 新增业务特有经验时，优先补案例或 checklist，不要让触发描述绑定某个业务名词。
