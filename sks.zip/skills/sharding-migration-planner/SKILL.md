---
name: sharding-migration-planner
description: Use when planning, splitting, writing, or reviewing database sharding and table-splitting migrations for core business tables, especially when work spans multiple Jira tasks, TDs, query paths, route keys, data access layers, consistency risks, gray release, backfill, or rollback.
---

# Sharding Migration Planner

用于复杂核心表分库分表项目的启动、拆分、方案评审和落地规划。主流程保持业务无关，只处理迁移方法、风险分类和产物边界。

## 快速判断

使用本 skill 当用户要做这些事情：
- 把一个大规模分库分表需求拆成多个 Jira、TD 或实施阶段。
- 梳理现有 SQL 访问面、查询入口、写入入口、事务边界或外部依赖。
- 设计 sharding key/route key 传递、兜底查询、索引表、灰度切换或补偿校验。
- Review 分库分表 TD/MR，找遗漏风险、错误假设和发布顺序问题。

不要用于：
- 单个 SQL 优化、普通索引优化或无迁移风险的小改动。
- 纯业务需求分析但没有数据分片、路由、迁移或一致性问题。

## 工作流

1. 先确认目标表、目标分片维度、迁移范围、是否已有平台能力、是否要求不停机。
2. 建立访问面清单：读写入口、SQL 类型、事务边界、异步任务、外部系统、导出/报表、归档/清理。
3. 按阶段拆 Jira/TD：审计、数据模型准备、访问层统一、路由键传递、查询兜底、跨边界一致性、灰度发布、补偿验证。
4. 对每个阶段定义输入、输出、依赖、回滚方式、验证指标和 owner。
5. 对高风险点加载对应 reference，避免一次性读入全部资料。
6. 输出时优先给依赖图、任务拆分表、TD 章节建议、风险清单或 review findings。

## 按需加载

- 拆 Jira/TD：读 `references/task-splitting.md`。
- SQL/访问面审计：读 `references/access-surface-audit.md`。
- 字段、路由键、历史数据准备：读 `references/schema-and-route-key-preparation.md`。
- Repository/data source/engine 切换：读 `references/repository-routing-switch.md`。
- 查询路由、兜底、索引表：读 `references/query-routing-and-indexes.md`。
- 跨库、跨分片、跨系统一致性：读 `references/cross-boundary-consistency.md`。
- 灰度、补偿、回滚、上线验证：读 `references/rollout-reconcile.md`。
- TD/MR review：读 `references/review-checklist.md`。
- 安装或分发此 skill：读 `references/installation.md`。
- 历史项目经验案例：只有用户明确要求案例或经验复盘时，读 `references/project-case-study.md`。

## 输出规范

- 先给结论，再给任务/风险表。
- 每个任务至少说明：目标、依赖、改动面、验证方式、回滚方式。
- 明确区分强一致、最终一致、只读兜底和灰度观测，不能用“异步补偿”掩盖业务一致性要求。
- 对未确认的 sharding key、route key、数据迁移方式、平台能力、发布窗口，用“待确认”标出并列为阻塞项。
