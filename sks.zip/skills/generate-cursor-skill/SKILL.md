---
name: generate-cursor-skill
description: >-
  Authors new Cursor Agent Skills from user requirements: emits YAML-frontmatter
  SKILL.md plus optional skill.spec.json (input/output JSON Schemas, prompt
  template, examples). Use when the user wants to create a skill, scaffold
  .cursor/skills/, or convert informal workflow notes into a reusable skill.
---

# Generate Cursor Skill（从需求生成 Skill）

## 目标

把用户的自然语言需求**结构化**为可落地的 Cursor Skill，并同时产出：

1. **`SKILL.md`**：符合 Cursor 约定（YAML frontmatter + 正文），可被 Agent 发现与执行。
2. **`skill.spec.json`（可选）**：供编排器 / 自动化校验的机器可读定义（输入输出 schema、prompt 模板、示例）。

## 何时使用

- 用户说「帮我写一个 skill」「生成 .cursor/skills」「把流程固化成 skill」。
- 需要 **Markdown + JSON** 双轨、且希望后续能自动校验 I/O。

## 输入（向用户收集或从上下文推断）

至少确认以下项；缺失则先提问，**禁止编造**业务规则：

| 字段 | 说明 |
|------|------|
| `purpose` | 解决什么问题、边界是什么 |
| `trigger_when` | 什么情况下 Agent 应自动选用本 skill（关键词/场景） |
| `target_scope` | 个人 `~/.cursor/skills/` 还是项目 `.cursor/skills/`（默认项目） |
| `inputs` | 人类调用时通常提供什么（文件、参数、约束） |
| `outputs` | 期望结构：仅 Markdown / Markdown+JSON / 是否要脚本 |
| `constraints` | 语言、安全（PII）、禁止动作、是否允许工具 |
| `examples` | 1～2 个正例即可 |

## 输出协议（Agent 必须遵守）

### 1) 先生成 `skill.spec.json` 草稿

使用下列**最小结构**（可按业务扩展 `input_schema.properties` / `result_json`）：

- `skill_spec_version`、`skill`（id、name、version、summary、use_when、do_not_use_when、safety）
- `input_schema`：JSON Schema object
- `output_schema`：至少包含 `status`、`result_markdown`、`result_json`
- `prompt_template`：`system` + `user`（占位符用 `{{task}}`、`{{constraints_json}}`、`context_json`）
- `invocation.example_request` / `example_response`（简写即可）
- `extensions`：可扩展点列表

### 2) 再生成 `SKILL.md`

**Frontmatter 必填**（与 Cursor 一致）：

- `name`：小写、连字符，≤64 字符
- `description`：第三人称；写清 **WHAT + WHEN**，并包含触发词

**正文建议章节**：

1. 目标与边界  
2. 何时使用 / 何时不要用  
3. 执行步骤（编号列表，可执行）  
4. 输入与输出格式（若需 JSON，说明代码块语言为 `json`）  
5. 示例（1 个完整示例）  
6. 可扩展点（钩子、版本策略）

### 3) 目录约定

若用户需要落盘，使用：

```text
.cursor/skills/<skill-name>/
├── SKILL.md
├── skill.spec.json    # 可选
├── reference.md       # 可选
└── scripts/           # 可选
```

`skill-name` 必须与 frontmatter `name` 一致。

## Prompt 模板（嵌入生成过程）

生成 skill 时，内部使用以下逻辑（不必输出给用户）：

- **System**：你是 Skill 作者；遵守 Cursor skill 规范；描述用第三人称；输出双轨时 Markdown 为人类主输出，JSON 为机器摘要。  
- **User**：`task` = 用户需求 + 收集到的字段；`constraints` = 语言与安全；`context` = 仓库路径、团队约定等。

## 质量检查（生成完成后自检）

- [ ] `description` 含触发场景，第三人称  
- [ ] 步骤可执行，无模糊动词堆砌  
- [ ] 若含 JSON schema，`additionalProperties` 策略明确  
- [ ] 未假设未提供的业务事实  

## 示例（节选）

**用户**：「帮我写一个 skill：从 PRD 链接提取验收标准，输出表格 Markdown。」

**产出**：`skill.spec.json` 定义 `input_schema`（prd_url、format）、`output_schema`（result_markdown 表格 + result_json 行数组）；`SKILL.md` 写清调用步骤与示例。

## 可扩展点

- 在 `skill.spec.json` 的 `extensions.plugin_fields` 中登记新增字段。  
- 需要自动化时增加 `scripts/validate_output.py` 校验 `result_json`。  
- 多语言：在 `constraints.output_locale` 枚举中扩展。
- 生成后若要走 **评测 + 评审 + 定稿**，让用户或 Agent 继续执行 `skill-build-pipeline`（见 `.cursor/skills/skill-build-pipeline/SKILL.md`）。
