---
name: tc-implementation-mapper
description: >-
  Maps test cases (from Confluence, Excel, or images) against the current
  branch's code implementation by scanning PRD, TD, and codebase. Outputs a
  structured TC-to-code mapping document with coverage statistics. Optionally
  generates gomonkey unit tests or integration tests for implemented features
  via the golang-gomonkey-access-handler-tests or integration-test-generator
  skills. Use when the user asks for TC
  mapping, test case implementation analysis, 「用例映射」, 「TC映射」,
  「功能实现验证」, or 「测试用例覆盖率」.
---

# TC Implementation Mapper（测试用例 — 代码实现映射）

## 目标与边界

将**测试用例**与**当前分支代码实现**逐条对齐，生成结构化映射文档，标明每条 TC 的实现状态（Implemented / Partial / Not Implemented / Frontend-Only / Infra-Only / Cancelled），供 QA 与开发查漏。

**边界**：

- 负责**分析、映射与文档输出**，不负责撰写 PRD/TD。
- 文档为**扫描时刻**的静态快照；行号、路径会随分支变化，须以当次工具读取结果为准。
- **单测生成**为可选；仅当用户明确要求时，再按「与 golang-gomonkey-access-handler-tests 集成」执行。

## 何时使用

- 用户提供了 PRD、TD、测试用例（一种或多种来源），要求**看当前分支实现了哪些 TC**。
- 用户提到「TC 映射」「用例映射」「功能实现验证」「测试用例覆盖率」「哪些 TC 没实现」。
- 用户需要将 TC 按实现状态分类并给出**代码定位**（文件/函数/行号以工具结果为准）。
- 用户要求按 TD 章节 / 功能域 / TC 编号范围**子集映射与验证**。

## 何时不要用

- 只读 PRD/TD、不做映射（直接用 Confluence MCP 即可）。
- 从零**编写**测试用例（用 `test-case-import-xlsx-generator`）。
- 只运行已有单测、不需要映射文档。

## 前置条件

1. **Confluence MCP**（或等价方式）可用于读取 PRD/TD/Confluence 上的用例页。
2. **当前 Git 分支**为目标功能分支（映射文档内需写明分支名）。
3. **Jira 号**：优先从分支名中按 `feature/{JIRA_NO}/` 模式提取（如 `feature/SPXFM-223633/xxx` → `SPXFM-223633`）；无法确定时必须询问用户，**禁止编造**。

## 测试用例来源与工具要求

### Confluence 页面

- 通过 Confluence MCP 拉取正文与表格。
- 解析表格中的 TC 编号、优先级、标题、步骤/描述等列；列名不统一时，先向用户确认列映射再抽取。

### Excel（.xlsx / .xlsm）

- `.xlsx` 为二进制（OOXML），**不要假设**可直接当纯文本 `Read` 读懂全表。
- **推荐**：在仓库内用 **Python + openpyxl**（或 pandas）编写/运行**一次性抽取脚本**（可放在 `AI_gen/{jira_no}/` 下临时文件），将表导出为结构化列表（TSV/JSON）再映射；或请用户另存为 **CSV** 后读取。
- 抽取字段至少包含：**TC 编号**、**优先级（P1/P2/P3）**、**用例名称**、**功能域/模块**（若有）、**测试描述/步骤**（若有）。缺列时记录为「源数据缺口」并在映射表备注中说明。

### 图片（截图、导出图）

- 可使用 Cursor **图片 `Read`** 识别文字与表格结构。
- **限制**：多页、模糊、合并单元格时识别可能不全；应要求用户补充 **Excel/Confluence 链接**或**可复制表格文本**；**禁止**在不确定时臆造 TC 条数或编号。

### 多源组合

- 若同时提供 Confluence + Excel + 图片：向用户确认**权威顺序**（例如以 Excel 条数为准还是以 Confluence 为准），对重复 TC 编号做**去重规则**说明后再映射。

## 执行步骤

### 第一步：收集输入

向用户确认或提取（缺失则提问，禁止编造）：

| 输入 | 必填 | 说明 |
|------|------|------|
| PRD 链接 | 是 | Confluence URL |
| TD 链接 | 是 | Confluence URL |
| 测试用例来源 | 是 | Confluence URL / 仓库内 xlsx 路径 / 图片路径；可多选 |
| Jira 号 | 是 | 如 `SPXFM-223633`；优先从分支名 `feature/{JIRA}/` 提取 |
| 扫描范围 | 否 | 默认识别 TD 涉及模块；可缩小为指定 `apps/<module>/` |
| 是否生成单测 | 否 | 默认否 |

### 第二步：解析 PRD / TD

1. 读取 PRD：功能列表、验收要点、术语。
2. 读取 TD：涉及模块、接口、数据模型、关键流程。
3. 产出内部使用的「需求/设计要点清单」，用于与 TC 及代码对照。

### 第三步：标准化测试用例列表

统一为可枚举条目，建议每条至少包含：

`TC-{编号} | 优先级 | 用例名称 | 功能域 | 测试描述（摘要）`

- **TC 总数**须与来源一致；若来源之间冲突，在文档「概览」或备注中说明处理规则。

### 第四步：代码仓扫描

1. 读取当前分支名（如 `git branch --show-current`）。
2. 按 TD 与用户指定范围，在 `apps/` 等目录用 `Grep` / `SemanticSearch` / `Read` 定位 **access → service → repository** 链路。
3. 对每条 TC：从描述提取 3-5 个关键标识符（英文函数名/变量名/配置 key + 中文业务词），用 `Grep` 定位入口，再 `Read` 确认逻辑。
4. 判定状态：

| 状态 | 判定标准 |
|------|----------|
| **Implemented** | 后端核心逻辑已实现，可测 |
| **Partial** | 主路径已实现，部分细节/依赖/API/配置未齐 |
| **Not Implemented** | 后端未实现或缺失关键逻辑 |
| **Frontend-Only** | 仅前端（Driver APP / Portal 等），后端无需求或已就绪 |
| **Infra-Only** | 依赖运维、压测、观测等非业务代码验证 |
| **Cancelled** | TD/需求已取消该点 |

**防幻觉**：「对应代码」中的**文件名、函数名、行号**必须来自**本次**在仓库中的搜索/阅读结果；无法确认时写「待确认」或「—」，不得凭记忆填写行号。

### 第五步：写出映射文档

**输出路径**：`AI_gen/{jira_no}/{jira_no}_TC_Implementation_Mapping.md`

**文档结构须与已验证的参考格式一致**（见仓库内 `AI_gen/SPXFM-223633/SPXFM-223633_TC_Implementation_Mapping.md`）：

1. **标题**：`# {Jira} 测试用例 — 代码实现映射`
2. **元信息**（引用块）：当前**分支名**、**生成时间**、**修订记录**。
3. **`## 1. 概览统计`**
   - **1.1 总体覆盖率**：表头 `| 实现状态 | 数量 | 占比 | 说明 |`（含合计行）。
   - **1.2 按功能域统计**：表头 `| # | 功能域 | TC 数 | Implemented | Partial | Not Impl | FE-Only | Infra | Cancelled |`。
   - **1.3 按优先级统计**：表头 `| 优先级 | 总数 | Implemented | Partial | Not Impl | FE-Only | Infra | Cancelled |`。
   - **1.4 未实现用例清单（需开发）**：表头 `| TC | Pri | 用例名称 | 功能域 | 缺失说明 |`（仅 Not Implemented 状态的 TC）。
   - **1.5 测试覆盖统计**：汇总单测和集成测试覆盖情况。表头 `| 测试类型 | 覆盖 TC 数 | 文件数 | 总行数 | 说明 |`。分为 `gomonkey 单测` 和 `集成测试（Real DB/Redis）` 两行。此段在第六步或增量更新后由 Agent 自动汇总填入。
4. **`## 2. 详细映射表（按功能域分组）`**
   - 每个功能域一个子章节：`### 2.x {功能域名} — {N} TC`
   - 表格前增加一行**核心实现入口**（如 `核心实现入口: ProcessEventRouteMatchDriverMultiRound @ calculation_service.go:324`）。
   - 表头固定：`| TC | Pri | 用例名称 | 状态 | 对应代码 | 单测 | 集成测试 | 备注 |`
   - **对应代码**格式：`文件名` — `函数名:行号`；无后端实现写 `—`。
   - **单测**格式：`✅ N 项` 或 `—`；标注已有 gomonkey 单测数量。
   - **集成测试**格式：`✅` / `✅ N 项` / `—`；标注已有 `//go:build integration` 集成测试覆盖状态。由 `integration-test-generator` 生成测试后回填此列。
5. **`## 3. 交叉校验`**（可选，有发现时输出）
   - TD 有设计但无 TC 覆盖的点。
   - TC 描述的能力在 TD 中无依据的点（标注待产品/TD 确认）。

### 第六步（可选）：生成单测

**仅当用户明确要求**时：

1. 以 **`golang-gomonkey-access-handler-tests`** 技能为**唯一方法论来源**（请先 `Read` 该 skill 全文）。
2. **硬约束摘要**（与上述 skill 一致，不可省略）：
   - **不要**使用 build tag 区分测试。
   - 使用 **`gomonkey.NewPatches()` 链式**打桩。
   - **单个**顶层 `Test`，子用例用 `t.Run`。
   - 打桩不稳定时，使用 **`-gcflags="all=-N -l"`** 运行测试。
   - **禁止** `t.Parallel()`（与包级打桩冲突）。
3. 优先对 **Implemented** 的 TC 所对应入口生成测试；**Partial** 仅覆盖已实现部分，并在注释或备注中标明未覆盖分支。
4. 单测文件命名建议：`{feature}_tc_verify_test.go`，位置与被测代码同包。

## 增量更新（分步，可执行）

当用户说「更新映射」「重新扫描」「代码已改」时：

1. **打开**已有 `AI_gen/{jira_no}/{jira_no}_TC_Implementation_Mapping.md`，解析其中 **TC 全集**与各条当前状态。
2. 与用户确认范围：
   - **增量**：仅对 **Not Implemented**、**Partial** 以及用户点名的 TC 重扫；**Implemented** 仅在用户要求或 TD 变更涉及时重扫。
   - **全量**：对所有 TC 重扫。
3. **重扫代码**：重复「第四步」判定规则，**更新**受影响行的状态、对应代码、备注。
4. **重算统计**：按 1.1–1.3 规则重新汇总数量与占比，保证 **各功能域 TC 数之和 = 总数 = 各优先级之和**。
5. **更新文首**：追加或修改**修订日期**与简短修订说明（例如：增量重扫 / 全量重扫）。
6. **向用户汇报**：列出**状态发生变化的 TC 清单**（从 → 到），便于 review。

## 输出文件

| 文件 | 路径 |
|------|------|
| 映射文档 | `AI_gen/{jira_no}/{jira_no}_TC_Implementation_Mapping.md` |
| 单测（可选） | `apps/.../**/*_tc_verify_test.go`（路径以模块为准） |

## 质量检查（生成后自检）

- [ ] TC 条数与来源一致，无静默遗漏。
- [ ] 1.1 / 1.2 / 1.3 数字自洽（合计、分域、分优先级三者之和一致）。
- [ ] Implemented / Partial 的「对应代码」有据可查（当次搜索/阅读结果）。
- [ ] Not Implemented 在 1.4 或备注中有**缺失说明**。
- [ ] 映射表「单测」「集成测试」列与实际测试文件一致；未生成测试的填 `—`。
- [ ] 1.5 测试覆盖统计与映射表中 ✅ 数量一致。
- [ ] 无伪造行号、无未经验证的脚本路径。
- [ ] 映射文档避免包含客户 PII、密钥等敏感信息。

## 示例（说明性，勿抄为事实）

用户提供 Confluence PRD/TD/用例页 + 仓库内 xlsx；Agent 抽取 166 条 TC，扫描 `apps/route_match_driver/` 等，输出：

```
AI_gen/SPXFM-223633/SPXFM-223633_TC_Implementation_Mapping.md

总计 166 TC：
- Implemented: 132 (79.5%)
- Partial: 17 (10.2%)
- Not Implemented: 5 (3.0%)
- Frontend-Only: 6 (3.6%)
- Infra-Only: 5 (3.0%)
- Cancelled: 1 (0.6%)
```

具体数字与模块名随项目变化。

## 与仓库其他 Skill 的关系

| Skill | 关系 |
|-------|------|
| **golang-gomonkey-access-handler-tests** | 可选集成：为 Implemented/Partial 相关代码生成 gomonkey 单测；约束以该 skill 正文为准 |
| **integration-test-generator** | 互补：为 Implemented TC 生成真实 DB/Redis 集成测试；测试完成后回填映射表「集成测试」列 |
| **test-case-import-xlsx-generator** | 互补：生成 import 用例 Excel；本 skill 做实现映射 |
| **log-driven-self-test** | 互补：用日志验证运行时行为；本 skill 侧重静态代码与需求对齐 |

## 可扩展点（未实现能力，勿当作现成脚本）

- **多代码仓**：映射表可增加「代码仓」列。
- **Excel 导出**：若团队需要，可新增专用导出脚本后再在 skill 中写入**真实路径**；在脚本落地前不要引用不存在的文件。
- **CI 集成**：在 PR 中自动生成增量映射 diff。
