---
name: jira-dev-duration-analysis
description: 通过自然语言搜索条件或直接 JQL 查询 Shopee Jira，分析 DEVSTART、DEVEND 和研发时长，生成本地 HTML 报告或启动实时 Web 页面。适用于用户要求搜索 Jira、查询 Jira issue、按状态/项目/组件/日期/文本查找 ticket、检查研发周期，或提到 jira-dev-duration-analysis 的场景。
---

# Jira 交付时长分析

使用这个 skill 将用户的自然语言 Jira 搜索请求转换为 JQL，调用 `https://jira.shopee.io` 查询，分析 Jira 从开发开始到 UAT 的研发时长，并生成本地 HTML 结果文件或实时 Web 页面。

实现脚本位于 `scripts/jira_api_search.py`。

## 凭证配置

从 `~/.codex/config.toml` 读取 Jira token。

期望配置：

```toml
[jira]
server = "https://jira.shopee.io"
token_auth = "YOUR_JIRA_PERSONAL_ACCESS_TOKEN"
```

如果 `token_auth` 缺失或为空，必须停止执行，并告知用户到下面页面生成 token：

`https://jira.shopee.io/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens`

然后让用户把 token 保存到 `~/.codex/config.toml` 的 `[jira].token_auth`。

不要把 token 硬编码到脚本里，也不要在日志、回复或提交内容中回显 token。

## 快速使用

用用户的自然语言搜索条件运行脚本：

```bash
python ~/.codex/skills/jira-dev-duration-analysis/scripts/jira_api_search.py "我负责的 SPXFM 项目里状态不是 Done 的任务"
```

默认行为：

- 默认返回 100 条结果。
- 如果用户没有指定 component，默认追加 `component in ("DeliveryOperation", "DeliveryMgt")`。
- 如果不是查询单个精确 issue key，默认追加 `"Epic Link" is not EMPTY`，只搜索已经关联 Epic 的 Jira。
- 查询字段为 `key,issuetype,summary,status,created,reporter,components`。
- HTML 中 Jira 时间统一展示为日期格式，例如 `2026-01-06`。
- HTML 额外展示 `DEVSTART` 列：读取每个 issue 的 changelog，筛选所有 `toString == "Developing"` 的状态变更，取最近一次变更日期。
- HTML 额外展示 `DEVEND` 列：筛选所有 `toString == "UAT"` 的状态变更，取最近一次变更日期。
- HTML 在 `DEVEND` 右侧展示 `研发时长` 列：如果 `DEVEND` 非空，计算 `DEVEND - DEVSTART`；如果 `DEVEND` 为空，计算 `今天 - DEVSTART`。
- HTML 默认按 `研发时长` 倒序排列，研发时长越长的 issue 越靠前；空 `研发时长` 始终排在最后。
- HTML 搜索结果上方提供 Status 下拉过滤器，初始显示全部结果；可按 `waiting`、`PRD`、`开发中`、`uat/other` 四个状态分组过滤。
- HTML 视觉风格使用“企业数据表 + 交付状态看板”混合方案：顶部展示 Jira total，JQL 独立面板，结果区展示 4 个可点击状态统计块，表格使用 sticky header、hover 行状态和 status badge。
- 在当前工作目录的 `jira_search_results/` 下生成本地 HTML 文件。
- 使用 `open` 自动打开生成的 HTML 文件。

## 实时 Web 模式

如果用户希望在页面上刷新并重新获取 Jira 最新数据，使用 `--web`：

```bash
python ~/.codex/skills/jira-dev-duration-analysis/scripts/jira_api_search.py --web
```

Web 模式会监听 `http://127.0.0.1:26513/`。首页标题展示为“Jira 交付时长分析”，带交付时长图标；页面会先立即展示“查询中...”和“重新查询”按钮，再通过 `/report` 实时调用 Jira API 查询数据，并复用静态 HTML 报告的列、过滤、排序和视觉样式。点击“重新查询”会重新请求 Jira API 并刷新报告。

Web 模式支持 URL 参数覆盖默认查询：

- `?q=自然语言搜索条件`
- `?jql=直接JQL`
- `?maxResults=100`

例如：

```text
http://127.0.0.1:26513/?jql=assignee%20%3D%20%22jeeery.liu%40shopee.com%22&maxResults=100
```

## 直接使用 JQL

如果用户提供明确的 JQL，使用 `--jql` 直接传入：

```bash
python ~/.codex/skills/jira-dev-duration-analysis/scripts/jira_api_search.py --jql 'assignee = "jeeery.liu@shopee.com"'
```

HTML 报告第一部分必须展示生成的 JQL，并把“生成的 JQL”标题本身做成可点击链接，跳转到 Jira 搜索页。不要把 URL 编码后的长链接直接显示在页面正文里。

## 自然语言转 JQL 规则

优先生成保守、易人工检查的 JQL：

- 用户说“我负责的”、“分配给我”、“assignee 是我”、“我的”：默认使用 `assignee = "jeeery.liu@shopee.com"`，除非用户明确指定其他邮箱。
- 用户给出 assignee 或 reporter 的邮箱/用户名：如果包含 `@`，直接使用该邮箱；如果是 Shopee 用户名且语义明确指向人员，补全为 `name@shopee.com`。
- 用户提到项目 key，例如 `SPXFM`：追加 `project = SPXFM`。
- 用户提到 issue key，例如 `SPXFM-230530`：使用 `key = SPXFM-230530`。
- 用户提到状态：追加 `status = "Status Name"` 或 `status in (...)`。
- 用户提到“未完成”、“未关闭”、“不是 Done”、“not done”：追加 `status not in (Done, Closed)`。
- 用户明确提到 component 或组件：追加 `component = "ComponentName"`。
- 用户没有提到 component，且不是查询单个精确 issue key 时，默认追加 `component in ("DeliveryOperation", "DeliveryMgt")`。
- 用户没有明确处理 Epic，且不是查询单个精确 issue key 时，默认追加 `"Epic Link" is not EMPTY`。
- 如果用户像 `SPXFM-238860` 这样查询单个精确 issue key，不追加默认 component 或 Epic 过滤，避免把单号查没。
- 用户提到创建/更新时间限制：使用 Jira 日期字段，例如 `created >= "2026-05-01"` 或 `updated >= -7d`。
- 用户提到 summary/text 关键词：除非字段明确，否则使用 `text ~ "keyword"`。
- 除非用户要求其他排序，或 JQL 已包含 `ORDER BY`，默认追加 `ORDER BY updated DESC`。

如果不确定某段自然语言是否应该映射成特定字段，优先把它作为文本搜索条件处理，不要猜测不稳定的自定义字段。

## 输出要求

HTML 报告包含两部分：

1. 生成的 JQL
   - 以纯文本展示 JQL。
   - 将“生成的 JQL”标题链接到 URL 编码后的 Jira 搜索页。
   - 不要把很长的 Jira 搜索 URL 直接显示成页面文字。

2. 搜索结果
   - 表格列固定为：`Key | Type | Summary | Status | Created | DEVSTART | DEVEND | 研发时长 | Reporter | Components`。
   - 默认展示最多 100 行结果。
   - 在表格上方添加 Status 下拉框，提供 `waiting`、`PRD`、`开发中`、`uat/other` 四个过滤分组。
   - 在下拉框上方添加 4 个状态统计块，展示各分组数量；点击统计块时同步切换下拉过滤。
   - Status 分组规则：`Waiting` 归入 `waiting`；`PRD` 归入 `PRD`；`Developing`、`Testing`、`Reviewing` 归入 `开发中`；其他状态归入 `uat/other`。
   - Status 列使用 badge 样式区分不同状态分组；`Developing`、`Testing`、`Reviewing` 仍归入 `开发中` 过滤分组，但表格 Status 列必须显示 Jira 原始详细状态，例如 `Developing`、`Testing`、`Reviewing`；表头保持 sticky，长列表滚动时仍可看到列名。
   - `研发时长` 表头是默认排序按钮，默认显示倒序指示 `↓` 和提示 `长 → 短`；点击后切换为正序 `↑` 和 `短 → 长`。
   - `DEVSTART` 表头也可点击排序；切到 `DEVSTART` 排序时，显示 `早 → 晚` 或 `晚 → 早`。
   - 每个 Key 链接到 `https://jira.shopee.io/browse/<KEY>`。
   - 所有超链接都使用新 tab 打开，并加上 `rel="noopener noreferrer"`。
   - `Created` 只展示日期，格式为 `YYYY-MM-DD`。
   - `DEVSTART` 只展示日期，格式为 `YYYY-MM-DD`；如果存在多次流转到 `Developing` 的记录，取最近最新的一条。
   - `DEVEND` 只展示日期，格式为 `YYYY-MM-DD`；如果存在多次流转到 `UAT` 的记录，取最近最新的一条。
   - `DEVSTART` 排序时空值始终放到最后，避免无日期 issue 干扰交付先后判断。
   - `研发时长` 展示研发阶段天数，例如 `3 天`；如果 `DEVEND` 为空，按今天作为结束日期；如果 `DEVSTART` 为空，则 `研发时长` 为空且排序时放到最后。
   - `Reporter` 优先展示 displayName，其次展示 name 或 emailAddress。
   - 多个 Components 用逗号拼接。

回复用户时，说明生成的 JQL、结果数量，以及本地 HTML 文件路径。
