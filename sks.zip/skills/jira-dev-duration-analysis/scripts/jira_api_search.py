#!/usr/bin/env python3
"""Search Shopee Jira from natural language or JQL and render an HTML report."""

from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import html
import http.server
import json
from pathlib import Path
import re
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request


DEFAULT_SERVER = "https://jira.shopee.io"
DEFAULT_ASSIGNEE = "jeeery.liu@shopee.com"
DEFAULT_COMPONENTS = ("DeliveryOperation", "DeliveryMgt")
DEFAULT_REQUIRE_EPIC = True
DEFAULT_MAX_RESULTS = 200
DEFAULT_FIELDS = "key,issuetype,summary,status,created,reporter,components"
DEFAULT_WEB_HOST = "127.0.0.1"
DEFAULT_WEB_PORT = 26513
FAVICON_DATA_URI = (
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E"
    "%3Crect width='64' height='64' rx='14' fill='%231f6feb'/%3E"
    "%3Ccircle cx='32' cy='32' r='18' fill='none' stroke='white' stroke-width='5'/%3E"
    "%3Cpath d='M32 20v13l10 6' fill='none' stroke='white' stroke-width='5' stroke-linecap='round' stroke-linejoin='round'/%3E"
    "%3Cpath d='M18 51h28' fill='none' stroke='white' stroke-width='5' stroke-linecap='round'/%3E"
    "%3C/svg%3E"
)
TOKEN_HELP_URL = (
    "https://jira.shopee.io/secure/ViewProfile.jspa?"
    "selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens"
)


def parse_simple_toml(path: Path) -> dict[str, dict[str, str]]:
    data: dict[str, dict[str, str]] = {}
    section: str | None = None
    if not path.exists():
        return data
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            data.setdefault(section, {})
            continue
        if section and "=" in line:
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            data[section][key] = value
    return data


def load_config() -> tuple[str, str]:
    config_path = Path.home() / ".codex" / "config.toml"
    config = parse_simple_toml(config_path)
    jira_config = config.get("jira", {})
    server = jira_config.get("server") or DEFAULT_SERVER
    token = jira_config.get("token_auth") or ""
    if not token:
        raise SystemExit(
            "未找到 Jira token。\n"
            f"请到 {TOKEN_HELP_URL} 生成 Personal Access Token，"
            "然后保存到 ~/.codex/config.toml：\n\n"
            "[jira]\n"
            f'server = "{DEFAULT_SERVER}"\n'
            'token_auth = "YOUR_JIRA_PERSONAL_ACCESS_TOKEN"\n'
        )
    return server.rstrip("/"), token


def quote_value(value: str) -> str:
    value = value.strip().strip('"')
    return '"' + value.replace('"', '\\"') + '"'


def normalize_email(value: str) -> str:
    value = value.strip().strip('"')
    if "@" in value:
        return value
    return f"{value}@shopee.com"


def looks_like_jql(text: str) -> bool:
    lowered = text.lower()
    return bool(
        re.search(r"^\s*(project|assignee|reporter|status|summary|text|key|created|updated|component|\"epic link\")\b\s*(=|in|not\s+in|~|>|<|is)", lowered)
        or re.search(r"\border\s+by\b", lowered)
    )


def extract_statuses(text: str) -> list[str]:
    known = [
        "Waiting",
        "Designing",
        "PRD",
        "Developing",
        "Testing",
        "Reviewing",
        "UAT",
        "Staging",
        "Regression",
        "Delivering",
        "Live Testing",
        "Done",
        "Closed",
        "Icebox",
    ]
    found: list[str] = []
    lowered = text.lower()
    compact = re.sub(r"[\s_-]+", "", lowered)
    for status in known:
        status_compact = re.sub(r"[\s_-]+", "", status.lower())
        if status.lower() in lowered or status_compact in compact:
            found.append(status)
    return found


def build_jql(text: str) -> str:
    text = text.strip()
    if not text:
        return ensure_order_by(" AND ".join(default_filter_clauses()))
    if looks_like_jql(text):
        return ensure_order_by(text)

    clauses: list[str] = []
    has_component_clause = False

    issue_key = re.search(r"\b([A-Z][A-Z0-9]+-\d+)\b", text)
    if issue_key:
        clauses.append(f"key = {issue_key.group(1)}")

    project_keys = re.findall(r"\b([A-Z][A-Z0-9]{1,12})-\d+\b", text)
    standalone_projects = re.findall(r"\b([A-Z][A-Z0-9]{2,12})\b", text)
    for project in project_keys + standalone_projects:
        if project in {"JQL", "API", "URL"}:
            continue
        if project and f"project = {project}" not in clauses and not issue_key:
            clauses.append(f"project = {project}")
            break

    if re.search(r"(我负责|分配给我|assignee\s*是我|我的)", text, re.I):
        clauses.append(f"assignee = {quote_value(DEFAULT_ASSIGNEE)}")

    assignee_match = re.search(r"(?:assignee|负责人|经办人|分配给)\s*(?:是|=|:|为)?\s*([A-Za-z0-9_.+-]+(?:@shopee\.com)?)", text, re.I)
    if assignee_match and "我" not in assignee_match.group(1):
        clauses.append(f"assignee = {quote_value(normalize_email(assignee_match.group(1)))}")

    reporter_match = re.search(r"(?:reporter|报告人|创建人)\s*(?:是|=|:|为)?\s*([A-Za-z0-9_.+-]+(?:@shopee\.com)?)", text, re.I)
    if reporter_match:
        clauses.append(f"reporter = {quote_value(normalize_email(reporter_match.group(1)))}")

    if re.search(r"(未完成|没完成|未关闭|没关闭|不是\s*done|not\s+done)", text, re.I):
        clauses.append("status not in (Done, Closed)")
    else:
        statuses = extract_statuses(text)
        if len(statuses) == 1:
            clauses.append(f"status = {quote_value(statuses[0])}")
        elif len(statuses) > 1:
            clauses.append("status in (" + ", ".join(quote_value(s) for s in statuses) + ")")

    component_match = re.search(r"(?:component|组件)\s*(?:是|=|:|为)?\s*([A-Za-z0-9_. -]+)", text, re.I)
    if component_match:
        component = component_match.group(1).strip()
        component = re.split(r"\s+(?:的|里|中|状态|created|updated|创建|更新)\b", component)[0].strip()
        if component:
            clauses.append(f"component = {quote_value(component)}")
            has_component_clause = True

    for field, words in (("created", "创建|created"), ("updated", "更新|updated")):
        match = re.search(rf"(?:{words}).*?(>=|>|<=|<|之后|以来|以前|之前)?\s*(\d{{4}}-\d{{2}}-\d{{2}}|-?\d+d)", text, re.I)
        if match:
            op = match.group(1) or ">="
            date_value = match.group(2)
            op = {">": ">", ">=": ">=", "<": "<", "<=": "<=", "之后": ">=", "以来": ">=", "以前": "<=", "之前": "<="}.get(op, ">=")
            rendered_date = date_value if re.match(r"-?\d+d$", date_value) else quote_value(date_value)
            clauses.append(f"{field} {op} {rendered_date}")

    quoted_keywords = re.findall(r"[\"“](.+?)[\"”]", text)
    for keyword in quoted_keywords:
        if keyword and not looks_like_jql(keyword):
            clauses.append(f"text ~ {quote_value(keyword)}")

    if not clauses:
        cleaned = re.sub(r"\s+", " ", text).strip()
        clauses.append(f"text ~ {quote_value(cleaned)}")

    if not issue_key:
        if not has_component_clause:
            clauses.append(default_component_clause())
        if DEFAULT_REQUIRE_EPIC and not mentions_epic(text):
            clauses.append(default_epic_clause())

    return ensure_order_by(" AND ".join(dedupe(clauses)))


def default_filter_clauses() -> list[str]:
    clauses = [default_component_clause()]
    if DEFAULT_REQUIRE_EPIC:
        clauses.append(default_epic_clause())
    return clauses


def default_component_clause() -> str:
    return "component in (" + ", ".join(quote_value(c) for c in DEFAULT_COMPONENTS) + ")"


def default_epic_clause() -> str:
    return '"Epic Link" is not EMPTY'


def mentions_epic(text: str) -> bool:
    return bool(re.search(r"\bepic\b|史诗|父需求", text, re.I))


def ensure_order_by(jql: str) -> str:
    if re.search(r"\border\s+by\b", jql, re.I):
        return jql.strip()
    return jql.strip() + " ORDER BY updated DESC"


def dedupe(items: list[str]) -> list[str]:
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def search_jira(server: str, token: str, jql: str, max_results: int) -> dict:
    url = f"{server}/rest/api/2/search"
    payload = {
        "jql": jql,
        "startAt": 0,
        "maxResults": max_results,
        "fields": DEFAULT_FIELDS.split(","),
    }
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Jira API 请求失败：HTTP {exc.code}\n{detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Jira API 请求失败：{exc}") from exc


def enrich_dev_dates(server: str, token: str, data: dict) -> None:
    issues = data.get("issues", [])
    if not issues:
        return

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(issues))) as executor:
        future_to_issue = {
            executor.submit(fetch_issue_dev_dates, server, token, issue.get("key", "")): issue
            for issue in issues
        }
        for future in concurrent.futures.as_completed(future_to_issue):
            issue = future_to_issue[future]
            key = issue.get("key", "")
            try:
                issue.update(future.result())
            except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as exc:
                issue["devStart"] = ""
                issue["devEnd"] = ""
                print(f"Warning: failed to fetch changelog for {key}: {exc}", file=sys.stderr)


def fetch_issue_dev_dates(server: str, token: str, issue_key: str) -> dict[str, str]:
    if not issue_key:
        return {"devStart": "", "devEnd": ""}
    histories = fetch_changelog_histories(server, token, issue_key)
    return {
        "devStart": latest_status_transition_date(histories, "Developing"),
        "devEnd": latest_status_transition_date(histories, "UAT"),
    }


def fetch_changelog_histories(server: str, token: str, issue_key: str) -> list[dict]:
    issue_url = f"{server}/rest/api/2/issue/{urllib.parse.quote(issue_key)}?expand=changelog&fields=key"
    data = request_json(issue_url, token)
    changelog = data.get("changelog") or {}
    histories = list(changelog.get("histories") or [])
    total = changelog.get("total") or len(histories)
    max_results = changelog.get("maxResults") or len(histories) or total

    if total > len(histories):
        try:
            start_at = len(histories)
            while start_at < total:
                page_url = (
                    f"{server}/rest/api/2/issue/{urllib.parse.quote(issue_key)}/changelog"
                    f"?startAt={start_at}&maxResults={max_results}"
                )
                page = request_json(page_url, token)
                page_histories = page.get("values") or page.get("histories") or []
                if not page_histories:
                    break
                histories.extend(page_histories)
                start_at += len(page_histories)
                total = page.get("total") or total
        except urllib.error.HTTPError:
            # Some Jira Server versions do not expose the separate changelog endpoint.
            pass

    return histories


def request_json(url: str, token: str) -> dict:
    request = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def latest_status_transition_date(histories: list[dict], status_name: str) -> str:
    latest = ""
    for history in histories:
        created = history.get("created") or ""
        for item in history.get("items") or []:
            if item.get("field") == "status" and item.get("toString") == status_name:
                if created > latest:
                    latest = created
    return format_jira_date(latest)


def dev_start_sort_key(issue: dict) -> tuple[int, str]:
    dev_start = issue.get("devStart") or ""
    return (0, dev_start) if dev_start else (1, "")


def dev_duration_sort_key(issue: dict) -> tuple[int, int]:
    duration = dev_duration_value(issue.get("devStart") or "", issue.get("devEnd") or "")
    return (1, duration) if duration is not None else (0, -1)


def build_report_data(server: str, token: str, jql: str, max_results: int) -> dict:
    data = search_jira(server, token, jql, max_results)
    enrich_dev_dates(server, token, data)
    return data


def favicon_link() -> str:
    return f'<link rel="icon" type="image/svg+xml" href="{FAVICON_DATA_URI}">'


def render_html_document(server: str, jql: str, data: dict) -> str:
    jira_search_url = f"{server}/issues/?jql={urllib.parse.quote(jql)}"
    issues = sorted(data.get("issues", []), key=dev_duration_sort_key, reverse=True)
    total = data.get("total", len(issues))
    status_counts = {
        "waiting": 0,
        "prd": 0,
        "in-development": 0,
        "uat-other": 0,
    }

    rows = []
    for issue in issues:
        key = issue.get("key", "")
        fields = issue.get("fields", {})
        issue_type = (fields.get("issuetype") or {}).get("name", "")
        summary = fields.get("summary") or ""
        status = (fields.get("status") or {}).get("name", "")
        status_group = status_filter_group(status)
        status_label = status_display_label(status)
        status_counts[status_group] += 1
        created = format_jira_date(fields.get("created") or "")
        dev_start = issue.get("devStart") or ""
        dev_end = issue.get("devEnd") or ""
        dev_duration_num = dev_duration_value(dev_start, dev_end)
        dev_duration = format_duration(dev_duration_num)
        reporter = user_display(fields.get("reporter") or {})
        components = ", ".join(c.get("name", "") for c in fields.get("components") or [])
        key_link = f"{server}/browse/{urllib.parse.quote(key)}"
        rows.append(
            f'<tr data-status-group="{html.escape(status_group)}" data-dev-start="{html.escape(dev_start)}" data-dev-duration="{html.escape(str(dev_duration_num if dev_duration_num is not None else ""))}">'
            f'<td><a href="{html.escape(key_link)}" target="_blank" rel="noopener noreferrer">{html.escape(key)}</a></td>'
            f"<td>{html.escape(issue_type)}</td>"
            f"<td>{html.escape(summary)}</td>"
            f'<td><span class="status-badge status-{html.escape(status_group)}" title="{html.escape(status)}">{html.escape(status_label)}</span></td>'
            f"<td>{html.escape(created)}</td>"
            f"<td>{html.escape(dev_start)}</td>"
            f"<td>{html.escape(dev_end)}</td>"
            f"<td>{html.escape(dev_duration)}</td>"
            f"<td>{html.escape(reporter)}</td>"
            f"<td>{html.escape(components)}</td>"
            "</tr>"
        )

    status_summary_html = "".join(
        f'<button class="status-card status-card-{key}" type="button" data-filter="{key}">'
        f'<span class="status-card-label">{label}</span>'
        f'<span class="status-card-value">{status_counts[key]}</span>'
        "</button>"
        for key, label in (
            ("waiting", "waiting"),
            ("prd", "PRD"),
            ("in-development", "开发中"),
            ("uat-other", "uat/other"),
        )
    )

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  {favicon_link()}
  <title>Jira 交付时长分析</title>
  <style>
    :root {{
      --bg: #f6f8fb;
      --surface: #ffffff;
      --surface-muted: #f9fafc;
      --line: #dfe4ec;
      --line-strong: #c8d1df;
      --text: #172b4d;
      --muted: #5e6c84;
      --blue: #1f6feb;
      --blue-soft: #e9f2ff;
      --amber: #b76e00;
      --amber-soft: #fff4dc;
      --green: #1f7a4d;
      --green-soft: #e5f6ed;
      --purple: #5f4bb6;
      --purple-soft: #f0edff;
      --slate: #42526e;
      --slate-soft: #eef1f6;
      --shadow: 0 10px 28px rgba(23, 43, 77, 0.08);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 14px;
      line-height: 1.5;
    }}
    .page-shell {{
      width: min(1480px, calc(100vw - 48px));
      margin: 28px auto 40px;
    }}
    .page-header {{
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 24px;
      margin-bottom: 18px;
    }}
    h1 {{ font-size: 24px; line-height: 1.2; margin: 0 0 6px; letter-spacing: 0; }}
    h2 {{ font-size: 16px; line-height: 1.3; margin: 0 0 12px; letter-spacing: 0; }}
    .title-lockup {{ align-items: center; display: inline-flex; gap: 10px; }}
    .title-icon {{
      align-items: center;
      background: var(--blue-soft);
      border: 1px solid #c8ddff;
      border-radius: 8px;
      color: var(--blue);
      display: inline-flex;
      flex: 0 0 auto;
      height: 34px;
      justify-content: center;
      width: 34px;
    }}
    .title-icon svg {{ display: block; height: 20px; width: 20px; }}
    .subtitle {{ color: var(--muted); margin: 0; }}
    .top-metric {{
      min-width: 170px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--surface);
      padding: 12px 14px;
      box-shadow: var(--shadow);
    }}
    .top-metric-label {{ color: var(--muted); display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px; }}
    .top-metric-value {{ display: block; font-size: 24px; font-weight: 700; }}
    .panel {{
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 16px;
      background: var(--surface);
      box-shadow: var(--shadow);
    }}
    .section {{ margin-top: 18px; }}
    code {{ white-space: pre-wrap; word-break: break-word; color: #253858; }}
    a {{ color: var(--blue); text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    .status-grid {{
      display: grid;
      grid-template-columns: repeat(4, minmax(150px, 1fr));
      gap: 12px;
      margin: 0 0 14px;
    }}
    .status-card {{
      appearance: none;
      border: 1px solid var(--line);
      border-left-width: 4px;
      border-radius: 8px;
      background: var(--surface);
      color: var(--text);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 68px;
      padding: 12px 14px;
      text-align: left;
      transition: border-color 160ms ease, box-shadow 160ms ease, transform 160ms ease;
    }}
    .status-card:hover, .status-card.active {{
      border-color: var(--blue);
      box-shadow: 0 8px 20px rgba(31, 111, 235, 0.14);
      transform: translateY(-1px);
    }}
    .status-card-waiting {{ border-left-color: var(--amber); }}
    .status-card-prd {{ border-left-color: var(--purple); }}
    .status-card-in-development {{ border-left-color: var(--blue); }}
    .status-card-uat-other {{ border-left-color: var(--green); }}
    .status-card-label {{ color: var(--muted); font-size: 13px; font-weight: 700; }}
    .status-card-value {{ color: var(--text); font-size: 24px; font-weight: 800; }}
    .results-panel {{
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--surface);
      box-shadow: var(--shadow);
      overflow: hidden;
    }}
    .toolbar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      border-bottom: 1px solid var(--line);
      background: var(--surface-muted);
      padding: 12px 14px;
    }}
    .filter-control {{ display: flex; align-items: center; gap: 10px; }}
    label {{ color: var(--muted); font-size: 13px; font-weight: 700; }}
    select {{
      border: 1px solid var(--line-strong);
      border-radius: 6px;
      color: var(--text);
      font-size: 14px;
      min-height: 36px;
      padding: 6px 32px 6px 10px;
      background: #fff;
    }}
    .meta {{ color: var(--muted); font-size: 13px; margin: 0; }}
    .table-wrap {{ max-height: calc(100vh - 320px); overflow: auto; }}
    table {{ width: 100%; border-collapse: separate; border-spacing: 0; font-size: 14px; }}
    th, td {{ border-bottom: 1px solid var(--line); padding: 11px 10px; text-align: left; vertical-align: top; }}
    th {{
      position: sticky;
      top: 0;
      z-index: 1;
      background: #f1f4f9;
      color: #334563;
      font-size: 12px;
      font-weight: 800;
      text-transform: uppercase;
    }}
    .sort-button {{
      align-items: center;
      appearance: none;
      background: transparent;
      border: 0;
      color: inherit;
      cursor: pointer;
      display: inline-flex;
      font: inherit;
      gap: 6px;
      min-height: 32px;
      padding: 0;
      text-transform: inherit;
    }}
    .sort-button:focus-visible {{
      border-radius: 4px;
      outline: 2px solid var(--blue);
      outline-offset: 2px;
    }}
    .sort-indicator {{
      color: var(--blue);
      font-size: 13px;
      line-height: 1;
      min-width: 12px;
    }}
    .sort-hint {{
      color: var(--muted);
      font-size: 11px;
      font-weight: 700;
      margin-left: 4px;
      text-transform: none;
    }}
    tbody tr:hover {{ background: #f8fbff; }}
    td:nth-child(1), td:nth-child(5), td:nth-child(6), td:nth-child(7), td:nth-child(8) {{ white-space: nowrap; }}
    td:nth-child(3) {{ min-width: 360px; }}
    .status-badge {{
      border-radius: 999px;
      display: inline-flex;
      align-items: center;
      min-height: 24px;
      padding: 2px 9px;
      font-size: 12px;
      font-weight: 700;
      white-space: nowrap;
    }}
    .status-waiting {{ background: var(--amber-soft); color: var(--amber); }}
    .status-prd {{ background: var(--purple-soft); color: var(--purple); }}
    .status-in-development {{ background: var(--blue-soft); color: var(--blue); }}
    .status-uat-other {{ background: var(--green-soft); color: var(--green); }}
    @media (max-width: 900px) {{
      .page-shell {{ width: min(100vw - 24px, 1480px); margin-top: 16px; }}
      .page-header {{ align-items: stretch; flex-direction: column; }}
      .status-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
      .toolbar {{ align-items: flex-start; flex-direction: column; }}
      .table-wrap {{ max-height: none; }}
    }}
  </style>
</head>
<body>
  <main class="page-shell">
  <header class="page-header">
    <div>
      <h1 class="title-lockup">
        <span class="title-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="8"></circle>
            <path d="M12 8v4l3 2"></path>
            <path d="M4 19h16"></path>
          </svg>
        </span>
        <span>Jira 交付时长分析</span>
      </h1>
      <p class="subtitle">面向交付跟进的 Jira 查询报告</p>
    </div>
    <div class="top-metric">
      <span class="top-metric-label">Jira total</span>
      <span class="top-metric-value">{html.escape(str(total))}</span>
    </div>
  </header>
  <section class="section">
    <h2><a href="{html.escape(jira_search_url)}" target="_blank" rel="noopener noreferrer">生成的 JQL</a></h2>
    <div class="panel">
      <p><code>{html.escape(jql)}</code></p>
    </div>
  </section>
  <section class="section">
    <h2>搜索结果</h2>
    <div class="status-grid" aria-label="Status summary">
      {status_summary_html}
    </div>
    <div class="results-panel">
      <div class="toolbar">
        <div class="filter-control">
          <label for="statusFilter">Status</label>
          <select id="statusFilter">
            <option value="all">全部</option>
            <option value="waiting">waiting</option>
            <option value="prd">PRD</option>
            <option value="in-development">开发中</option>
            <option value="uat-other">uat/other</option>
          </select>
        </div>
        <p class="meta">显示 <span id="visibleCount">{len(issues)}</span> / {len(issues)} 条，Jira total = {html.escape(str(total))}</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Key</th>
              <th>Type</th>
              <th>Summary</th>
              <th>Status</th>
              <th>Created</th>
              <th id="devStartHeader" aria-sort="none">
                <button class="sort-button" id="devStartSort" type="button" aria-label="按 DEVSTART 正序排列">
                  <span>DEVSTART</span>
                  <span class="sort-indicator" id="devStartSortIndicator">↕</span>
                  <span class="sort-hint" id="devStartSortHint">日期</span>
                </button>
              </th>
              <th>DEVEND</th>
              <th id="devDurationHeader" aria-sort="descending">
                <button class="sort-button" id="devDurationSort" type="button" aria-label="按研发时长正序排列">
                  <span>研发时长</span>
                  <span class="sort-indicator" id="devDurationSortIndicator">↓</span>
                  <span class="sort-hint" id="devDurationSortHint">长 → 短</span>
                </button>
              </th>
              <th>Reporter</th>
              <th>Components</th>
            </tr>
          </thead>
          <tbody>
            {''.join(rows) if rows else '<tr><td colspan="10">没有搜索结果</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  </section>
  </main>
  <script>
    const statusFilter = document.getElementById("statusFilter");
    const visibleCount = document.getElementById("visibleCount");
    const tableBody = document.querySelector("tbody");
    const resultRows = Array.from(document.querySelectorAll("tbody tr[data-status-group]"));
    const statusCards = Array.from(document.querySelectorAll(".status-card"));
    const devStartHeader = document.getElementById("devStartHeader");
    const devStartSort = document.getElementById("devStartSort");
    const devStartSortIndicator = document.getElementById("devStartSortIndicator");
    const devStartSortHint = document.getElementById("devStartSortHint");
    const devDurationHeader = document.getElementById("devDurationHeader");
    const devDurationSort = document.getElementById("devDurationSort");
    const devDurationSortIndicator = document.getElementById("devDurationSortIndicator");
    const devDurationSortHint = document.getElementById("devDurationSortHint");
    let devStartSortDirection = "asc";
    let devDurationSortDirection = "desc";

    function applyStatusFilter() {{
      const selected = statusFilter.value;
      let count = 0;
      for (const row of resultRows) {{
        const matched = selected === "all" || row.dataset.statusGroup === selected;
        row.style.display = matched ? "" : "none";
        if (matched) {{
          count += 1;
        }}
      }}
      visibleCount.textContent = String(count);
      for (const card of statusCards) {{
        card.classList.toggle("active", card.dataset.filter === selected);
      }}
    }}

    function compareDevStartRows(a, b, direction) {{
      const left = a.dataset.devStart || "";
      const right = b.dataset.devStart || "";
      if (!left && !right) {{
        return 0;
      }}
      if (!left) {{
        return 1;
      }}
      if (!right) {{
        return -1;
      }}
      const result = left.localeCompare(right);
      return direction === "asc" ? result : -result;
    }}

    function sortByDevStart(direction) {{
      resultRows
        .slice()
        .sort((a, b) => compareDevStartRows(a, b, direction))
        .forEach((row) => tableBody.appendChild(row));
      devStartSortDirection = direction;
      devStartHeader.setAttribute("aria-sort", direction === "asc" ? "ascending" : "descending");
      devStartSort.setAttribute("aria-label", direction === "asc" ? "按 DEVSTART 倒序排列" : "按 DEVSTART 正序排列");
      devStartSortIndicator.textContent = direction === "asc" ? "↑" : "↓";
      devStartSortHint.textContent = direction === "asc" ? "早 → 晚" : "晚 → 早";
      devDurationHeader.setAttribute("aria-sort", "none");
      devDurationSortIndicator.textContent = "↕";
      devDurationSortHint.textContent = "时长";
      applyStatusFilter();
    }}

    function compareDurationRows(a, b, direction) {{
      const leftRaw = a.dataset.devDuration || "";
      const rightRaw = b.dataset.devDuration || "";
      if (!leftRaw && !rightRaw) {{
        return 0;
      }}
      if (!leftRaw) {{
        return 1;
      }}
      if (!rightRaw) {{
        return -1;
      }}
      const result = Number(leftRaw) - Number(rightRaw);
      return direction === "asc" ? result : -result;
    }}

    function sortByDuration(direction) {{
      resultRows
        .slice()
        .sort((a, b) => compareDurationRows(a, b, direction))
        .forEach((row) => tableBody.appendChild(row));
      devDurationSortDirection = direction;
      devDurationHeader.setAttribute("aria-sort", direction === "asc" ? "ascending" : "descending");
      devDurationSort.setAttribute("aria-label", direction === "asc" ? "按研发时长倒序排列" : "按研发时长正序排列");
      devDurationSortIndicator.textContent = direction === "asc" ? "↑" : "↓";
      devDurationSortHint.textContent = direction === "asc" ? "短 → 长" : "长 → 短";
      devStartHeader.setAttribute("aria-sort", "none");
      devStartSortIndicator.textContent = "↕";
      devStartSortHint.textContent = "日期";
      applyStatusFilter();
    }}

    statusFilter.addEventListener("change", applyStatusFilter);
    devStartSort.addEventListener("click", () => {{
      sortByDevStart(devStartSortDirection === "asc" ? "desc" : "asc");
    }});
    devDurationSort.addEventListener("click", () => {{
      sortByDuration(devDurationSortDirection === "asc" ? "desc" : "asc");
    }});
    for (const card of statusCards) {{
      card.addEventListener("click", () => {{
        statusFilter.value = card.dataset.filter;
        applyStatusFilter();
      }});
    }}
    sortByDuration("desc");
  </script>
</body>
</html>
"""


def render_html(server: str, jql: str, data: dict, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    output_path = output_dir / f"jira-search-{timestamp}.html"
    output_path.write_text(render_html_document(server, jql, data), encoding="utf-8")
    return output_path


def format_jira_date(value: str) -> str:
    match = re.match(r"^(\d{4}-\d{2}-\d{2})", value or "")
    return match.group(1) if match else value


def dev_duration_value(dev_start: str, dev_end: str) -> int | None:
    if not dev_start:
        return None
    try:
        start = dt.date.fromisoformat(dev_start)
        end = dt.date.fromisoformat(dev_end) if dev_end else dt.datetime.now().date()
    except ValueError:
        return None
    return (end - start).days


def format_duration(value: int | None) -> str:
    return "" if value is None else f"{value} 天"


def status_filter_group(status: str) -> str:
    normalized = re.sub(r"[\s_-]+", "", (status or "").lower())
    if normalized == "waiting":
        return "waiting"
    if normalized == "prd":
        return "prd"
    if normalized in {"developing", "testing", "reviewing"}:
        return "in-development"
    return "uat-other"


def status_display_label(status: str) -> str:
    return status


def user_display(user: dict) -> str:
    return user.get("displayName") or user.get("name") or user.get("emailAddress") or ""


def open_file(path: Path) -> None:
    try:
        subprocess.run(["open", str(path)], check=False)
    except FileNotFoundError:
        return


def open_url(url: str) -> None:
    try:
        subprocess.run(["open", url], check=False)
    except FileNotFoundError:
        return


def parse_max_results(value: str | None, default: int) -> int:
    if not value:
        return default
    try:
        parsed = int(value)
    except ValueError:
        return default
    return parsed if parsed > 0 else default


def error_html(message: str) -> str:
    escaped = html.escape(str(message))
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  {favicon_link()}
  <title>Jira 查询失败</title>
  <style>
    body {{
      margin: 0;
      background: #f6f8fb;
      color: #172b4d;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.5;
    }}
    main {{
      width: min(860px, calc(100vw - 48px));
      margin: 48px auto;
      border: 1px solid #dfe4ec;
      border-radius: 8px;
      background: #fff;
      padding: 20px;
      box-shadow: 0 10px 28px rgba(23, 43, 77, 0.08);
    }}
    h1 {{ font-size: 22px; margin: 0 0 12px; }}
    pre {{ white-space: pre-wrap; word-break: break-word; }}
  </style>
</head>
<body>
  <main>
    <h1>Jira 查询失败</h1>
    <pre>{escaped}</pre>
  </main>
</body>
</html>
"""


def web_shell_html() -> str:
    return """<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%231f6feb'/%3E%3Ccircle cx='32' cy='32' r='18' fill='none' stroke='white' stroke-width='5'/%3E%3Cpath d='M32 20v13l10 6' fill='none' stroke='white' stroke-width='5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M18 51h28' fill='none' stroke='white' stroke-width='5' stroke-linecap='round'/%3E%3C/svg%3E">
  <title>Jira 交付时长分析</title>
  <style>
    :root {
      --bg: #f6f8fb;
      --surface: #ffffff;
      --line: #dfe4ec;
      --line-strong: #c8d1df;
      --text: #172b4d;
      --muted: #5e6c84;
      --blue: #1f6feb;
      --blue-soft: #e9f2ff;
      --blue-dark: #1558c7;
      --shadow: 0 10px 28px rgba(23, 43, 77, 0.08);
    }
    * { box-sizing: border-box; }
    html, body { height: 100%; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 14px;
    }
    .web-shell {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    .web-toolbar {
      align-items: center;
      background: rgba(255, 255, 255, 0.96);
      border-bottom: 1px solid var(--line);
      box-shadow: var(--shadow);
      display: flex;
      gap: 16px;
      justify-content: space-between;
      min-height: 64px;
      padding: 12px 24px;
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .toolbar-title {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }
    h1 {
      font-size: 17px;
      line-height: 1.25;
      margin: 0;
      letter-spacing: 0;
    }
    .title-lockup {
      align-items: center;
      display: inline-flex;
      gap: 8px;
    }
    .title-icon {
      align-items: center;
      background: var(--blue-soft);
      border: 1px solid #c8ddff;
      border-radius: 8px;
      color: var(--blue);
      display: inline-flex;
      flex: 0 0 auto;
      height: 30px;
      justify-content: center;
      width: 30px;
    }
    .title-icon svg {
      display: block;
      height: 18px;
      width: 18px;
    }
    .status-line {
      color: var(--muted);
      font-size: 12px;
      min-height: 18px;
    }
    .actions {
      align-items: center;
      display: flex;
      gap: 10px;
      flex: 0 0 auto;
    }
    .refresh-button {
      align-items: center;
      background: var(--blue);
      border: 1px solid var(--blue);
      border-radius: 6px;
      color: #fff;
      cursor: pointer;
      display: inline-flex;
      font: inherit;
      font-weight: 700;
      gap: 8px;
      min-height: 36px;
      padding: 7px 12px;
      transition: background 160ms ease, border-color 160ms ease, box-shadow 160ms ease;
    }
    .refresh-button:hover {
      background: var(--blue-dark);
      border-color: var(--blue-dark);
      box-shadow: 0 8px 18px rgba(31, 111, 235, 0.22);
    }
    .refresh-button:disabled {
      cursor: wait;
      opacity: 0.72;
    }
    .loading-panel {
      align-items: center;
      display: flex;
      flex: 1;
      justify-content: center;
      padding: 32px;
    }
    .loading-card {
      align-items: center;
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 8px;
      box-shadow: var(--shadow);
      display: flex;
      gap: 14px;
      min-width: min(420px, calc(100vw - 48px));
      padding: 18px 20px;
    }
    .spinner {
      animation: spin 900ms linear infinite;
      border: 3px solid #dbe7fb;
      border-top-color: var(--blue);
      border-radius: 999px;
      height: 28px;
      width: 28px;
    }
    .loading-title {
      display: block;
      font-size: 16px;
      font-weight: 800;
      margin-bottom: 2px;
    }
    .loading-copy {
      color: var(--muted);
      font-size: 13px;
    }
    iframe {
      border: 0;
      display: none;
      flex: 1;
      min-height: calc(100vh - 64px);
      width: 100%;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    @media (max-width: 720px) {
      .web-toolbar {
        align-items: stretch;
        flex-direction: column;
        gap: 10px;
        padding: 12px;
      }
      .actions { justify-content: flex-start; }
      iframe { min-height: calc(100vh - 106px); }
    }
  </style>
</head>
<body>
  <main class="web-shell">
    <div class="web-toolbar">
      <div class="toolbar-title">
        <h1 class="title-lockup">
          <span class="title-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="8"></circle>
              <path d="M12 8v4l3 2"></path>
              <path d="M4 19h16"></path>
            </svg>
          </span>
          <span>Jira 交付时长分析</span>
        </h1>
        <span class="status-line" id="statusLine">查询中...</span>
      </div>
      <div class="actions">
        <button class="refresh-button" id="refreshButton" type="button" disabled>
          <span aria-hidden="true">↻</span>
          <span>重新查询</span>
        </button>
      </div>
    </div>
    <section class="loading-panel" id="loadingPanel" aria-live="polite">
      <div class="loading-card">
        <span class="spinner" aria-hidden="true"></span>
        <span>
          <span class="loading-title">查询中...</span>
          <span class="loading-copy">正在请求 Jira API 并计算研发时长</span>
        </span>
      </div>
    </section>
    <iframe id="reportFrame" title="Jira report"></iframe>
  </main>
  <script>
    const frame = document.getElementById("reportFrame");
    const loadingPanel = document.getElementById("loadingPanel");
    const refreshButton = document.getElementById("refreshButton");
    const statusLine = document.getElementById("statusLine");

    function reportUrl() {
      const params = new URLSearchParams(window.location.search);
      params.set("_ts", String(Date.now()));
      return "/report?" + params.toString();
    }

    function setLoading() {
      refreshButton.disabled = true;
      frame.style.display = "none";
      loadingPanel.style.display = "flex";
      statusLine.textContent = "查询中...";
    }

    function refreshReport() {
      setLoading();
      frame.src = reportUrl();
    }

    frame.addEventListener("load", () => {
      loadingPanel.style.display = "none";
      frame.style.display = "block";
      refreshButton.disabled = false;
      statusLine.textContent = "上次刷新：" + new Date().toLocaleString();
    });
    refreshButton.addEventListener("click", refreshReport);
    refreshReport();
  </script>
</body>
</html>
"""


def run_web_server(server: str, token: str, args: argparse.Namespace) -> int:
    base_query_text = " ".join(args.query).strip()
    base_jql = args.jql.strip() if args.jql else ""
    base_max_results = args.max_results

    class JiraReportHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, format: str, *values: object) -> None:
            print(f"[web] {self.address_string()} - {format % values}", file=sys.stderr)

        def write_response(self, status_code: int, body: str, content_type: str = "text/html; charset=utf-8") -> None:
            encoded = body.encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(encoded)

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/healthz":
                self.write_response(200, "ok\n", "text/plain; charset=utf-8")
                return
            if parsed.path in {"/", "/index.html"}:
                self.write_response(200, web_shell_html())
                return
            if parsed.path != "/report":
                self.write_response(404, "Not Found\n", "text/plain; charset=utf-8")
                return

            params = urllib.parse.parse_qs(parsed.query)
            request_jql = (params.get("jql") or [""])[0].strip()
            request_query = (params.get("q") or params.get("query") or [""])[0].strip()
            max_results = parse_max_results((params.get("maxResults") or [""])[0], base_max_results)
            try:
                jql = ensure_order_by(request_jql) if request_jql else build_jql(request_query or base_query_text)
                data = build_report_data(server, token, jql, max_results)
                self.write_response(200, render_html_document(server, jql, data))
            except (Exception, SystemExit) as exc:
                self.write_response(500, error_html(exc))

    try:
        httpd = http.server.ThreadingHTTPServer((DEFAULT_WEB_HOST, DEFAULT_WEB_PORT), JiraReportHandler)
    except OSError as exc:
        raise SystemExit(f"无法监听 http://{DEFAULT_WEB_HOST}:{DEFAULT_WEB_PORT}/：{exc}") from exc

    url = f"http://{DEFAULT_WEB_HOST}:{DEFAULT_WEB_PORT}/"
    print(f"Web: {url}")
    print("访问页面时会实时查询 Jira API。可用 URL 参数：?q=自然语言条件 或 ?jql=JQL&maxResults=100")
    if not args.no_open:
        open_url(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nWeb server stopped.")
    finally:
        httpd.server_close()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Search Shopee Jira and render an HTML report.")
    parser.add_argument("query", nargs="*", help="Natural-language search condition.")
    parser.add_argument("--jql", help="Use explicit JQL instead of natural-language conversion.")
    parser.add_argument("--max-results", type=int, default=DEFAULT_MAX_RESULTS)
    parser.add_argument("--output-dir", default="jira_search_results")
    parser.add_argument("--web", action="store_true", help="Serve a live local report at http://127.0.0.1:26513/.")
    parser.add_argument("--no-open", action="store_true", help="Do not open the generated HTML file.")
    args = parser.parse_args()

    server, token = load_config()
    if args.web:
        return run_web_server(server, token, args)

    query_text = " ".join(args.query).strip()
    jql = ensure_order_by(args.jql.strip()) if args.jql else build_jql(query_text)
    data = build_report_data(server, token, jql, args.max_results)
    output_path = render_html(server, jql, data, Path(args.output_dir))
    if not args.no_open:
        open_file(output_path)
    print(f"JQL: {jql}")
    print(f"Results: {len(data.get('issues', []))} / total {data.get('total', 0)}")
    print(f"HTML: {output_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
