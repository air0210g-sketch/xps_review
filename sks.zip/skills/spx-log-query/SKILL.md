---
name: spx-log-query
description: 通过 MCP 日志服务器查询和分析 SPX 派送服务日志。当用户需要搜索日志、排查问题、追踪请求、调试错误或分析 live/uat/test/staging 环境的系统行为时使用。触发关键词：日志、log、trace、调试、debug、排查、报错、追踪、订单号查询，或任何包含 live/uat/test/staging 环境日志查询的请求。
---

# SPX 日志查询

## 0. MCP 前置检查

执行日志查询前，先检查所需的 MCP 服务器是否已连接。若用户的 MCP 未配置或连接失败，告知用户按以下步骤安装：

### 安装步骤

1. **生成 API Token**：
   - LIVE 环境（对应 live、BR uat）：https://space.shopee.io/observability/log/access-tokens
   - NON-LIVE 环境（对应 test、staging、SEA uat）：https://space.shopee.io/observability/lognonlive/access-tokens

2. **在 Cursor 中添加 MCP Server**：`Cmd + Shift + P` → `Cursor Settings` → `MCP` → `+ Add new MCP server`

3. **添加以下配置**（将 `{your_api_token}` 替换为第 1 步生成的 token）：

**live-uat-log-mcp**（查 live / BR uat 环境日志）：
```json
{
    "mcpServers": {
        "live-uat-log-mcp": {
            "url": "https://log.shopee.io/openapi/v1/mcp",
            "headers": {
                "Authorization": "Bearer {your_api_token}"
            }
        }
    }
}
```

**test-staging-log-mcp**（查 test / staging / SEA uat 环境日志）：
```json
{
    "mcpServers": {
        "test-staging-log-mcp": {
            "url": "https://log.test.shopee.io/openapi/v1/mcp",
            "headers": {
                "Authorization": "Bearer {your_api_token}"
            }
        }
    }
}
```

4. **验证**：确认 MCP Server 状态为绿色（已连接）后即可使用。

## 1. 环境路由

根据用户指定的环境和市场选择对应的 MCP 服务器：

| 环境 | 市场 | MCP 服务器 | Server ID |
|------|------|-----------|-----------|
| **live** | 任意市场 | live-uat-log-mcp | `user-live-uat-log-mcp` |
| **uat** | **BR** | live-uat-log-mcp | `user-live-uat-log-mcp` |
| **uat** | **SG / TH / VN / ID / PH / MY / TW**（SEA） | test-staging-log-mcp | `user-test-staging-log-mcp` |
| **test** | 任意市场 | test-staging-log-mcp | `user-test-staging-log-mcp` |
| **staging** | 任意市场 | test-staging-log-mcp | `user-test-staging-log-mcp` |

**环境为必填项。** 若用户未指定环境，必须先询问再执行查询。

**env=uat 时市场也必填。** 若用户只说 uat 但未说明市场，必须先询问市场；BR UAT 使用 live-uat-log-mcp，SEA UAT 使用 test-staging-log-mcp。

## 2. 应用注册表

### 默认应用（每次查询都包含）：

```
shopee.supply_chain.spx.delivery.deliveryapi
shopee.supply_chain.spx.delivery.deliverytask
```

### 扩展应用（按需加入查询）：

| 应用 | 加入条件 |
|------|---------|
| `shopee.supply_chain.spx.delivery.lmrouteapi` | 涉及路由/Zone/区域集群/多边形相关查询 |
| `shopee.supply_chain.spx.delivery.lmroutetask` | 路由异步任务、路线计算 |
| `shopee.supply_chain.spx.instation.instationapi` | 站内操作/分拣/Plan 创建 |
| `shopee.supply_chain.spx.instation.instationtask` | 站内异步任务 |

### 未知服务

当日志中发现外部服务调用（如 gRPC 调用其他微服务）且需要查询其日志时：
1. 先尝试从代码推断 CMDB 服务名（检查 `thirdpart/` 目录或 gRPC 客户端配置）
2. 若无法推断，向用户询问服务名

## 3. 时间范围规则

### 默认行为（用户未指定时间）

查询**当天日志**：从 `00:00:00` 到当前时间，时区使用 `+08:00`（SGT）。

示例（假设今天是 2026-03-31）：
- `start_time`: `2026-03-31T00:00:00.000+08:00`
- `end_time`: `2026-03-31T23:59:59.000+08:00`

### 用户指定时间范围

解析用户的自然语言时间描述，转换为 RFC3339 格式：

| 用户输入示例 | start_time | end_time |
|---|---|---|
| "今天下午3点到5点" | `2026-03-31T15:00:00.000+08:00` | `2026-03-31T17:00:00.000+08:00` |
| "昨天的日志" | `2026-03-30T00:00:00.000+08:00` | `2026-03-30T23:59:59.000+08:00` |
| "最近1小时" | (当前时间 - 1h) | (当前时间) |
| "3月28号 10:00~12:00" | `2026-03-28T10:00:00.000+08:00` | `2026-03-28T12:00:00.000+08:00` |
| "最近30分钟" | (当前时间 - 30min) | (当前时间) |

### 超时防护

- 默认全天查询超时时，自动缩小到最近 2 小时重试
- 用户指定范围超过 4 小时时，提醒可能超时并建议分段查询
- 通配符查询（如 `*`）限制最大 1 小时

## 4. 工作流程

### 第一步：解析用户请求

从用户问题中提取：
- **环境**：live / uat / test / staging（必填）
- **市场**：BR / SG / TH / VN / ID / PH / MY / TW（env=uat 时必填；其他环境可选，影响日志内容）
- **关键词**：trace ID、订单号、AT ID、司机 ID、错误信息、API 名称等
- **时间范围**：用户指定的时间段，或默认查当天（参见第 3 节）
- **意图**：用户想了解什么（错误原因、请求流程、数据状态等）

### 第二步：分析代码上下文

查询日志前，先搜索代码仓理解相关逻辑：
- 找到与用户问题相关的 handler/service 方法
- 识别涉及的 Kafka topic、event code 和异步任务
- 识别外部服务调用（gRPC/HTTP），判断是否需要查询额外服务的日志
- 利用代码上下文帮助解读日志条目，决定是否需要扩展查询范围

### 第三步：构建并执行查询

**工具**：`CallMcpTool`，server 取自第一步，toolName: `search_logs`

**必填参数**：
- `applications`：CMDB 服务名数组
- `start_time`：RFC3339 格式（按第 3 节时间规则）
- `end_time`：RFC3339 格式（按第 3 节时间规则）
- `query`：PQL 查询字符串

**时间范围**：按第 3 节规则 — 使用用户指定范围，或默认查当天。

**查询规则**：
- 搜索词必须用双引号包裹：`"BR261459249346H"`
- 泛查询（无具体关键词）使用 `*`
- 查询超时时，自动缩小时间窗口重试（参见第 3 节超时防护）
- 持续超时时，分段查询后合并结果

**分页**：使用响应中的 `next_cursor` 获取更多结果。

### 第四步：分析与交叉关联

- 按时间顺序解析日志条目，还原请求处理流程
- 识别调用的 gRPC/HTTP 方法、请求体、响应和耗时
- 追踪 Kafka 消息：识别 topic、event_code、接收方（Saturn 异步任务）
- 若日志中发现外部服务调用，用相同 trace ID 查询该服务的日志
- 关联 deliveryapi（同步阶段）和 deliverytask（异步阶段）的日志

### 第五步：输出结构化总结

以结构化格式呈现结果：
1. **请求概览**：什么操作、谁触发、何时、结果如何
2. **关键数据**：订单信息、AT 信息、司机信息等
3. **处理流程**：逐步说明发生了什么（同步阶段 + 异步阶段）
4. **错误/告警**：发现的错误及其影响
5. **回答用户问题**：直接回答用户提出的问题

## 5. 查询模式

### 按 trace ID 查询
```
query: "SPX-INSTATIONAPI-LIVE-BR-0a374981-493018-1084061858"
```

### 按订单号查询
```
query: "BR261459249346H"
```

### 按 AT ID 查询
```
query: "AT2026033034LDF"
```

### 按错误级别查询
```
query: "ERROR"
```

### 组合查询（用 AND 取交集）
```
query: "BR261459249346H" AND "ERROR"
```

## 6. 日志格式参考

### deliveryapi 日志字段
```
timestamp|LEVEL|process|goroutine|file:line|function|trace_id|content
```

关键模式：
- `[LogProvider@Chassis]latency:XXX` — 收到的 gRPC/HTTP 请求及总耗时
- `[LogConsumer@Chassis]latency:XXX` — 发出的 RPC 调用及耗时
- SQL 语句带有 `[X.XXms]` 耗时和 `[N rows affected or returned]` 行数
- `LockDecorator locker unlock` — 分布式锁释放
- `KafkaCommon send sync message success` — Kafka 消息发送成功

### deliverytask 日志字段
```
timestamp|LEVEL|process|goroutine|file:line|function|trace_id|content
```

关键模式：
- `SATURN,SaturnSyncMsg,METHOD=topic##task_name` — Saturn 异步任务执行
- `RESPONSE={"Retcode":0,"Message":"success"}` — 异步任务执行成功
- `handleFetchedRecords records.count():N` — Kafka 消费者批量大小

## 7. 常见坑点

- **泛查询超时**：默认查当天全天日志；超时后自动缩小到最近 2 小时重试。高流量应用的全天 `*` 查询必定超时。
- **PQL 语法错误**：含特殊字符的裸字符串会导致 400 错误，搜索词必须用双引号包裹。
- **遗漏异步流程**：deliveryapi 发送 Kafka 消息，实际处理在 deliverytask 中执行，两个服务必须都查。
- **跨服务追踪**：使用 `Root-Message-Id` 或 `X-Ssc-Global-Id` 请求头的值在不同服务间串联日志。
