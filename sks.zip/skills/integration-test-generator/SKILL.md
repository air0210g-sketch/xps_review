# Integration Test Generator（TC 驱动集成测试生成）

## 目标与边界

根据 **TD（技术方案）、PRD（产品需求文档）、TC Mapping 文档** 的内容，为指定的测试用例自动生成 **不 mock 内部中间件**（DB / Redis / Apollo）的 Go 集成测试，通过真实数据库写入与清理来验证端到端逻辑。

**核心约束**：
- **Mock 外部**：仅 mock 外部 HTTP / gRPC 服务（通过 `MOCKHTTP=TRUE` 环境变量）
- **真实内部**：DB（Scorm/GORM）、Redis、Apollo 配置均使用测试环境真实连接
- **数据自清理**：所有测试数据在 TearDown 中删除，不留残留
- **不影响现有测试**：集成测试放在独立目录或使用 `//go:build integration` 标签，与纯 mock 单测隔离

```
┌──────────────────────────────────────────────────────────────┐
│                  Integration Test 边界                        │
├──────────────────────────────────────────────────────────────┤
│  ✅ Real:  MySQL (via Chassis SCORM)                         │
│  ✅ Real:  Redis (via config.UnmarshalConfig)                │
│  ✅ Real:  Apollo Config (via Chassis)                       │
│  ❌ Mock:  外部 gRPC/HTTP (MOCKHTTP=TRUE)                   │
│  ❌ Mock:  Saturn 异步任务调度 (frameworkJob.AutoCall)        │
│  ❌ Mock:  Driver 服务 / Smart-Sorting 服务 / Route 服务     │
│  ❌ Mock:  Roster Planning Event Facade                      │
└──────────────────────────────────────────────────────────────┘
```

## 何时使用

- 用户说「集成测试」「integration test」「真实DB测试」「不mock内部」「TC集成测试」
- 用户提供 TC 编号或功能域，要求生成端到端验证
- 用户要求为 TC Mapping 文档的「集成测试」列补充覆盖

## 何时不要用

- 用户只要求纯 mock 单测 → 使用 `golang-gomonkey-access-handler-tests` skill
- 用户只要求分析 TC 覆盖率 → 使用 `tc-implementation-mapper` skill
- 目标代码不涉及 DB/缓存操作（纯业务逻辑/计算函数）→ 纯 mock 单测更合适

## 输入（向用户确认）

| 字段 | 必填 | 说明 | 默认值 |
|------|------|------|--------|
| `tc_mapping_path` | 是 | TC Mapping 文档路径 | 无 |
| `target_tcs` | 是 | 目标 TC 编号列表或功能域名称 | 无 |
| `cid` | **是** | 测试环境国家代码（如 `br`、`sg`、`id`、`th`、`vn`、`ph`） | **无，必须由用户指定** |
| `env` | **是** | 测试环境名称（如 `test`、`uat`、`staging`） | **无，必须由用户指定** |
| `module_path` | 否 | 集成测试输出目录 | 从 TC 对应代码自动推断 |

> ⚠️ **`cid` 和 `env` 是阻塞项**：chassis 初始化依赖 `CID` 和 `ENV` 环境变量来决定连接哪个 Apollo 集群和 DB 实例。**不同国家的 DB schema、Apollo namespace 配置、Redis 集群地址均不同**，如果使用错误的环境会导致连接失败或操作到错误的数据。Agent **禁止**假设默认值，必须在生成代码前获取用户明确确认。

## 输出

1. **集成测试 Go 文件**（带 `//go:build integration` 标签）
2. **更新的 TC Mapping 文档**（集成测试列标记 ✅）
3. **测试运行结果摘要**

## 执行步骤

### 前置步骤（⚠️ 阻塞项）：确认测试环境与国家

在开始任何代码生成之前，**必须**向用户确认以下两项：

1. **国家代码（CID）**：决定 Apollo 集群、DB 实例、Redis 地址
   - 可选值：`br`、`sg`、`id`、`th`、`vn`、`ph`、`my`、`tw` 等
   - 不同国家的 schema 可能有差异（如 BR 有 CIOT/MDFe 相关表，SG 有 Driver Group）

2. **测试环境（ENV）**：决定连接的环境级别
   - 可选值：`test`（SIT）、`uat`、`staging`
   - **禁止连接 `live`（生产环境）**

**如果用户未提供，Agent 必须主动询问并等待回复，禁止使用任何默认值继续生成。**

询问模板：
```
生成集成测试前，需要确认测试环境配置（chassis 初始化依赖这两项来连接正确的 DB/Redis/Apollo）：

1. **国家代码（CID）**：br / sg / id / th / vn / ph / ...？
2. **测试环境（ENV）**：test / uat / staging？
```

### Step 0：分析 TC 与代码映射

1. **读取 TC Mapping 文档**（`Read` 工具），定位目标 TC 行，提取：
   - TC 编号、优先级、用例名称
   - 对应代码位置（service / repository / model）
   - 当前单测覆盖状态
   - 集成测试列当前状态

2. **读取相关 TD/PRD**（从 Mapping 文档头部的参考链接或 `AI_gen/` 目录获取），理解：
   - 业务场景与验收标准
   - 数据模型与状态流转
   - 涉及的中间件（DB 表、缓存 key、消息队列）

3. **判断适用性**：只有涉及以下操作的 TC 适合集成测试：
   - DB CRUD（Config 创建/更新/查询、状态变更）
   - 缓存读写（Redis key 写入/失效验证）
   - 多步骤状态流转（Pending → Completed → Failed）
   - 跨 repository 的数据一致性

### Step 1：探索目标代码结构

1. **定位 Model**：读取 `repository/model/` 下的表结构定义，确认：
   - `TableName()` 返回的表名
   - `DBName()` 返回的数据库集群名（如 `fms`、`default`）
   - 所有字段名常量（用于 `dbhelper.Filters`）
   - 主键和唯一键

2. **定位 Repository**：读取 repository 文件，确认：
   - CRUD 方法签名（Create / Get / Update / Delete）
   - 使用的 `database` 包函数（`CreateObject` / `GetObject` / `UpdateObjects` / `DeleteObjects`）
   - 查询条件类型（`*databaseDefine.QueryCondition` / `*databaseDefine.QueryConditionV3`）

3. **定位 Service**（如需测试 service 层）：读取 service 文件，确认：
   - service 初始化方式（单例 `Get*Service()` / `New*Service()`）
   - 方法签名和参数类型（`request.*Req` → `response.*Rsp`）
   - 内部依赖（其他 service / 外部 client）

4. **检查现有 TestMain**：确认目标包是否已有 `TestMain`：
   - **有且无 build tag** → 集成测试必须放在独立子目录（如 `integration_test/`）
   - **有且有 `//go:build integration`** → 可以在同包追加
   - **无** → 可以在同包创建带 `//go:build integration` 的 `TestMain`

### Step 2：生成集成测试代码

#### 2.1 TestMain 文件（`main_test.go`）

每个集成测试目录需要一个 `main_test.go`，负责环境初始化：

```go
//go:build integration
// +build integration

package integration_test

import (
    "context"
    "os"
    "path/filepath"
    "testing"

    "git.garena.com/shopee/bg-logistics/go/chassis"
    "git.garena.com/shopee/bg-logistics/go/chassis/cache"
    "git.garena.com/shopee/bg-logistics/go/chassis/config"
    "git.garena.com/shopee/bg-logistics/go/chassis/handler"
    "git.garena.com/shopee/bg-logistics/go/chassis/handler/scormhelper"
    dbCommonHandler "git.garena.com/shopee/bg-logistics/spx/common/spx-db-common/dbcommon/monitor/handler"

    clientCache "delivery/client/cache"
    "delivery/client/db"
)

func TestMain(m *testing.M) {
    cid := os.Getenv("CID")
    if cid == "" {
        panic("CID environment variable is required (e.g. CID=br)")
    }
    env := os.Getenv("ENV")
    if env == "" {
        env = "test"
    }
    if env == "live" {
        panic("ENV=live is forbidden for integration tests")
    }
    _ = os.Setenv("MOCKHTTP", "TRUE")
    _ = os.Setenv("ENV", env)
    _ = os.Setenv("CID", cid)
    _ = os.Setenv("CHASSIS_CONF_DIR", findProjectRoot()+"/conf/server")

    _ = handler.RegisterScormHandler(
        scormhelper.WithScormConfig("scorm.mysql"),
        scormhelper.WithHook(db.RegisterScormCallback),
    )
    handler.RegisterPrometheusMetricHandler()
    dbCommonHandler.RegisterDBCommonHandler()
    handler.RegisterCacheHandler(cache.WithCacheConfig("common.cache"))

    if err := chassis.Init(
        chassis.WithDefaultProviderHandlerChain(
            handler.NameOfPrometheusMetricProvider,
            handler.ScormHandlerName,
            dbCommonHandler.DBCommonHandlerName,
            handler.CacheHandler,
        ),
    ); err != nil {
        panic("chassis init: " + err.Error())
    }

    redisConfig := &clientCache.RedisOptions{}
    if err := config.UnmarshalConfig(clientCache.SecondRedisConf, redisConfig); err != nil {
        panic("redis config: " + err.Error())
    }
    if err := clientCache.InitRedis(*redisConfig); err != nil {
        panic("redis init: " + err.Error())
    }

    os.Exit(m.Run())
}

func getTestCtx() context.Context {
    return scormhelper.BindContext(context.Background())
}

func findProjectRoot() string {
    dir, _ := os.Getwd()
    for dir != "/" {
        if _, err := os.Stat(dir + "/go.mod"); err == nil {
            return dir
        }
        parent := filepath.Dir(dir)
        if parent == dir {
            break
        }
        dir = parent
    }
    return ""
}
```

#### 2.2 测试 Suite 文件

使用 `testify/suite` 管理 SetUp / TearDown：

```go
//go:build integration
// +build integration

package integration_test

type ExampleSuite struct {
    suite.Suite
    ctx              context.Context
    repo             *repository.SomeRepo
    svc              *impl.SomeService
    createdIDs       []uint64
    createdBizKeys   []string
}

func TestExample(t *testing.T) {
    suite.Run(t, new(ExampleSuite))
}

func (s *ExampleSuite) SetupSuite() {
    s.ctx = getTestCtx()
    s.repo = repository.GetSomeRepo()
    s.svc = impl.GetSomeService()
}

func (s *ExampleSuite) SetupTest() {
    s.createdIDs = nil
    s.createdBizKeys = nil
}

func (s *ExampleSuite) TearDownTest() {
    s.cleanupTestData()
}

func (s *ExampleSuite) TearDownSuite() {
    s.cleanupTestData()
}

func (s *ExampleSuite) cleanupTestData() {
    if len(s.createdIDs) > 0 {
        _ = database.DeleteObjects(s.ctx, &model.SomeTab{}, dbhelper.Filters{
            model.SomeFieldID + "__in": s.createdIDs,
        })
    }
    if len(s.createdBizKeys) > 0 {
        _ = database.DeleteObjects(s.ctx, &model.SomeTab{}, dbhelper.Filters{
            model.SomeFieldBizKey + "__in": s.createdBizKeys,
        })
    }
}
```

#### 2.3 数据隔离策略

| 策略 | 规则 | 示例 |
|------|------|------|
| Station ID | `99900000+` 范围，按 TC 编号偏移 | `99900001 + 86 = 99900087` |
| String ID | `IT_` 前缀 | `IT_ENTRY_TC1_TASK`, `IT_ROUTE_30_001` |
| Driver ID | `88800000+` 范围 | `88801001`, `88801002` |
| 双重追踪 | 同时追踪自增 ID 和业务键 | TearDown 用两种条件兜底删除 |
| Suite 级兜底 | `TearDownSuite` 再做一次全量清理 | 防 panic 中断导致残留 |
| 环境限制 | `ENV=live` 直接 panic | `main_test.go` 入口强制校验 |

#### 2.4 测试方法模板

每个测试方法遵循 **Arrange → Act → Track → Assert** 模式：

```go
func (s *ExampleSuite) TestTC_XX_Description() {
    // Arrange
    tab := &model.SomeTab{
        StationID: testStationIDBase + 1,
    }

    // Act
    svcErr := s.repo.Create(s.ctx, tab)
    s.Require().Nil(svcErr)

    // Track
    s.createdIDs = append(s.createdIDs, tab.ID)

    // Assert
    got, svcErr := s.repo.GetByID(s.ctx, tab.ID)
    s.Require().Nil(svcErr)
    assert.Equal(s.T(), expectedValue, got.SomeField)
}
```

## 测试模式

### 模式 A：CRUD 持久化验证

适用于新增字段、配置项等场景。

**关键模式**：
- `trackConfig(id, stationID)` 追踪创建的记录，确保清理
- 每个 TC 使用独立 `stationID = testStationIDBase + TC编号` 避免冲突
- Create → Read → Assert 字段值
- Update → Read → Assert 新值生效
- Boundary → Assert 越界被拒绝

**文件组织**：按功能域拆分，如 `config_crud_test.go`、`reallocation_test.go`

### 模式 B：状态流转验证

适用于 Reallocation、Task 状态等场景。

**关键模式**：
- Seed 初始状态记录 → 执行状态变更操作 → Query 验证最终状态
- 批量操作 (`BatchCreate` → `BatchUpdateStatus`) 的原子性
- Pending → Completed / Failed 等转换路径

### 模式 C：端到端流程验证

适用于完整业务流程（如多轮匹配）。需要 `gomonkey` mock 外部依赖。

**关键模式**：
- `gomonkey` 仅用于 mock 外部服务（driver、smart-sorting、Saturn 调度等），内部逻辑走真实路径
- Seed Task(Created) + Config → 调用 `Process()` → 验证 DB 中的 result 和 status
- 验证主表 + 副作用表（如 `route_match_driver_result_tab` + `ct_event_relation_tab`）

**文件组织**：`route_match_entry_test.go` — Suite 中包含 `patches *gomonkey.Patches` 字段，`TearDownTest` 中 `patches.Reset()`

### Step 3：编译验证

运行编译检查（不实际执行测试）：

```bash
go test -tags integration -mod=mod -count=1 -run "^$" ./<package_path>/
```

如果编译失败，根据错误信息修复（常见问题：枚举常量名、import 路径、方法签名不匹配），修复后重新编译直到通过。

### Step 4：运行测试

```bash
CID=<cid> ENV=<env> go test -tags integration -mod=mod -count=1 -v -run "<TestSuiteName>" ./<package_path>/
```

- 检查每个子测试的 PASS/FAIL 状态
- 如有 FAIL，分析原因并修复
- 确认 TearDown 成功清理（可通过再次查询验证无残留数据）

### Step 5：更新 TC Mapping 文档

1. 定位 TC Mapping 文档中对应 TC 行
2. 将「集成测试」列从 `—` 更新为 `✅` 或 `✅ N项`
3. 在「备注」列追加 `IT: <TestName>` 说明
4. 更新文档头部的「集成测试覆盖统计」section
5. 如果运行命令或首次运行信息有变，同步更新

## 关键 API 参考

### DB 操作（`lm-route-common/libs/database`）

| 函数 | 用途 | 签名 |
|------|------|------|
| `database.CreateObject` | 插入单条 | `(ctx, data interface{}, tableInfo ...*define.TableInfo) error` |
| `database.BatchCreateObjects` | 批量插入 | `(ctx, data interface{}, tableInfo ...*define.TableInfo) error` |
| `database.GetObject` | 查询单条 | `(ctx, data interface{}, condition *define.QueryCondition) (bool, error)` |
| `database.GetObjectSlice` | 列表查询 | `(ctx, data interface{}, condition *define.QueryCondition) error` |
| `database.GetObjectSliceV3` | 列表查询 V3 | `(ctx, data interface{}, condition *define.QueryConditionV3) error` |
| `database.UpdateObjects` | 按条件更新 | `(ctx, model interface{}, filters dbhelper.Filters, updateData dbhelper.UpdateData, ...) (int64, error)` |
| `database.DeleteObjects` | 按条件删除 | `(ctx, model interface{}, filters dbhelper.Filters, ...) error` |

### 测试上下文

| 函数 | 用途 |
|------|------|
| `scormhelper.BindContext(ctx)` | 绑定 DB 连接到 context |

### dbhelper 过滤条件

| 语法 | 含义 | 示例 |
|------|------|------|
| `field` | 等于 | `"station_id": 123` |
| `field__in` | IN 列表 | `"id__in": []uint64{1,2,3}` |
| `field__gt` | 大于 | `"ctime__gt": 1000` |
| `field__gte` | 大于等于 | `"ctime__gte": 1000` |

## 运行方式

> ⚠️ **CID 是必填环境变量**，必须由用户指定，不可省略。

```bash
# 运行指定模块的全部集成测试
CID=<cid> ENV=test go test -tags integration -mod=mod -count=1 -v \
  ./apps/<module>/integration_test/

# 仅运行某个 Suite
CID=br ENV=test go test -tags integration -mod=mod -count=1 -v \
  -run "TestConfigCRUD" ./apps/route_match_driver/integration_test/

# 仅编译检查（不需要 CID）
go test -tags integration -mod=mod -count=1 -run "^$" \
  ./apps/<module>/integration_test/
```

## 文件组织结构

```
apps/{module}/integration_test/
├── main_test.go              ← TestMain: Chassis/DB/Redis 初始化, ENV 校验
├── config_crud_test.go       ← Config CRUD 相关 TC (testify/suite)
├── reallocation_test.go      ← Reallocation 状态流转 TC
├── route_match_entry_test.go ← 端到端匹配流程 TC (gomonkey mock 外部)
└── route_match_priority_test.go ← 匹配优先级/轮次持久化 TC
```

## 完整示例

**用户输入**：
> 帮我为 TC#41/42/86/87 生成集成测试，验证 Config CRUD 在真实 DB 上的行为

**Agent 执行流程**：

1. 读取 TC Mapping，定位 TC#41/42/86/87 → Config CRUD 功能域
2. 读取 `route_match_driver_config_tab` Model → 确认表名、字段、DBName
3. 读取 Config Repository → 确认 Create/Get/Update 方法签名
4. 读取 Config Service → 确认 Create/Update 业务逻辑与参数校验
5. 检查 `apps/route_match_driver/service/impl/` 有无 build tag 的 TestMain → 有 → 创建独立 `integration_test/` 目录
6. 生成 `main_test.go`（环境初始化）
7. 生成 `config_crud_test.go`（testify/suite + SetUp/TearDown）：
   - TestTC86: Create 新字段持久化验证
   - TestTC41: AutoDeclineCallUpTime CRUD
   - TestTC42: ReallocateToDeclinedDrivers CRUD
   - TestTC87: Update 新字段生效验证
8. 编译检查 → 修复常量名问题 → 通过
9. 运行测试 → 全部 PASS
10. 更新 TC Mapping 文档集成测试列

## 本仓库参考示例（SPXFM-223633）

| 场景 | 模式 | 路径 |
|------|------|------|
| Config CRUD（Create/Get/Update 新字段持久化） | A: Repository CRUD | `apps/route_match_driver/integration_test/config_crud_test.go` |
| Route Match 优先级（多轮匹配排序验证） | B: Service 层 | `apps/route_match_driver/integration_test/route_match_priority_test.go` |
| Route Match 入口端到端 | C: 端到端流程 | `apps/route_match_driver/integration_test/route_match_entry_test.go` |
| Reallocation（重分配业务逻辑） | B: Service 层 | `apps/route_match_driver/integration_test/reallocation_test.go` |
| 环境初始化（TestMain + DB/Redis/Apollo） | 基础设施 | `apps/route_match_driver/integration_test/main_test.go` |

## 可扩展点

- **Redis 集成测试**：在 SetUp 中写入 Redis key，TearDown 中 DEL，验证缓存策略
- **Apollo 配置测试**：通过 `gomonkey` 临时覆盖 Apollo 值，验证配置驱动的分支逻辑
- **跨模块测试**：在 `integration_test/` 中引入多个 module 的 repo/service，验证跨表一致性
- **CI 集成**：在 CI pipeline 中添加 `go test -tags integration` 步骤，使用独立测试数据库
