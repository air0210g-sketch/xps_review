import sys
import json
import time
import hmac
import hashlib
import base64

def base64url_encode(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    # Use standard base64 urlsafe encoding
    encoded = base64.urlsafe_b64encode(data)
    # Remove padding '=' characters
    return encoded.rstrip(b'=')

def generate_token(shipment_id):
    # Configuration
    jwt_account = 'export_platform'
    # The secret key provided in the example
    jwt_secret = b'ab39d18c43949bc9f6da7f7569541474' 
    
    # Header
    header = {
        'typ': 'JWT',
        'alg': 'HS256',
        'account': jwt_account
    }
    # JSON dumps with separators=(',', ':') removes whitespace to match JS JSON.stringify() default behavior typically used in JWT libraries
    # although standard JSON.stringify adds no spaces, let's be safe.
    # Actually, JS JSON.stringify() produces minimal JSON. Python's default adds spaces.
    # So separators=(',', ':') is correct to mimic standard compact JSON.
    encoded_header = base64url_encode(json.dumps(header, separators=(',', ':')))

    # Payload (Data)
    user_data = {
        "shipment_id": shipment_id
    }
    current_timestamp = int(time.time())
    
    payload_wrapper = {
        'data': user_data,
        'timestamp': current_timestamp
    }
    encoded_payload = base64url_encode(json.dumps(payload_wrapper, separators=(',', ':')))

    # Signature
    token_input = encoded_header + b'.' + encoded_payload
    # HMAC-SHA256
    signature = hmac.new(jwt_secret, token_input, hashlib.sha256).digest()
    encoded_signature = base64url_encode(signature)

    # Final Token
    signed_token = token_input + b'.' + encoded_signature
    return signed_token.decode('utf-8')

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python generate_jwt.py <shipment_id>")
        sys.exit(1)
    
    shipment_id = sys.argv[1]
    print(generate_token(shipment_id))
