#!/usr/bin/env python3
"""
Batch query order delivery status via OpenAPI.

Usage:
    # From stdin (one orderID per line, or orderID,traceID per line)
    echo "SPXID123456\nSPXVN789012" | python check_order_status.py

    # From file
    python check_order_status.py --file orders.txt

    # Direct order IDs
    python check_order_status.py SPXID123456 SPXVN789012

    # Output as CSV
    python check_order_status.py --csv --file orders.txt

Output: JSON array of {order_id, trace_id, market, status, is_delivered}
"""

import sys
import json
import time
import hmac
import hashlib
import base64
import argparse
import csv
import io
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("Error: 'requests' not installed. Run: pip install requests", file=sys.stderr)
    sys.exit(1)

DOMAIN_MAP = {
    "id": "http://spx-delivery-service.ssc.shopee.co.id",
    "vn": "http://spx-delivery-service.ssc.shopee.vn",
    "sg": "http://spx-delivery-service.ssc.shopee.sg",
    "my": "http://spx-delivery-service.ssc.shopee.com.my",
    "th": "http://spx-delivery-service.ssc.shopee.co.th",
    "ph": "http://spx-delivery-service.ssc.shopee.ph",
    "br": "http://spx-delivery-service.ssc.shopee.com.br",
    "tw": "http://spx-delivery-service.ssc.shopee.tw",
}

ORDER_PREFIX_TO_MARKET = {
    "SPXID": "id", "ID": "id",
    "SPXVN": "vn", "VN": "vn",
    "SPXSG": "sg", "SG": "sg",
    "SPXMY": "my", "MY": "my",
    "SPXTH": "th", "TH": "th",
    "SPXPH": "ph", "PH": "ph",
    "SPXBR": "br", "BR": "br",
    "SPXTW": "tw", "TW": "tw",
}

TRACE_MARKET_KEYWORDS = ["id", "vn", "sg", "my", "th", "ph", "br", "tw"]

JWT_ACCOUNT = "export_platform"
JWT_SECRET = b"ab39d18c43949bc9f6da7f7569541474"
API_PATH = "/spx_delivery/openapi/delivery_domain/order_info/query"
MAX_WORKERS = 8
TIMEOUT = 10


def base64url_encode(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return base64.urlsafe_b64encode(data).rstrip(b"=")


def generate_jwt(shipment_id):
    header = {"typ": "JWT", "alg": "HS256", "account": JWT_ACCOUNT}
    payload = {"data": {"shipment_id": shipment_id}, "timestamp": int(time.time())}
    enc_header = base64url_encode(json.dumps(header, separators=(",", ":")))
    enc_payload = base64url_encode(json.dumps(payload, separators=(",", ":")))
    token_input = enc_header + b"." + enc_payload
    sig = hmac.new(JWT_SECRET, token_input, hashlib.sha256).digest()
    return (token_input + b"." + base64url_encode(sig)).decode("utf-8")


def detect_market(order_id, trace_id=""):
    for kw in TRACE_MARKET_KEYWORDS:
        if f"-live-{kw}-" in trace_id or f"-staging-{kw}-" in trace_id:
            return kw
    for prefix, market in ORDER_PREFIX_TO_MARKET.items():
        if order_id.upper().startswith(prefix):
            return market
    return "vn"


def get_domain(market):
    return DOMAIN_MAP.get(market, DOMAIN_MAP["vn"])


def query_single_order(order_id, trace_id=""):
    market = detect_market(order_id, trace_id)
    domain = get_domain(market)
    url = f"{domain}{API_PATH}"
    token = generate_jwt(order_id)

    try:
        resp = requests.post(url, headers={"Content-Type": "application/json"},
                             json={"jwt": token}, timeout=TIMEOUT)
        if resp.status_code != 200:
            return {
                "order_id": order_id, "trace_id": trace_id, "market": market.upper(),
                "status": f"HTTP_{resp.status_code}", "is_delivered": False, "error": resp.text,
            }

        data = resp.json()
        status = "Unknown"
        if "data" in data and isinstance(data["data"], dict):
            status = data["data"].get("lmo_status_text", "Unknown")
            if status == "Unknown":
                do_info = data["data"].get("do_info")
                if do_info and isinstance(do_info, list) and len(do_info) > 0:
                    status = do_info[0].get("do_status_text", "Unknown")

        return {
            "order_id": order_id, "trace_id": trace_id, "market": market.upper(),
            "status": status, "is_delivered": status.lower() == "delivered",
        }
    except Exception as e:
        return {
            "order_id": order_id, "trace_id": trace_id, "market": market.upper(),
            "status": f"Error", "is_delivered": False, "error": str(e),
        }


def query_orders(orders, max_workers=MAX_WORKERS):
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(query_single_order, o["order_id"], o.get("trace_id", "")): o
            for o in orders
        }
        for future in as_completed(futures):
            results.append(future.result())
    return results


def parse_input_line(line):
    """Parse a line: 'orderID' or 'orderID,traceID' or 'orderID traceID'"""
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    parts = line.replace("\t", ",").replace(" ", ",").split(",")
    parts = [p.strip() for p in parts if p.strip()]
    if not parts:
        return None
    order_id = parts[0]
    trace_id = parts[1] if len(parts) > 1 else ""
    return {"order_id": order_id, "trace_id": trace_id}


def main():
    parser = argparse.ArgumentParser(description="Batch query order delivery status")
    parser.add_argument("order_ids", nargs="*", help="Order IDs to check")
    parser.add_argument("--file", "-f", help="File with order IDs (one per line)")
    parser.add_argument("--csv", action="store_true", help="Output as CSV instead of JSON")
    parser.add_argument("--workers", "-w", type=int, default=MAX_WORKERS,
                        help=f"Concurrent workers (default: {MAX_WORKERS})")
    args = parser.parse_args()

    orders = []

    if args.file:
        with open(args.file) as f:
            for line in f:
                parsed = parse_input_line(line)
                if parsed:
                    orders.append(parsed)
    elif args.order_ids:
        for oid in args.order_ids:
            orders.append({"order_id": oid, "trace_id": ""})
    elif not sys.stdin.isatty():
        for line in sys.stdin:
            parsed = parse_input_line(line)
            if parsed:
                orders.append(parsed)
    else:
        parser.print_help()
        sys.exit(1)

    seen = set()
    unique_orders = []
    for o in orders:
        if o["order_id"] not in seen:
            seen.add(o["order_id"])
            unique_orders.append(o)

    if not unique_orders:
        print("No orders to check.", file=sys.stderr)
        sys.exit(1)

    print(f"Checking {len(unique_orders)} orders with {args.workers} workers...",
          file=sys.stderr)
    results = query_orders(unique_orders, max_workers=args.workers)
    results.sort(key=lambda r: (r["market"], r["order_id"]))

    if args.csv:
        output = io.StringIO()
        writer = csv.DictWriter(output,
                                fieldnames=["order_id", "trace_id", "market", "status", "is_delivered"],
                                extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
        print(output.getvalue())
    else:
        print(json.dumps(results, indent=2))

    delivered = sum(1 for r in results if r["is_delivered"])
    print(f"\nSummary: {delivered}/{len(results)} delivered", file=sys.stderr)


if __name__ == "__main__":
    main()
