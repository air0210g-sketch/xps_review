---
name: daily-reconciliation
description: Use when performing daily reconciliation for AddOrderToATGrayscale orders, SPX delivery logs, order delivery status, or unmatched comparison logs.
---

# Daily Reconciliation

## 背景

本 skill 用于做 AddOrderToATGrayscale 日常对账：从各市场日志收集订单样本，批量查询 delivery-domain 订单状态，再对 delivered 订单追查比较日志，找出未完全匹配的订单和差异内容。

| 项目 | 内容 |
| --- | --- |
| 方法 | 按市场查询 AddOrderToATGrayscale 日志，提取 `orderID` 和 trace ID，批量查询状态，再搜索 delivered 订单的比较日志。 |
| 落地要求 | 对账结论不能只看首轮日志，必须关联订单状态和 comparison/unmatched 日志。 |
| 交付产出 | 生成 `daily_reconciliation_<DATE>.csv`，并在聊天中输出总量、已 delivered、未匹配和市场维度摘要。 |

## 0. Skill 使用方式

### 文件组成

| 文件 | 用途 |
| --- | --- |
| `SKILL.md` | 定义对账输入、日志采样、状态查询、比较日志搜索、报告格式和异常处理。 |
| `scripts/check_order_status.py` | 批量查询 delivery-domain 订单状态，支持 stdin、文件、CLI order IDs、JSON/CSV 输出。 |
| `scripts/generate_jwt.py` | 单个 shipment 的 JWT 生成辅助脚本，仅用于调试或脚本内部逻辑参考。 |

### 使用实操

用户可直接点名 skill：

```text
使用 daily-reconciliation，做昨天 AddOrderToATGrayscale 对账，按市场输出 unmatched 订单。
```

最常用输入格式：

```text
时间范围：2026-05-14 00:00:00+08:00 到 2026-05-14 23:59:59+08:00
市场：ID,SG,MY,TH,VN,PH,BR,TW
采样要求：每个市场至少 10 个订单
输出：生成 daily_reconciliation_2026-05-14.csv，并给 summary
```

如果已有订单列表，可直接查状态：

```bash
python3 ~/.cursor/skills/daily-reconciliation/scripts/check_order_status.py \
  --file /tmp/reconciliation_orders_2026-05-14.txt \
  --csv > /tmp/reconciliation_status_2026-05-14.csv
```

文件每行支持：

```text
SPXID123456,SPX-DELIVERY-live-id-xxxxx
SPXVN789012 SPX-DELIVERY-live-vn-yyyyy
SPXSG345678
```

### 输出判定

| 结论 | 判定 |
| --- | --- |
| Fully Matched | 订单已 delivered，且 comparison 日志无 unmatched 内容。 |
| Not Matched | 订单已 delivered，且 comparison 日志明确出现 unmatched 或匹配失败。 |
| NotDelivered | 状态不是 `Delivered`，不进入 comparison 通过判定。 |
| UNKNOWN | 日志、trace ID、订单状态或 comparison 证据不足，不能判断。 |

## 1. 核心目标

- 覆盖 `ID`、`SG`、`MY`、`TH`、`VN`、`PH`、`BR`、`TW` 市场。
- 每个市场尽量收集至少 10 个 AddOrderToATGrayscale 订单样本。
- 批量查询订单 delivery status，区分 delivered 和 pending/other。
- 对 delivered 订单搜索 comparison 日志并提取 unmatched 内容。
- 输出 CSV 文件和聊天摘要，便于 QA/Dev 复核每日对账风险。

## 2. 执行原则

| 原则 | 要求 |
| --- | --- |
| 时间明确 | 用户未提供时间范围时，默认查过去 24 小时到现在。 |
| 市场分治 | 每个市场单独查询和统计，避免样本集中在单一市场。 |
| 样本可追溯 | 每个订单保留 `OrderID`、`TraceID`、market、status 和 unmatched 内容。 |
| 状态先行 | 只有 delivered 订单才进入 comparison 匹配结果判断。 |
| 证据保守 | 缺日志、缺 trace ID、接口异常或 comparison 不明确时输出 `UNKNOWN`，不要猜结论。 |
| 安全输出 | 不在聊天中打印 JWT、secret 或完整敏感请求。 |

## 3. 必填输入

| 输入 | 要求 |
| --- | --- |
| 时间范围 | 用户提供；未提供时默认 last 24h to now。 |
| 市场 | 默认 `ID,SG,MY,TH,VN,PH,BR,TW`，可由用户缩小范围。 |
| 日志入口 | `AddOrderToATGrayscale` 初始日志和同 trace 的 comparison 日志。 |
| 样本目标 | 默认每个市场至少 10 个订单；不足时报告实际数量。 |
| 输出位置 | 默认当前工作区或 `/tmp`，文件名 `daily_reconciliation_<DATE>.csv`。 |

## 4. 执行流程

| 步骤 | 动作 | 结果 |
| --- | --- | --- |
| 1. 准备范围 | 明确时间、市场和每市场目标样本量。 | 查询计划。 |
| 2. 搜首轮日志 | 按市场调用 `live-uat-log-mcp/search_logs` 搜索 `AddOrderToATGrayscale` 日志。 | 原始订单日志。 |
| 3. 提取订单 | 解析 `orderID` 和 `SPX-DELIVERY-live...` trace ID。 | 待查状态订单表。 |
| 4. 批量查状态 | 调用 `check_order_status.py` 并输出 CSV/JSON。 | 订单状态表。 |
| 5. 筛选 delivered | 只保留 `is_delivered=True` 的订单。 | comparison 候选。 |
| 6. 搜比较日志 | 用 trace ID 搜同链路 comparison/unmatched 日志。 | 匹配结果和差异。 |
| 7. 生成报告 | 写出 `daily_reconciliation_<DATE>.csv`。 | 完整对账明细。 |
| 8. 输出摘要 | 按总量和市场维度汇总。 | 聊天结论。 |

## 5. 日志查询规则

### 首轮日志

对每个市场优先使用市场专属 app：

```text
shopee.supply_chain.spx.delivery.deliveryapi-live-<market>
```

若专属 app 无结果或不可用，使用通用 app：

```text
shopee.supply_chain.spx.delivery.deliveryapi
```

通用 app 的查询增加市场关键字：

```text
AddOrderToATGrayscale AND "live-<market>"
```

解析规则：

| 字段 | 规则 |
| --- | --- |
| `order_id` | `orderID[:=]\s*(\w+)` |
| `trace_id` | `traceid[:=]\s*(SPX-DELIVERY-live\S+)`，或日志中出现的 `SPX-DELIVERY-live...` 字段。 |
| `market` | 优先从 trace ID 的 `live-<market>` 推断，其次从订单 prefix 推断。 |

### Comparison 日志

仅对 delivered 订单执行：

```text
traceid:<TRACE_ID> AND "[AddOrderToATGrayscale] "
```

处理要求：

- 搜索同 trace 下的 comparison/unmatched 内容。
- 如果有 unmatched 内容，记录到 `UnmatchedContent`。
- 如果 comparison 日志缺失或无法解析，结论用 `UNKNOWN`。
- 只有日志明确出现 unmatched 或明确匹配失败时，才判定 `Not Matched`。

## 6. 状态查询

优先使用脚本：

```bash
python3 ~/.cursor/skills/daily-reconciliation/scripts/check_order_status.py \
  --file /tmp/reconciliation_orders_<DATE>.txt \
  --csv > /tmp/reconciliation_status_<DATE>.csv
```

脚本支持：

| 参数 | 用途 |
| --- | --- |
| `order_ids...` | 直接传入一个或多个 order ID。 |
| `--file, -f <path>` | 从文件读取订单，每行 `orderID`、`orderID,traceID` 或 `orderID traceID`。 |
| `--csv` | 输出 CSV；默认输出 JSON。 |
| `--workers, -w <n>` | 并发查询数量，默认 `8`。 |
| stdin | 无 CLI 参数且 stdin 非 TTY 时，从 stdin 读取订单。 |

输出字段：

| 字段 | 说明 |
| --- | --- |
| `order_id` | 输入订单号。 |
| `trace_id` | 输入或解析出的 trace ID。 |
| `market` | 大写市场。 |
| `status` | `lmo_status_text`，若缺失则取 `do_info[0].do_status_text`。 |
| `is_delivered` | `status.lower() == "delivered"`。 |

注意：

- 脚本未知市场时会默认使用 `VN` 域名；如果订单 prefix 和 trace ID 都无法识别，必须在报告中标为风险或 UNKNOWN。
- `generate_jwt.py` 会直接打印 token，仅用于本地调试；不要把 token 粘贴到用户回复或共享文档。

## 7. 报告格式

生成 CSV：

```text
daily_reconciliation_<DATE>.csv
```

列定义：

| 列 | 说明 |
| --- | --- |
| `OrderID` | shipment/order ID。 |
| `TraceID` | 首轮日志 trace ID。 |
| `Market` | 订单市场。 |
| `DeliveryStatus` | delivery-domain 状态。 |
| `ReconciliationStatus` | `Fully Matched` / `Not Matched` / `NotDelivered` / `UNKNOWN`。 |
| `UnmatchedContent` | comparison 日志中的 unmatched 内容或缺失说明。 |

聊天摘要：

```markdown
**Reconciliation Report (<DATE>)**

| Metric | Count |
| --- | --- |
| Total Orders Checked | <total> |
| Delivered | <count> |
| Pending/Other | <count> |
| Fully Matched | <count> |
| Not Matched | <count> |
| UNKNOWN | <count> |

**Market Breakdown**
| Market | Checked | Delivered | Not Matched | UNKNOWN |
| --- | --- | --- | --- | --- |
| ID | <n> | <n> | <n> | <n> |

**Unmatched Details (Top 5)**
| OrderID | Market | Reason |
| --- | --- | --- |
| <order> | <market> | <diff> |
```

必须说明：

- 实际查询时间范围、市场和 app/query 策略。
- 每个市场实际采样数量；不足 10 个时说明不足原因。
- CSV 文件路径。
- 所有 API 或日志查询失败的摘要。

## 8. 异常处理

- `live-uat-log-mcp/search_logs` 无结果：报告时间范围、市场、app 和 query，停止该市场或降级到 fallback app。
- 状态脚本缺少 `requests`：执行 `pip install requests` 后重试。
- API 非 200 或响应格式异常：保留订单、market、trace ID 和错误摘要，结论不要判 PASS。
- trace ID 缺失：可查询状态，但 comparison 结论为 `UNKNOWN`。
- 市场无法识别：不要静默按 VN 通过；在报告中标出并人工复核。
- 对账结论有冲突时，以 delivery-domain 状态和同 trace comparison 证据为准。
