---
name: go-refactor-consistency-review
description: Review Go refactor before/after code for business behavior parity. Use when Codex is asked to compare refactored Go functions, methods, files, commits, diffs, or snippets for "重构一致性", "重构代码对比", "行为是否一致", "refactor consistency", or "before/after Go code behavior review".
---

# Go Refactor Consistency Review

## Goal

Compare "before refactor" and "after refactor" Go code and judge whether the refactor preserves business behavior. Focus on behavior, edge cases, side effects, and exceptional paths, not style or structure.

Each invocation is a fresh analysis. Do not reuse prior conclusions. Generate new request metadata for every review:

- `RUN_ID`: random UUID
- `CACHE_BUST`: current execution timestamp
- `CACHE_POLICY`: `do_not_use_prompt_cache`
- `REQUEST_ID`: random UUID

Use `scripts/build_prompt.py` when a ready-to-fill prompt skeleton is helpful.

## Workflow

1. Establish the exact before/after code under review.
   - If the user provides code snippets, use them directly.
   - If the user provides file paths, diffs, commits, or function names, inspect the repository with `rg`, `git show`, `git diff`, `go test`, or other local tools as needed.
   - If only a function name is provided and either side cannot be resolved, ask for the missing code or mark the affected conclusion as `不确定`.

2. Build a behavior inventory for both versions.
   - Function signature, exported contract, input/output shape.
   - Nil, empty slice, empty map, zero value, missing field, and boundary inputs.
   - Condition branches, loops, filtering, sorting, grouping, aggregation, state mutation.
   - Error returns, wrapped errors, fallback, retry, degrade, panic/recover.
   - DB writes, RPC/HTTP calls, MQ/event sends, cache writes, logs, metrics, traces.
   - Goroutines, context cancellation/timeout, channels, locks, shared state.

3. Compare behavior dimension by dimension.
   - Treat behavior as inconsistent unless there is evidence that the two paths are equivalent.
   - Mark unknowns as `不确定`; do not assume equivalence.
   - Mark as high risk when refactored code removes or weakens error handling, boundary handling, nil handling, side effects, locking, context propagation, retry/fallback, or observability that may affect production behavior.
   - Cite file paths and line numbers when reviewing local files.

4. Recommend tests.
   - Give must-have Go table-driven cases, not vague test themes.
   - Include normal path, boundary path, nil/empty path, error path, side-effect path, and concurrency/context path when applicable.
   - Mark high-risk cases explicitly.

## Output Format

Always output in Chinese with this structure:

```markdown
## 结论

- 一致性判断：一致 / 基本一致 / 存在风险 / 不一致
- 风险等级：低 / 中 / 高
- 是否建议合入：是 / 否 / 需要补充测试后合入

## 差异分析表

| 维度 | 重构前行为 | 重构后行为 | 是否一致 | 风险说明 |
|---|---|---|---|---|
| 功能行为一致性 |  |  |  |  |
| 业务逻辑一致性 |  |  |  |  |
| 副作用一致性 |  |  |  |  |
| 并发与上下文一致性 |  |  |  |  |
| 错误与异常路径 |  |  |  |  |

## 潜在不一致点

逐条列出潜在行为差异，并说明触发条件。

## 必补测试用例

用 Go table-driven test 风格描述测试用例。

## 最终建议

给出明确的工程判断。
```

## Judgment Rules

- `一致`: Evidence shows all relevant behavior, side effects, error paths, and edge cases are equivalent.
- `基本一致`: Main behavior is equivalent, with minor non-business differences or low-risk observability differences.
- `存在风险`: Main path appears equivalent, but edge cases, side effects, or missing evidence could change behavior.
- `不一致`: Clear behavior difference exists.

Default to `需要补充测试后合入` when any high-risk path is untested or uncertain.
