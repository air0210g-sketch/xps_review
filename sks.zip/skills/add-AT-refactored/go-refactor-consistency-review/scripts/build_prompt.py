#!/usr/bin/env python3
"""Generate a fresh Go refactor consistency review prompt skeleton."""

from __future__ import annotations

import argparse
import time
import uuid


PROMPT_BODY = """RUN_ID: {run_id}
CACHE_BUST: {cache_bust}
CACHE_POLICY: do_not_use_prompt_cache
REQUEST_ID: {request_id}

你是 Go 代码重构一致性审查专家。

你的任务是对比“重构前代码”和“重构后代码”，判断重构后的代码是否保持了重构前的业务行为一致性。

请严格从以下维度分析：

1. 功能行为一致性
   - 输入输出是否保持一致
   - 边界条件是否保持一致
   - 错误处理是否保持一致
   - nil、空 slice、空 map、零值处理是否一致

2. 业务逻辑一致性
   - 条件分支是否等价
   - 循环逻辑是否等价
   - 状态变更是否等价
   - 数据过滤、排序、聚合逻辑是否一致

3. 副作用一致性
   - DB 写入是否一致
   - RPC / HTTP 调用是否一致
   - MQ / Event 发送是否一致
   - 日志、metrics、trace 是否有行为差异

4. 并发与上下文一致性
   - goroutine 生命周期是否一致
   - context cancel / timeout 是否一致
   - channel 读写是否一致
   - lock / mutex 使用是否存在差异

5. 错误与异常路径
   - error 返回是否一致
   - panic / recover 行为是否一致
   - fallback / retry / degrade 逻辑是否一致

6. 测试建议
   - 给出必须补充的单元测试 case
   - 给出表驱动测试建议
   - 标记高风险 case

请按以下格式输出：

## 结论

- 一致性判断：一致 / 基本一致 / 存在风险 / 不一致
- 风险等级：低 / 中 / 高
- 是否建议合入：是 / 否 / 需要补充测试后合入

## 差异分析表

| 维度 | 重构前行为 | 重构后行为 | 是否一致 | 风险说明 |
|---|---|---|---|---|

## 潜在不一致点

逐条列出潜在行为差异，并说明触发条件。

## 必补测试用例

用 Go table-driven test 风格描述测试用例。

## 最终建议

给出明确的工程判断。

注意：
- 不要只比较代码结构，要重点判断行为是否等价。
- 如果无法确认，请明确标记“不确定”，不要假设一致。
- 如果发现重构后减少了错误处理、边界处理或副作用，请标记为高风险。
- 本次请求必须视为全新分析，不得复用历史分析结论。

下面是重构前代码：
{before_label}

下面是重构后代码：
{after_label}
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a fresh prompt skeleton for Go refactor consistency review."
    )
    parser.add_argument("--before", default="我手动输入函数名", help="Before-refactor code, function name, file path, or label.")
    parser.add_argument("--after", default="我手动输入函数名", help="After-refactor code, function name, file path, or label.")
    parser.add_argument("--millis", action="store_true", help="Use millisecond timestamp for CACHE_BUST.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cache_bust = int(time.time() * 1000) if args.millis else int(time.time())
    print(
        PROMPT_BODY.format(
            run_id=uuid.uuid4(),
            cache_bust=cache_bust,
            request_id=uuid.uuid4(),
            before_label=args.before,
            after_label=args.after,
        )
    )


if __name__ == "__main__":
    main()
