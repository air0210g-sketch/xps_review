#!/usr/bin/env python3
import argparse
import base64
import hashlib
import hmac
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request


DEFAULT_SECRET = "ab39d18c43949bc9f6da7f7569541474"
ACCOUNT = "export_platform"
API_PATH = "/spx_delivery/openapi/delivery_domain/order_info/query"

MARKET_HOSTS = {
    "id": "http://spx-delivery-service.ssc.shopee.co.id",
    "my": "http://spx-delivery-service.ssc.shopee.com.my",
    "th": "http://spx-delivery-service.ssc.shopee.co.th",
    "ph": "http://spx-delivery-service.ssc.shopee.ph",
    "sg": "http://spx-delivery-service.ssc.shopee.sg",
    "br": "http://spx-delivery-service.ssc.shopee.com.br",
    "vn": "http://spx-delivery-service.ssc.shopee.vn",
}

ORDER_MARKET_PREFIXES = {
    "SPXID": "id",
    "ID": "id",
    "SPXMY": "my",
    "MY": "my",
    "SPXTH": "th",
    "TH": "th",
    "SPXPH": "ph",
    "PH": "ph",
    "SPXSG": "sg",
    "SG": "sg",
    "SPXBR": "br",
    "BR": "br",
    "SPXVN": "vn",
    "VN": "vn",
}


def b64url(raw):
    if isinstance(raw, str):
        raw = raw.encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=")


def make_jwt(shipment_id, secret):
    header = {"typ": "JWT", "alg": "HS256", "account": ACCOUNT}
    payload = {"data": {"shipment_id": shipment_id}, "timestamp": int(time.time())}
    encoded_header = b64url(json.dumps(header, separators=(",", ":")))
    encoded_payload = b64url(json.dumps(payload, separators=(",", ":")))
    signing_input = encoded_header + b"." + encoded_payload
    signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return (signing_input + b"." + b64url(signature)).decode("utf-8")


def infer_market(order_id, trace_id="", explicit_market=""):
    if explicit_market:
        return explicit_market.lower()

    trace_match = re.search(r"SPX-DELIVERY-live-([a-z]{2})", trace_id, re.IGNORECASE)
    if trace_match:
        return trace_match.group(1).lower()

    upper_order = order_id.upper()
    for prefix, market in ORDER_MARKET_PREFIXES.items():
        if upper_order.startswith(prefix):
            return market
    return ""


def extract_trace_id(line):
    match = re.search(r"\b(SPX-DELIVERY-live-[^|,\s]+)", line, re.IGNORECASE)
    return match.group(1) if match else ""


def extract_market_from_log(line, order_id, trace_id):
    market_match = re.search(r"\bmarket:\s*([A-Z]{2})\b", line, re.IGNORECASE)
    if market_match:
        return market_match.group(1).lower()
    return infer_market(order_id, trace_id)


def parse_log_lines(lines):
    rows = []
    seen = set()
    for line in lines:
        if "AddOrderToATGrayscale" not in line:
            continue
        order_match = re.search(r"\borderID:\s*([A-Z0-9]+)\b", line, re.IGNORECASE)
        if not order_match:
            continue
        order_id = order_match.group(1).upper()
        trace_id = extract_trace_id(line)
        market = extract_market_from_log(line, order_id, trace_id)
        key = (market, order_id)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"market": market, "order_id": order_id, "trace_id": trace_id})
    return rows


def load_log_rows(paths, use_stdin):
    rows = []
    for path in paths:
        with open(path, "r", encoding="utf-8") as handle:
            rows.extend(parse_log_lines(handle))
    if use_stdin:
        rows.extend(parse_log_lines(sys.stdin))
    return rows


def normalize_manual_orders(orders, market):
    rows = []
    seen = set()
    for order_id in orders:
        normalized = order_id.strip().upper()
        if not normalized:
            continue
        row_market = infer_market(normalized, explicit_market=market)
        key = (row_market, normalized)
        if key in seen:
            continue
        seen.add(key)
        rows.append({"market": row_market, "order_id": normalized, "trace_id": ""})
    return rows


def parse_status(response_json):
    data = response_json.get("data") if isinstance(response_json, dict) else {}
    if not isinstance(data, dict):
        data = {}

    do_statuses = []
    do_info = data.get("do_info")
    if isinstance(do_info, list):
        for item in do_info:
            if isinstance(item, dict) and item.get("do_status_text"):
                do_statuses.append(str(item.get("do_status_text")))

    return {
        "do_status_text": ",".join(do_statuses) if do_statuses else "",
        "lmo_status_text": str(data.get("lmo_status_text") or ""),
    }


def query_order(row, secret, timeout):
    market = row["market"]
    order_id = row["order_id"]
    if market not in MARKET_HOSTS:
        return {
            **row,
            "http_status": "",
            "do_status_text": "",
            "lmo_status_text": "",
            "error": "unknown market",
        }

    url = MARKET_HOSTS[market] + API_PATH
    token = make_jwt(order_id, secret)
    body = json.dumps({"jwt": token}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw) if raw else {}
            statuses = parse_status(parsed)
            return {
                **row,
                "http_status": str(resp.status),
                "do_status_text": statuses["do_status_text"],
                "lmo_status_text": statuses["lmo_status_text"],
                "error": "",
            }
    except urllib.error.HTTPError as err:
        raw = err.read().decode("utf-8", errors="replace")
        return {
            **row,
            "http_status": str(err.code),
            "do_status_text": "",
            "lmo_status_text": "",
            "error": raw[:300],
        }
    except Exception as err:
        return {
            **row,
            "http_status": "",
            "do_status_text": "",
            "lmo_status_text": "",
            "error": str(err),
        }


def print_markdown(rows):
    headers = ["market", "order_id", "do_status_text", "lmo_status_text", "http_status", "trace_id", "error"]
    print("| " + " | ".join(headers) + " |")
    print("| " + " | ".join(["---"] * len(headers)) + " |")
    for row in rows:
        values = [str(row.get(header, "")).replace("|", "\\|") for header in headers]
        print("| " + " | ".join(values) + " |")


def print_tsv(rows):
    headers = ["market", "order_id", "do_status_text", "lmo_status_text", "http_status", "trace_id", "error"]
    print("\t".join(headers))
    for row in rows:
        print("\t".join(str(row.get(header, "")).replace("\t", " ") for header in headers))


def main():
    parser = argparse.ArgumentParser(description="Query delivery-domain order status for AddOrderToATGrayscale logs.")
    parser.add_argument("orders", nargs="*", help="Order IDs to query when not using --log-file/--stdin-logs.")
    parser.add_argument("--log-file", action="append", default=[], help="File containing raw AddOrderToATGrayscale logs.")
    parser.add_argument("--stdin-logs", action="store_true", help="Read raw logs from stdin.")
    parser.add_argument("--market", choices=sorted(MARKET_HOSTS), help="Market for manually supplied order IDs.")
    parser.add_argument("--format", choices=["markdown", "json", "tsv"], default="markdown")
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument("--dry-run", action="store_true", help="Only parse/deduplicate orders; do not call the API.")
    parser.add_argument("--secret", help="JWT secret. Defaults to SPX_EXPORT_PLATFORM_JWT_SECRET or the configured default.")
    args = parser.parse_args()

    rows = []
    rows.extend(load_log_rows(args.log_file, args.stdin_logs))
    rows.extend(normalize_manual_orders(args.orders, args.market or ""))

    deduped = []
    seen = set()
    for row in rows:
        key = (row.get("market", ""), row.get("order_id", ""))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    if args.dry_run:
        results = [{**row, "http_status": "", "do_status_text": "", "lmo_status_text": "", "error": ""} for row in deduped]
    else:
        secret = args.secret or os.environ.get("SPX_EXPORT_PLATFORM_JWT_SECRET") or DEFAULT_SECRET
        results = [query_order(row, secret, args.timeout) for row in deduped]

    if args.format == "json":
        print(json.dumps(results, ensure_ascii=False, indent=2))
    elif args.format == "tsv":
        print_tsv(results)
    else:
        print_markdown(results)


if __name__ == "__main__":
    main()
