---
name: add-order-refactor-check
description: Use when checking AddOrderToATGrayscale, add order refactor/refractor, assignment task grayscale, or live SPX order status validation from delivery logs.
---

# Add Order Refactor Check

## 背景

本 skill 用于验证 `[AddOrderToATGrayscale]` 在 live 环境各市场的真实命中情况：先从日志中找到 hit grayscale 的 shipment，再查询 delivery-domain 订单状态，确认命中灰度的订单是否已经 delivered。

| 项目 | 内容 |
| --- | --- |
| 方法 | 按市场查询 live 日志，提取 `orderID`、market、trace ID，去重后调用 delivery-domain order info 接口。 |
| 落地要求 | 日志命中不能直接视为验证通过，必须用订单状态接口确认 `do_status_text` / `lmo_status_text`。 |
| 交付产出 | 输出订单状态表，标出未 delivered、未知市场、HTTP/API 失败或无法解析的样本。 |

## 0. Skill 使用方式

### 文件组成

| 文件 | 用途 |
| --- | --- |
| `SKILL.md` | 定义适用场景、输入、日志查询、状态查询、输出和安全要求。 |
| `scripts/query_order_status.py` | 从日志或手动订单号中解析 shipment，并查询 delivery-domain 订单状态。 |

### 使用实操

用户可直接点名 skill：

```text
使用 add-order-refactor-check，检查今天 AddOrderToATGrayscale 命中灰度的订单状态。
```

常用输入格式：

```text
环境：live
市场：id,my,th,ph,sg,br,vn
时间范围：2026-05-15 00:00:00+08:00 到现在
要求：每个市场找 hit grayscale 日志，查询订单状态并输出未 delivered 的订单。
```

如果用户只给订单号：

```bash
python3 ~/.codex/skills/add-order-refactor-check/scripts/query_order_status.py \
  --market my SPXMY067313879384
```

如果用户给原始日志文件：

```bash
python3 ~/.codex/skills/add-order-refactor-check/scripts/query_order_status.py \
  --log-file /tmp/add_order_grayscale_logs.txt \
  --format markdown
```

### 输出判定

| 结论 | 判定 |
| --- | --- |
| PASS | 已查到订单，接口成功返回，且 `do_status_text` 为 `delivered`。 |
| RISK | `do_status_text` 不是 `delivered`，或 HTTP/API 返回异常。 |
| UNKNOWN | 无日志、无法解析 order ID / market、未知市场，或用户输入材料不足。 |

## 1. 核心目标

- 覆盖 live 环境 `id`、`my`、`th`、`ph`、`sg`、`br`、`vn`。
- 找到 `[AddOrderToATGrayscale]` 的 hit grayscale 订单样本。
- 用 delivery-domain order info 接口确认订单状态，而不是只看日志文本。
- 给出可追溯的 `market`、`order_id`、`trace_id`、HTTP 状态和错误说明。

## 2. 执行原则

| 原则 | 要求 |
| --- | --- |
| 时间明确 | 用户未提供时间范围时，默认查今天 `00:00:00` 到当前时间，时区 `+08:00`。 |
| 市场隔离 | 每个市场单独查日志，避免一个市场日志覆盖其他市场样本。 |
| 证据闭环 | 每个订单至少保留日志 trace ID 和状态接口结果。 |
| 去重优先 | 按 `(market, order_id)` 去重，保留最早日志时间和 trace ID。 |
| 安全输出 | 不在用户可见回复中打印 JWT、secret 或完整敏感 token。 |

## 3. 必填输入

| 输入 | 要求 |
| --- | --- |
| 环境 | 只支持 `live`。 |
| 时间范围 | 可由用户提供；未提供时使用当天 `00:00:00+08:00` 到现在。 |
| 市场 | 默认 `id,my,th,ph,sg,br,vn`，可由用户缩小范围。 |
| 日志关键词 | 默认 `"[AddOrderToATGrayscale]"`，必须进一步筛选 `hit grayscale`。 |
| 订单来源 | 可来自日志，也可由用户手动提供 order ID。 |

## 4. 执行流程

| 步骤 | 动作 | 结果 |
| --- | --- | --- |
| 1. 准备范围 | 明确时间、市场、环境和默认 app。 | 查询计划。 |
| 2. 查询日志 | 对每个市场调用 `live-uat-log-mcp/search_logs`。 | 原始日志样本。 |
| 3. 筛选命中 | 只保留包含 `hit grayscale` 的日志。 | 命中灰度日志。 |
| 4. 提取字段 | 解析 `orderID`、market、trace ID。 | 订单候选表。 |
| 5. 去重 | 按 `(market, order_id)` 去重。 | 待查询订单表。 |
| 6. 查状态 | 用脚本或接口查询 delivery-domain order info。 | 订单状态结果。 |
| 7. 输出结论 | 汇总状态表并标出非 delivered 或异常订单。 | Markdown 报告。 |

## 5. 日志查询规则

默认 app：

```text
shopee.supply_chain.spx.delivery.deliveryapi
```

按市场使用 PQL：

```text
"AddOrderToATGrayscale" AND "SPX-DELIVERY-live-<market>"
```

处理要求：

- 用 `next_cursor` 翻页，直到结果耗尽或样本足够。
- 如果全日查询超时，拆成 1-2 小时窗口重试。
- 只保留日志消息包含 `hit grayscale` 的记录。

字段解析：

| 字段 | 规则 |
| --- | --- |
| `order_id` | `orderID:\s*([A-Z0-9]+)` |
| `market` | 优先 `market:\s*([A-Z]{2})`，其次 trace ID `SPX-DELIVERY-live-<market>`，再用 shipment prefix 推断。 |
| `trace_id` | 从日志中提取包含 `SPX-DELIVERY-live-...` 的字段。 |

## 6. 状态查询

优先使用脚本：

```bash
python3 ~/.codex/skills/add-order-refactor-check/scripts/query_order_status.py \
  --log-file /tmp/add_order_grayscale_logs.txt \
  --format markdown
```

脚本支持：

| 参数 | 用途 |
| --- | --- |
| `--log-file <path>` | 从原始 AddOrderToATGrayscale 日志文件解析订单，可重复传入。 |
| `--stdin-logs` | 从 stdin 读取原始日志。 |
| `--market <market>` | 手动订单号无法从 prefix 推断时指定市场。 |
| `--format markdown,json,tsv` | 输出格式，默认 `markdown`。 |
| `--dry-run` | 只解析和去重，不调用接口。 |
| `--secret <secret>` | 覆盖 JWT secret；默认读 `SPX_EXPORT_PLATFORM_JWT_SECRET` 或脚本内默认值。 |

接口路径：

```text
/spx_delivery/openapi/delivery_domain/order_info/query
```

Market hosts:

| market | host |
| --- | --- |
| id | `http://spx-delivery-service.ssc.shopee.co.id` |
| my | `http://spx-delivery-service.ssc.shopee.com.my` |
| th | `http://spx-delivery-service.ssc.shopee.co.th` |
| ph | `http://spx-delivery-service.ssc.shopee.ph` |
| sg | `http://spx-delivery-service.ssc.shopee.sg` |
| br | `http://spx-delivery-service.ssc.shopee.com.br` |
| vn | `http://spx-delivery-service.ssc.shopee.vn` |

请求体：

```json
{"jwt":"<signed token>"}
```

JWT payload：

```json
{"data":{"shipment_id":"<order_id>"},"timestamp":<unix_seconds>}
```

JWT header 使用 `typ=JWT`、`alg=HS256`、`account=export_platform`。

## 7. 输出要求

返回 Markdown 表：

| 字段 | 说明 |
| --- | --- |
| `market` | 小写市场，如 `my`。 |
| `order_id` | 归一化后的 shipment ID。 |
| `do_status_text` | delivery order status，重点检查是否为 `delivered`。 |
| `lmo_status_text` | LMO 状态文本。 |
| `http_status` | 状态查询 HTTP code。 |
| `trace_id` | 对应日志 trace ID。 |
| `error` | API、解析或未知市场错误。 |

必须额外说明：

- 查询时间范围、市场、app 和 PQL。
- 未 delivered 的订单列表。
- HTTP/API 失败的 host 和错误摘要。
- 如果无日志，说明实际查过的时间范围、市场、app 和 query pattern。

## 8. 安全与异常处理

- 不要在用户回复中打印 signed JWT、secret 或完整请求 body。
- 如果 `sg`、`th`、`ph` API 请求失败，报告 host 并请用户确认市场域名后再重试。
- 如果 market 无法推断，输出 `UNKNOWN`，不要默认猜测市场后继续调用。
- 如果日志解析和接口结果冲突，以接口结果为准，并保留日志 trace ID 方便复核。
