#!/usr/bin/env python3
"""扫描 Go 仓库中固定最大循环次数静默触顶风险。"""

from __future__ import annotations

import argparse
import html
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


FOR_RE = re.compile(
    r"^(?P<indent>\s*)for\s+"
    r"(?P<init>[^;\n{}]*?)\s*;\s*"
    r"(?P<cond>[^;\n{}]*?)\s*;\s*"
    r"(?P<post>[^\n{}]*?)\s*\{"
)
FUNC_RE = re.compile(r"^\s*func\s+(?:\([^)]+\)\s*)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\(")

SIGNAL_RE = re.compile(
    r"(reach(?:ed)?\s+(?:max|limit)|max\s+(?:loop|iterations|request|pages)|"
    r"exceed(?:ed)?|safe_loop|NewSafeLoop|AwesomeReportEvent|ReportEvent|"
    r"NotifySeatalk|CtxLogErrorf|LogErrorf|return\s+.*err|return\s+errors?\.)",
    re.IGNORECASE,
)
MAX_WORD_RE = re.compile(r"(max|limit|loop|maxloop|max_loop|maxiterations|max_iter|retry|times|page|pages)", re.IGNORECASE)
ACTION_RE = re.compile(
    r"(update|delete|del|push|sync|callback|accept|decline|finance|fee|status|"
    r"process|batch|cron|job|task|cleanup|backfill|notify|callup|call_up)",
    re.IGNORECASE,
)
SHARD_RE = re.compile(r"(shard|sharding|tableIndex|shardingIndex|tabIndex|handler tab|table shard)", re.IGNORECASE)


@dataclass
class Finding:
    priority: str
    path: Path
    line: int
    func_name: str
    loop_line: str
    loop_var: str
    max_expr: str
    reason: str
    diff: str
    fix_note: str


def iter_go_files(repo: Path, include_tests: bool) -> Iterable[Path]:
    skip_dirs = {".git", "vendor", "node_modules", ".idea", ".vscode", "tmp", "dist", "build"}
    for root, dirs, files in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".cache")]
        for name in files:
            if not name.endswith(".go"):
                continue
            if not include_tests and name.endswith("_test.go"):
                continue
            yield Path(root) / name


def find_matching_brace(lines: list[str], start_idx: int) -> int | None:
    depth = 0
    seen_open = False
    in_block_comment = False
    for idx in range(start_idx, len(lines)):
        line = lines[idx]
        j = 0
        in_string: str | None = None
        while j < len(line):
            ch = line[j]
            nxt = line[j + 1] if j + 1 < len(line) else ""
            if in_block_comment:
                if ch == "*" and nxt == "/":
                    in_block_comment = False
                    j += 2
                    continue
                j += 1
                continue
            if in_string:
                if ch == "\\" and in_string != "`":
                    j += 2
                    continue
                if ch == in_string:
                    in_string = None
                j += 1
                continue
            if ch == "/" and nxt == "/":
                break
            if ch == "/" and nxt == "*":
                in_block_comment = True
                j += 2
                continue
            if ch in ('"', "'", "`"):
                in_string = ch
                j += 1
                continue
            if ch == "{":
                depth += 1
                seen_open = True
            elif ch == "}":
                depth -= 1
                if seen_open and depth == 0:
                    return idx
            j += 1
    return None


def parse_loop(init: str, cond: str, min_literal_cap: int) -> tuple[str, str] | None:
    init_match = re.search(r"(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*:?=", init)
    loop_var = init_match.group("var") if init_match else ""
    if "range " in init or "range " in cond:
        return None
    if "||" in cond and not MAX_WORD_RE.search(cond):
        return None

    patterns = [
        r"(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*<={0,1}\s*(?P<max>[^&|]+)$",
        r"(?P<max>[^&|]+)\s*>\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)$",
    ]
    for pattern in patterns:
        match = re.search(pattern, cond.strip())
        if not match:
            continue
        var = match.group("var").strip()
        max_expr = match.group("max").strip()
        if loop_var and var != loop_var:
            continue
        if re.fullmatch(r"\d+", max_expr) and int(max_expr) < min_literal_cap:
            return None
        if re.fullmatch(r"\d+", max_expr) or MAX_WORD_RE.search(max_expr):
            return var, max_expr
    return None


def current_func(lines: list[str], line_idx: int) -> str:
    for idx in range(line_idx, max(-1, line_idx - 250), -1):
        match = FUNC_RE.match(lines[idx])
        if match:
            return match.group("name")
    return ""


def has_cap_signal(body: str, after: str) -> bool:
    combined = "\n".join([body[-3000:], after])
    if SIGNAL_RE.search(after) and re.search(r"(max|limit|exceed|reach|SafeLoop|err|ReportEvent|NotifySeatalk)", after, re.IGNORECASE):
        return True
    if re.search(r"reach\s+max|maxLoop|max_loop|max loop|exceed", combined, re.IGNORECASE):
        return True
    return False


def is_probable_shard_loop(loop_line: str, body: str, func_name: str) -> bool:
    text = "\n".join([loop_line, body[:1600], func_name])
    if SHARD_RE.search(text):
        return True
    if re.search(r"for\s+\w+\s*:=\s*0\s*;\s*\w+\s*<\s*1000\s*;", loop_line) and re.search(
        r"(table|tab|shard|分表|handler tab)", text, re.IGNORECASE
    ):
        return True
    return False


def priority_for(rel_path: str, func_name: str, body: str, max_expr: str) -> str:
    text = " ".join([rel_path, func_name, body[:2400], max_expr]).lower()
    if any(k in text for k in ["call_up", "callup", "accept", "callback", "finance", "push", "fee", "status"]):
        return "P1" if any(k in text for k in ["accept", "callback", "finance", "push"]) else "P2"
    if any(k in text for k in ["cron", "job", "task", "sync", "update", "batch", "process"]):
        return "P2"
    return "P3"


def make_reason(func_name: str, max_expr: str, body: str, after: str) -> str:
    end_hint = "循环后未发现 reach/max/exceed 相关错误日志、监控上报或返回错误。"
    if "break" in body:
        end_hint = "循环内存在正常 break 条件，但跑满上限后未发现明确的触顶信号。"
    if "return nil" in after[:500]:
        end_hint += " 外层可能仍返回 nil，调度侧容易误判成功。"
    if is_hardcoded_cap(max_expr):
        end_hint += " 最大循环次数是写死数字，建议改为 Apollo 配置。"
    return f"`{func_name or 'anonymous'}` 使用固定上限 `{max_expr}` 控制循环；{end_hint}"


def is_hardcoded_cap(max_expr: str) -> bool:
    return re.fullmatch(r"\d+", max_expr.strip()) is not None


def camel_name(name: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", name or "Job")
    return "".join(part[:1].upper() + part[1:] for part in parts) or "Job"


def apollo_key_name(func_name: str) -> str:
    words = re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)|\d+", func_name or "job")
    key = ".".join(word.lower() for word in words) or "job"
    return f"{key}.max_loop"


def make_diff(loop_line: str, loop_var: str, max_expr: str, func_name: str) -> str:
    if is_hardcoded_cap(max_expr):
        getter = f"util.Get{camel_name(func_name)}MaxLoop(ctx)"
        apollo_key = apollo_key_name(func_name)
        return f"""// import "git.garena.com/shopee/bg-logistics/spx/delivery/lm-route-common/libs/safe_loop"
+ // Apollo key 示例: {apollo_key}，默认值保持原硬编码值 {max_expr}
+ maxLoop := {getter}
- {loop_line.strip()}
+ sl := safe_loop.NewSafeLoop(ctx, maxLoop)
+ for sl.Next() {{
      // existing loop body
  }}
+ if sl.GetCurrentIterations() > maxLoop {{
+     logger.CtxLogErrorf(ctx, "{func_name or 'job'} reach max loop, max_loop=%d", maxLoop)
+     return errors.Errorf("{func_name or 'job'} reach max loop, max_loop=%d", maxLoop)
+ }}"""
    return f"""// import "git.garena.com/shopee/bg-logistics/spx/delivery/lm-route-common/libs/safe_loop"
- {loop_line.strip()}
+ sl := safe_loop.NewSafeLoop(ctx, int({max_expr}))
+ for sl.Next() {{
      // existing loop body
  }}
+ if sl.GetCurrentIterations() > int({max_expr}) {{
+     logger.CtxLogErrorf(ctx, "{func_name or 'job'} reach max loop, max_loop=%v", {max_expr})
+     return errors.Errorf("{func_name or 'job'} reach max loop, max_loop=%v", {max_expr})
+ }}"""


def make_fix_note(priority: str, max_expr: str) -> str:
    if is_hardcoded_cap(max_expr):
        return "当前最大循环次数是硬编码数字，建议先抽成 Apollo 配置并保留原值作为默认值，再用 SafeLoop 控制循环；关键任务触顶时返回 error，避免调度侧误判成功。"
    if priority == "P1":
        return "关键业务链路建议使用 SafeLoop 后继续显式返回 error，并在日志里带 last_id/page/status/table 等游标信息，避免 job 绿着失败。"
    if priority == "P2":
        return "建议改成 SafeLoop，并在触顶时至少 Errorf + monitor event；如果上游调度需要感知未处理完，应返回 error。"
    return "低风险清理/补偿任务可先补触顶 Errorf/monitor；确认触顶不影响业务后再决定是否返回 error。"


def scan_file(path: Path, repo: Path, min_literal_cap: int) -> list[Finding]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []

    findings: list[Finding] = []
    rel_path = str(path.relative_to(repo))
    for idx, line in enumerate(lines):
        match = FOR_RE.match(line)
        if not match:
            continue
        parsed = parse_loop(match.group("init"), match.group("cond"), min_literal_cap)
        if not parsed:
            continue
        loop_var, max_expr = parsed
        end_idx = find_matching_brace(lines, idx)
        if end_idx is None:
            continue
        body = "\n".join(lines[idx + 1 : end_idx])
        after = "\n".join(lines[end_idx + 1 : min(len(lines), end_idx + 12)])
        func_name = current_func(lines, idx)
        if is_probable_shard_loop(line, body, func_name):
            continue
        if has_cap_signal(body, after):
            continue
        priority = priority_for(rel_path, func_name, body, max_expr)
        findings.append(
            Finding(
                priority=priority,
                path=path,
                line=idx + 1,
                func_name=func_name,
                loop_line=line,
                loop_var=loop_var,
                max_expr=max_expr,
                reason=make_reason(func_name, max_expr, body, after),
                diff=make_diff(line, loop_var, max_expr, func_name),
                fix_note=make_fix_note(priority, max_expr),
            )
        )
    return findings


def render_html(repo: Path, findings: list[Finding]) -> str:
    rows = []
    priority_order = {"P1": 0, "P2": 1, "P3": 2}
    findings = sorted(findings, key=lambda f: (priority_order.get(f.priority, 9), str(f.path), f.line))
    for item in findings:
        rel = item.path.relative_to(repo)
        file_line = f"{rel}:{item.line}"
        rows.append(
            "<tr>"
            f"<td><span class='prio {html.escape(item.priority)}'>{html.escape(item.priority)}</span></td>"
            f"<td><code>{html.escape(file_line)}</code></td>"
            f"<td>{html.escape(item.reason)}</td>"
            f"<td><pre>{html.escape(item.diff)}</pre></td>"
            f"<td>{html.escape(item.fix_note)}</td>"
            "</tr>"
        )

    empty = ""
    if not rows:
        empty = "<p class='empty'>未发现明显的固定最大循环次数静默触顶风险。仍建议人工检查复杂循环和动态配置上限。</p>"

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>最大循环次数静默触顶扫描报告</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 24px; color: #172033; background: #f7f8fb; }}
    h1 {{ font-size: 24px; margin: 0 0 8px; }}
    .meta {{ color: #566173; margin-bottom: 18px; }}
    table {{ width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #d9dee8; }}
    th, td {{ border: 1px solid #d9dee8; padding: 10px 12px; vertical-align: top; font-size: 13px; line-height: 1.45; }}
    th {{ background: #eef2f7; text-align: left; white-space: nowrap; }}
    code {{ font-family: Menlo, Monaco, Consolas, monospace; font-size: 12px; }}
    pre {{ margin: 0; white-space: pre-wrap; word-break: break-word; font-family: Menlo, Monaco, Consolas, monospace; font-size: 12px; }}
    .prio {{ display: inline-block; min-width: 32px; text-align: center; border-radius: 4px; padding: 2px 6px; font-weight: 700; }}
    .P1 {{ background: #ffe1df; color: #a62018; }}
    .P2 {{ background: #fff1c7; color: #845300; }}
    .P3 {{ background: #dff3e7; color: #126b3a; }}
    .empty {{ background: #fff; border: 1px solid #d9dee8; padding: 14px; }}
  </style>
</head>
<body>
  <h1>最大循环次数静默触顶扫描报告</h1>
  <div class="meta">仓库: <code>{html.escape(str(repo))}</code> · 候选风险: {len(findings)}</div>
  {empty}
  <table>
    <thead>
      <tr>
        <th>优先级 如P1/P2/P3</th>
        <th>代码所在文件和行数</th>
        <th>说明</th>
        <th>可参考的修改diff</th>
        <th>修改的解释说明</th>
      </tr>
    </thead>
    <tbody>
      {"".join(rows)}
    </tbody>
  </table>
</body>
</html>
"""


def open_report(path: Path) -> None:
    commands = [
        ["open", str(path)],
        ["open", "-a", "Google Chrome", str(path)],
        ["open", "-a", "Safari", str(path)],
    ]
    last_error = ""
    for command in commands:
        try:
            result = subprocess.run(command, check=False, capture_output=True, text=True)
        except OSError as exc:
            last_error = str(exc)
            continue
        if result.returncode == 0:
            print(f"已打开报告，命令: {' '.join(command)}")
            return
        last_error = (result.stderr or result.stdout or "").strip()
    if last_error:
        print(f"无法自动打开报告: {last_error}")


def main() -> int:
    parser = argparse.ArgumentParser(description="扫描 Go 仓库中固定最大循环次数静默触顶风险。")
    parser.add_argument("--repo", default=".", help="要扫描的仓库根目录。")
    parser.add_argument("--out", default="", help="输出 HTML 路径。默认是 <repo>/max-loop-bug-scan-report.html。")
    parser.add_argument("--include-tests", action="store_true", help="包含 *_test.go 测试文件。")
    parser.add_argument("--min-literal-cap", type=int, default=10, help="忽略小于该值的数字循环上限。")
    parser.add_argument("--no-open", action="store_true", help="不要自动打开生成的 HTML 报告。")
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    out = Path(args.out).expanduser().resolve() if args.out else repo / "max-loop-bug-scan-report.html"

    findings: list[Finding] = []
    for path in iter_go_files(repo, args.include_tests):
        findings.extend(scan_file(path, repo, args.min_literal_cap))

    out.write_text(render_html(repo, findings), encoding="utf-8")
    print(f"已生成报告: {out}")
    print(f"候选风险数: {len(findings)}")

    if not args.no_open:
        open_report(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
