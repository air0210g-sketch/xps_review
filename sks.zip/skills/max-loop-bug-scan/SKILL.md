---
name: max-loop-bug-scan
description: 扫描 Go 代码仓库中固定最大循环次数的 for 循环，识别达到循环上限后可能静默停止、没有错误日志、告警、返回错误或其他可观测信号的问题。适用于排查 max loop bug、循环上限静默触顶、分页循环兜底次数、固定重试/批处理循环，或生成包含优先级、文件行号、说明、参考 diff、修改解释的 HTML 报告。
---

# 最大循环次数静默触顶扫描

## 使用流程

1. 在目标仓库根目录运行内置扫描脚本：

```bash
python ~/.codex/skills/max-loop-bug-scan/scripts/scan_max_loop_bug.py --repo .
```

2. 查看生成的 HTML 表格报告。脚本默认会使用 macOS `open` 自动打开报告。

3. 对每条结果做人工复核。脚本是启发式扫描：固定分片遍历，例如 `for tableIndex := 0; tableIndex < 1024; tableIndex++`，通常不是这类 bug；keyset 分页、批处理、清理、同步、推送、更新、callback 等循环更需要重点关注。

## 扫描目标

重点识别类似下面的循环：

```go
for i := 0; i < maxLoop; i++ {
    // 查询或处理下一页
    if done {
        break
    }
}
```

如果循环结束后没有明确记录“达到最大循环次数”，也没有监控上报或返回错误，脚本会将其列为候选风险。脚本会检查数字上限，例如 `10000`；命名上限，例如 `constant.LoopMaxCount`；以及任务参数，例如 `jobArgs.MaxLoop`。

脚本默认跳过以下常见非问题模式：

- `*_test.go` 测试文件
- 明显的固定 shard/table 遍历循环
- 循环后已有 `reach max`、`exceed max`、`max loop`、返回错误或监控上报的代码
- 低于默认阈值的小型数字重试循环

## 输出内容

HTML 报告包含以下列：

- `优先级 如P1/P2/P3`
- `代码所在文件和行数`
- `说明`
- `可参考的修改diff`
- `修改的解释说明`

默认输出到仓库根目录下的 `max-loop-bug-scan-report.html`。如需指定路径，使用 `--out`。

## 修复建议

在本仓库中，如果循环确实是“批处理/分页循环的防死循环兜底”，优先考虑使用 `safe_loop.NewSafeLoop`。关键业务任务要在循环结束后显式处理触顶场景。

如果最大循环次数是写死数字，例如 `10000`、`50000`，建议先改成 Apollo 配置，再接入 `SafeLoop`。原因是不同市场、不同数据量、不同 job 运行窗口下，合理上限可能不同；写死值会让线上扩容、临时止血和灰度调整都变困难。

```go
import "git.garena.com/shopee/bg-logistics/spx/delivery/lm-route-common/libs/safe_loop"

// 示例：新增 Apollo 配置 getter，默认值保持原硬编码值，避免发布后行为突变。
maxLoop := util.GetJobNameMaxLoop(ctx)
sl := safe_loop.NewSafeLoop(ctx, maxLoop)
for sl.Next() {
    // 原有循环逻辑
    if done {
        return nil
    }
}

if sl.GetCurrentIterations() > maxLoop {
    logger.CtxLogErrorf(ctx, "JobName reach max loop, max_loop=%d, last_id=%d", maxLoop, lastID)
    return errors.Errorf("JobName reach max loop, max_loop=%d, last_id=%d", maxLoop, lastID)
}
```

如果原本已经来自 Apollo/job args/常量配置，例如 `jobArgs.MaxLoop` 或 `util.GetXxxMaxLoop(ctx)`，则不需要再额外抽配置，重点是补触顶日志、监控和必要的返回错误。

低风险清理类任务可以先补清晰的错误日志和监控事件。关键业务任务建议返回 error，避免调度系统把“未处理完”误判为成功。

## 常用参数

```bash
python ~/.codex/skills/max-loop-bug-scan/scripts/scan_max_loop_bug.py --repo /path/to/repo --out /tmp/report.html
python ~/.codex/skills/max-loop-bug-scan/scripts/scan_max_loop_bug.py --repo . --no-open
python ~/.codex/skills/max-loop-bug-scan/scripts/scan_max_loop_bug.py --repo . --include-tests --min-literal-cap 0
```
