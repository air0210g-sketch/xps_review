# Config File Format

Store Apollo Open API tokens in `~/.codex/config.toml`:

```toml
[apollo_config_query.tokens]
test = "..."
uat = "..."
staging = "..."
live = "..."
br-uat = "..."
br-live = "..."
```

Token selection rules:
- `test` queries use `test`
- `uat` queries use `uat`, except cluster `br` uses `br-uat`
- `staging` queries use `staging`
- `live` queries use `live`, except cluster `br` uses `br-live`

Host mapping:

```text
test     -> https://config.ssc.test.shopeemobile.com
uat      -> https://config.ssc.uat.shopeemobile.com
staging  -> https://config.ssc.staging.shopeemobile.com
live     -> https://config.ssc.shopeemobile.com
br-uat   -> http://config-br1.ssc.uat.shopeemobile.com
br-live  -> https://config-br1.ssc.shopeemobile.com
```

Read endpoint:

```text
http://{portal_address}/openapi/v1/envs/{env}/apps/{appId}/clusters/{clusterName}/namespaces/{namespaceName}/items/{key}
```

If the required token is missing, stop and tell the user to add it to `~/.codex/config.toml`.
