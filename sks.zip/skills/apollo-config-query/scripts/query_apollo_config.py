#!/usr/bin/env python3
import argparse
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

try:
    import tomllib  # type: ignore
except ImportError:  # pragma: no cover
    tomllib = None


APP_ALIASES = {
    "spx-delivery-service": "spx-delivery-service",
    "delivery-service": "spx-delivery-service",
    "delivery service": "spx-delivery-service",
    "delivery": "spx-delivery-service",
    "spx-lm-route": "spx-lm-route",
    "lm-route": "spx-lm-route",
    "lmroute": "spx-lm-route",
    "lm route": "spx-lm-route",
}

APP_NAMESPACES = {
    "spx-delivery-service": [
        "common",
        "scorm",
        "application",
        "fms",
        "routeasy",
        "cse",
        "id_create",
        "assignment_task",
        "locker",
        "own_fleet",
        "lib",
        "transfer",
        "log",
        "driver_delivery",
        "chassis",
        "dbcommon",
        "lmo",
        "fault_inject",
        "polygon_match",
        "manpower",
    ],
    "spx-lm-route": [
        "application",
        "routing",
        "common",
        "third_party",
        "api_server",
        "task_server",
        "sentinel",
        "cse",
        "chassis",
    ],
}

DEFAULT_ENVS = ["test", "uat", "staging", "live"]
DEFAULT_CLUSTERS = ["id", "vn", "my", "tw", "th", "ph", "sg", "br"]
HOSTS = {
    "test": "https://config.ssc.test.shopeemobile.com",
    "uat": "https://config.ssc.uat.shopeemobile.com",
    "staging": "https://config.ssc.staging.shopeemobile.com",
    "live": "https://config.ssc.shopeemobile.com",
    "br-uat": "http://config-br1.ssc.uat.shopeemobile.com",
    "br-live": "https://config-br1.ssc.shopeemobile.com",
}


def parse_csv(value):
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def resolve_app_id(target, app_id):
    if app_id:
        return app_id
    if not target:
        return "spx-delivery-service"
    normalized = target.strip().lower()
    return APP_ALIASES.get(normalized, "spx-delivery-service")


def codex_config_path(explicit_path=None):
    if explicit_path:
        return Path(explicit_path).expanduser()
    return Path.home() / ".codex" / "config.toml"


def load_tokens(config_path):
    if not config_path.exists():
        return {}, f"missing config file: {config_path}"
    raw = config_path.read_text()
    if tomllib is not None:
        data = tomllib.loads(raw)
        section = data.get("apollo_config_query", {})
        tokens = section.get("tokens", {})
        if not isinstance(tokens, dict):
            return {}, f"invalid [apollo_config_query.tokens] section in {config_path}"
        return tokens, None
    return parse_tokens_without_tomllib(raw), None


def parse_tokens_without_tomllib(raw):
    tokens = {}
    section = None
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            section = stripped[1:-1].strip()
            continue
        if section != "apollo_config_query.tokens" or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        tokens[key] = value
    return tokens


def token_key_for(env, cluster):
    if cluster == "br" and env == "uat":
        return "br-uat"
    if cluster == "br" and env == "live":
        return "br-live"
    return env


def host_for(env, cluster):
    token_key = token_key_for(env, cluster)
    return HOSTS[token_key]


def infer_namespace(app_id, namespace, key):
    known = APP_NAMESPACES.get(app_id, [])
    if namespace:
        if key.startswith(namespace + "."):
            return [namespace], key[len(namespace) + 1 :]
        return [namespace], key
    if "." in key:
        prefix, rest = key.split(".", 1)
        if prefix in known:
            return [prefix], rest
    return known, key


def short_status_from_http_error(exc):
    body = exc.read().decode("utf-8", errors="replace").strip()
    if not body:
        return f"http {exc.code}"
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        condensed = re.sub(r"\s+", " ", body)
        return f"http {exc.code}: {condensed[:120]}"
    message = payload.get("message") or payload.get("error") or payload.get("exception") or "request failed"
    return f"http {exc.code}: {message}"


def fetch_item(host, token, env, app_id, cluster, namespace, key, timeout):
    quoted_key = urllib.parse.quote(key, safe="")
    url = (
        f"{host}/openapi/v1/envs/{env}/apps/{app_id}/clusters/{cluster}"
        f"/namespaces/{namespace}/items/{quoted_key}"
    )
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
            return payload.get("value", ""), "ok"
    except urllib.error.HTTPError as exc:
        return "", short_status_from_http_error(exc)
    except urllib.error.URLError as exc:
        return "", f"network error: {exc.reason}"
    except Exception as exc:  # pragma: no cover
        return "", f"error: {exc}"


def render_markdown(rows):
    headers = ["appid", "env", "cluster", "namespace", "key", "value", "status"]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in rows:
        vals = []
        for header in headers:
            value = str(row.get(header, ""))
            value = value.replace("\n", "\\n").replace("|", "\\|")
            vals.append(value)
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Query Apollo config values across envs, clusters, and namespaces."
    )
    parser.add_argument("--target", "--repo", "--service", dest="target")
    parser.add_argument("--app-id")
    parser.add_argument("--env")
    parser.add_argument("--envs")
    parser.add_argument("--cluster")
    parser.add_argument("--clusters")
    parser.add_argument("--namespace")
    parser.add_argument("--key", required=True)
    parser.add_argument("--config-file")
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument("--format", choices=["table", "json"], default="table")
    args = parser.parse_args()

    app_id = resolve_app_id(args.target, args.app_id)
    envs = [args.env] if args.env else parse_csv(args.envs) or DEFAULT_ENVS
    clusters = [args.cluster] if args.cluster else parse_csv(args.clusters) or DEFAULT_CLUSTERS
    namespaces, key = infer_namespace(app_id, args.namespace, args.key)

    config_path = codex_config_path(args.config_file)
    tokens, token_error = load_tokens(config_path)
    rows = []

    if token_error:
        row = {
            "appid": app_id,
            "env": "",
            "cluster": "",
            "namespace": args.namespace or "",
            "key": key,
            "value": "",
            "status": f"{token_error}; please configure ~/.codex/config.toml",
        }
        output_rows(rows + [row], args.format)
        return 1

    for env in envs:
        for cluster in clusters:
            token_name = token_key_for(env, cluster)
            token = tokens.get(token_name, "").strip()
            if not token:
                missing_row = {
                    "appid": app_id,
                    "env": env,
                    "cluster": cluster,
                    "namespace": args.namespace or "",
                    "key": key,
                    "value": "",
                    "status": f"missing token '{token_name}' in ~/.codex/config.toml",
                }
                rows.append(missing_row)
                continue
            host = host_for(env, cluster)
            for namespace in namespaces:
                value, status = fetch_item(host, token, env, app_id, cluster, namespace, key, args.timeout)
                rows.append(
                    {
                        "appid": app_id,
                        "env": env,
                        "cluster": cluster,
                        "namespace": namespace,
                        "key": key,
                        "value": value,
                        "status": status,
                    }
                )

    output_rows(rows, args.format)
    return 0


def output_rows(rows, output_format):
    if output_format == "json":
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return
    print(render_markdown(rows))


if __name__ == "__main__":
    sys.exit(main())
