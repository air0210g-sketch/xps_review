---
name: apollo-config-query
description: 查询 delivery-service 或 lm-route 的 Apollo Open API 配置值。适用于查看单个 key、对比不同环境或 cluster、核对 namespace 配置，或排查 test、uat、staging、live 的 Apollo 设置。
---

# Apollo Config Query

当用户想通过 Shopee Apollo Open API 读取配置时，使用这个 skill。

支持的目标仓库映射：
- `delivery-service`、`delivery service`、`delivery` -> `spx-delivery-service`
- `lm-route`、`lmroute`、`lm route` -> `spx-lm-route`

如果用户没有明确指向 `lm-route`，默认按 `spx-delivery-service` 处理。

## 快速规则

- 支持的环境：`test`、`uat`、`staging`、`live`
- 如果用户没指定环境，默认查询这 4 个环境。
- 支持的 cluster：`id`、`vn`、`my`、`tw`、`th`、`ph`、`sg`、`br`
- 如果用户没指定 cluster，默认查询这 8 个市场。
- `br + uat` 使用巴西本地 UAT Apollo host 和 `br-uat` token。
- `br + live` 使用巴西本地 live Apollo host 和 `br-live` token。
- 其它 env/cluster 组合都走新加坡部署的 Apollo 服务，并使用对应环境名的 token。
- 输出必须是 Markdown 表格，至少包含这些列：
  `appid`, `env`, `cluster`, `namespace`, `key`, `value`, `status`
- 查询成功时，`status` 为 `ok`；失败时填简短错误摘要。

## Token 来源

从 `~/.codex/config.toml` 读取 token。

所需配置在 `[apollo_config_query.tokens]` 下。

如果缺少所需 token，直接告知用户先去配置 `~/.codex/config.toml`，不要猜测 token，也不要把密钥硬编码进 skill。

配置格式见 [config-format.md](references/config-format.md)。

补充说明：
- 这里使用的 Apollo token 只具备 Apollo 读权限，不具备 Apollo 写权限。
- 如果需要申请或更新 token，找管理员 `xianwei.lin` 获取。

## Namespace 解析

已知 namespace：

- `spx-delivery-service`:
  `common`, `scorm`, `application`, `fms`, `routeasy`, `cse`, `id_create`, `assignment_task`, `locker`, `own_fleet`, `lib`, `transfer`, `log`, `driver_delivery`, `chassis`, `dbcommon`, `lmo`, `fault_inject`, `polygon_match`, `manpower`
- `spx-lm-route`:
  `application`, `routing`, `common`, `third_party`, `api_server`, `task_server`, `sentinel`, `cse`, `chassis`

解析顺序：
1. 如果用户明确给了 `namespace`，就直接使用。
2. 如果用户给的 key 类似 `scorm.mysql.default.connMaxLifetime`，并且前缀命中已知 namespace，则推断 `namespace=scorm`，真正查询的 key 为 `mysql.default.connMaxLifetime`。
3. 如果还是无法确定 namespace，就对该 appid 的所有已知 namespace 批量查询。

## 工作流

1. 根据用户表述解析目标 appid；如果用户直接给了 appid，就以用户为准。
2. 从请求中解析 env 和 cluster；未指定时按默认全集查询。
3. 按上面的规则解析 namespace。
4. 运行 [query_apollo_config.py](scripts/query_apollo_config.py)。
5. 返回表格结果，并清楚说明缺 token、鉴权失败或 HTTP 错误。

## 脚本

运行示例：

```bash
python3 scripts/query_apollo_config.py \
  --target delivery-service \
  --envs test,uat,staging,live \
  --clusters id,vn,my,tw,th,ph,sg,br \
  --namespace scorm \
  --key mysql.default.connMaxLifetime
```

注意：
- 不要在面向用户的回复里回显 token。
- 最终答案保持简洁，以结果表格为主。
- 没查到值时，`value` 留空，并把原因写进 `status`。
- 遇到 `401`、`403`、`404`、`405`、`500` 时，把 HTTP 状态码带进 `status`。

## 备注

- `br` 是特殊流量，因为 BR live 和 BR UAT 的 Apollo 服务部署在巴西本地机房。
- 如果用户只要某一个明确的 env/cluster，就不要无谓扩成全量查询。
- 如果用户只是快速核对，并且 key 已经带 namespace 前缀，优先走最窄查询。
